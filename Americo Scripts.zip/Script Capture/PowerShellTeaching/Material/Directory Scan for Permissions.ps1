﻿####################################################################
#
# Written by Terry Zumwalt (October 2023)
#
#####################################################################


#Change THIS!
$Log = "C:\Automation\NetworkScan_Log.txt"



#Array of Directories to scan
$DirArray = "\\KCSAN03\#KCSAN03\","\\kcnas01\#kcnas01\", "\\kcsan03\#kcnas01\"



$DirArray |%{
    
     CLS
     Write-Host "Please Wait: There is alot of information to load.."  -ForegroundColor yellow
    
    Set-Location $_

    $Error.clear()
    
    
    $Paths = Get-ChildItem -Recurse -Depth 2 -Directory -ErrorAction Ignore |Where{$_.Directory -notlike ".*"}
    

    foreach($Path in $Paths)
    {
        Write-Host $Path -ForegroundColor Yellow

        $DirPath = $Path.PSPath
        $ACL = $DirPath |get-acl


        if(($ACL.Access).IdentityReference -like "*SQL*" -or ($ACL.Access).IdentityReference -like "*DBA*" -or ($ACL.Access).IdentityReference -like "*DBA_DEV*" -or ($ACL.Access).IdentityReference -like "*Prod_DB*")
        {
            $ACLPath = $ACL.Path
            $ACLPath = $ACLPath -split '::'
            $ACLPath = $ACLPath[1]

            $ACLOwner = $Acl.Owner

            $ACLAccess = $Acl.access

            $InfObj = New-Object PSObject
            Add-Member -InputObject $InfObj -MemberType NoteProperty -Name Path -Value $ACLPath
            Add-Member -InputObject $InfObj -MemberType NoteProperty -Name Owner -Value $ACLOwner
            Add-Member -InputObject $InfObj -MemberType NoteProperty -Name Access -Value ($ACLAccess|Where{$_.IdentityReference -like "*SQL*" -or $_.IdentityReference -like "*DBA*" -or $_.IdentityReference -like "*DBA_DEV*" -or $_.IdentityReference -like "*PROD_DB*"})


            

            foreach($obj in $InfObj.access)
            {
                foreach($Right in $obj.FileSystemRights)
                {
                    $Export = $InfObj.Path + "," + $InfObj.Owner + "," + $obj.IdentityReference + "," + ($Right -replace ",", "::")
                    $Export |out-File $Log -Append
                    Write-Host $Export
                }
                
            }


        }
     
   
    }

}



$Done = "Scan Complete!"
$Done |out-file $Log -Append