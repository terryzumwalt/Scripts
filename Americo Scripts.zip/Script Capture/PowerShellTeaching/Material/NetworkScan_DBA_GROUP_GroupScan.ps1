####################################################################
#
# Written by Terry Zumwalt (October 2023)
#
#####################################################################


#Change THIS!
$Log = "C:\Automation\NetworkScan_SQLDBA_Log.csv"

$Headers = "Path" + "," + "Owners" + "," + "Users" + "," + "Permissions"
$Headers |out-File $Log -Append

#Array of Directories to scan
$DirArray = "\\KCSAN03\#KCSAN03\","\\kcnas01\#kcnas01\"

 
$GroupArray = @(
'LA_KCHEDGESQL01'
'LA_KCSPOTSQL01'
'SCCM Report User'
'LA_KCSQLACT01'
'LA_KCSQLCASE01'
'LA_KCSQLACT02'
'LA_KCSPOTSQL50'
'LA_KCSQLVRN51'
'LA_KCSQLVRN52'
'LA_SQLTAI01'
'LA_SQLHEDGE01'
'LA_SQLHEDGE02'
'LA_SQLINFA51'
'LA_SQLINFA71'
'LA_SQLINFA01'
'LA_SQLPMGR01'
'LA_SQLArchive51'
'LA_SQLArchive01'
'LA_SQLSSAS51'
'LA_SQLDW51'
'LA_SQLDW71'
'LA_SQLDW01'
'LA_SQLGPINT62'
'LA_SQLGPINT02'
'LA_SQLGPINT72'
'LA_APPWSCAPE71'
'f_kcnas01_finance_afcomm_case_RW'
'F_claims_clcomm_RO'
'F_finance_PowerPlay_ARCVAL_RO'
'F_finance_PowerPlay_ARCVAL_LAB_RO'
'LA_SQLDW61'
'F_finance_DED_RO'
'PrivDesktop-LA'
)

Import-Module SQLServer


$DirArray |%{
    
     CLS
     Write-Host "Please Wait: There is alot of information to load.."  -ForegroundColor yellow
    
    Set-Location $_

    $Error.clear()
    
    
    $Paths = Get-ChildItem -Recurse -Depth 3 -Directory -ErrorAction Ignore |Where{$_.Name -notlike "*.DFSFolder*"}


    foreach($Path in $Paths)
    {
        Write-Host $Path -ForegroundColor Yellow

        $DirPath = $Path.PSPath
        $ACL = $DirPath |get-acl

        foreach($ACLName in (($ACL.Access).IdentityReference).value)
        {
            if($GroupArray -contains $ACLName)  
            {
                $ACLPath = $ACL.Path
                $ACLPath = $ACLPath -split '::'
                $ACLPath = $ACLPath[1]

                $ACLOwner = $Acl.Owner
                $ACLAccess = $Acl.access

                $InfObj = New-Object PSObject
                Add-Member -InputObject $InfObj -MemberType NoteProperty -Name Path -Value $ACLPath
                Add-Member -InputObject $InfObj -MemberType NoteProperty -Name Owner -Value $ACLOwner
                Add-Member -InputObject $InfObj -MemberType NoteProperty -Name Access -Value ($ACLAccess|Where{$GroupArray -contains $_.IdentityReference })


                foreach($obj in $InfObj.access)
                {
                    foreach($Right in $obj.FileSystemRights)
                    {
                        $Export = $InfObj.Path + "," + $InfObj.Owner + "," + $obj.IdentityReference + "," + ($Right -replace ",", "::")
                        $Export |out-File $Log -Append
                        Write-Host $Export
                    }
                    
                }


            }

        }
     
   
    }

}



$Done = "Scan Complete!"
Write-host $Done
#$Done |out-file $Log -Append
" "

" "
" "

########################################### Begin Upload #############################
$Error.Clear()
Write-Host "Beginning Results Upload" -ForegroundColor Yellow
" "
" "
##Re-name your file
$TableName = "DBA_GROUP_Members_NetworkScan"

#$InputData = Get-Content $Log

Import-CSV $LOG| Write-SqlTableData -ServerInstance "SQLDBA51" -DatabaseName "PAW"  -TableName $TableName -SchemaName "dbo" -Force -Verbose

if(!$Error){Write-Host "File upload was successfull!!" -ForegroundColor Yellow}
if($Error){Write-Host "File upload Failed..." -ForegroundColor Red}


















