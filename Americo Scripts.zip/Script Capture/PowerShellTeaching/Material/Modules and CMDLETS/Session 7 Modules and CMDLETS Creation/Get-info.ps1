﻿
#https://www.mssqltips.com/sqlservertip/7262/cmdlets-for-powershell-examples/

Function Get-Info{

    [CmdletBinding()]
    param(
      [Parameter(Mandatory=$true)]
      [String]$aMandatoryParameter,

      [String]$nonMandatoryParameter,

      [Parameter(Mandatory=$true)]
      [String]$anotherMandatoryParameter

    )

    Begin {
        # ... your code ...
    } #close Begin

    Process {
        # ... your code ...
    } #close process

    End {
        # ... your code ...
    }


}

Get-Info