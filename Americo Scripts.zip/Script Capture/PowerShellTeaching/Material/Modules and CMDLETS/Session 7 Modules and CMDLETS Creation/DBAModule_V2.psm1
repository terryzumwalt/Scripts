﻿
#Remember to import the SQLServer Module Manually


#use the Azure Devops Module to just get the files from 
#https://dev.azure.com/americo-prod/SCR/_git/AgentSchema?path=/Americo.Agent.Tools.SCR.Schema/Scripts/SeedData&version=GBdevelop
#Module: VSTeam


Function get-SQLQuery{
    

    [CmdletBinding()]
    param(
      [Parameter(Mandatory=$true)] #Mandatory Param
      [String]$ServerName,

      [Parameter(Mandatory=$true)] #Mandatory Param
      [String]$Database,

      [Parameter(Mandatory=$true)] #Mandatory Param
      [String]$Path,

      [Parameter(Mandatory=$true)] #Mandatory Param
      [String]$Modified_Month

    )

    #Get the modified files only. 

    $GetScripts = Get-ChildItem $Path |Where{$_.Name -like "*.sql" -and $_.LastWriteTime.month -eq $Modified_Month}

    $GetScripts|%{

        $Query = get-content $_.PSPath
        
    

        Write-Host "Attempting to Run" $_.Name -ForegroundColor Yellow
        $Srv = $ServerName
        $Server = New-Object("Microsoft.SQLServer.Management.SMO.Server")$Srv
        $Server.Databases[$Database].ExecuteWithResults($Query).Tables[0]
        

    }


}

