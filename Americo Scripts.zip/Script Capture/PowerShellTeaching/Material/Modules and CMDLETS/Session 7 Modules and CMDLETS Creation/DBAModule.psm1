﻿


#Import-Module SQLServer


Function get-SQLQuery{

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [String]$ServerName,

        [Parameter(Mandatory=$true)]
        [String]$Database,

        [Parameter(Mandatory=$true)]
        [String]$Query
    )

    #Formed with SMO

    $Srv = $Servername
    $Server = New-Object("Microsoft.SQLServer.Management.SMO.Server")$Srv
    $Server.Databases[$Database].ExecuteWithResults($Query).Tables[0]
  


}


Function get-ADOQuery{

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [String]$ServerName,

        [Parameter(Mandatory=$true)]
        [String]$Database,

        [Parameter(Mandatory=$true)]
        [String]$Query
    )

    
    #Formed with ADO.Net

    $Srv = $ServerName
    $Server = New-Object System.Data.SqlClient.SqlConnection
    $Server.ConnectionString = "Server=$Srv;Integrated Security=true;Initial Catalog=$Database”
    $Server.Open()

    $QueryObj = $Server.CreateCommand()
    $QueryObj.CommandText = $Query

    $DataSet = New-Object System.Data.Dataset
    $Adapter = New-Object System.Data.SqlClient.SQLDataAdapter $QueryObj
    $Adapter.Fill($DataSet)

    $DataSet.Tables |Format-table

    $Server.Close()
    

}




