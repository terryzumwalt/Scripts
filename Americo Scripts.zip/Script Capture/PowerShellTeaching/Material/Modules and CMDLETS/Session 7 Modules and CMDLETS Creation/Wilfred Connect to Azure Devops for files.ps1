﻿
#https://itconstructors.com/download-files-from-azure-devops-repository-with-powershell/


import-module VSTeam
Import-Module AZ


#Connect-AzAccount -Tenant Americo.com -Credential

#Sign in to azure or Devops first with MFA
Connect-AzAccount -Tenant "Americo.com" 



#Youre Private Devops Token
$tokenInSecureString = ConvertTo-SecureString "kyeycm6ub5mb2jusejuhx2szdtbzltqqk33gckwzoozdgzsyeeyq" -AsPlainText -force


#Now we will get access to the Rest-API
$dummyCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList 'fakeUser', $tokenInSecureString


$base64AuthString = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f "", $dummyCredential.GetNetworkCredential().Password)))
$header = @{
    "Authorization" = ("Basic {0}" -f $base64AuthString)
}

$organization = {Americo-PROD}
$project = {SCR}
$Repo = "AgentSchema"

$urlRepos = "https://dev.azure.com/americo-prod/SCR/_git/AgentSchema?path=/Americo.Agent.Tools.SCR.Schema/Scripts/SeedData&version=GBdevelop"
$resultRepos = Invoke-RestMethod -Uri $urlRepos -Method Get -ContentType "application/text" -Headers $header



$urlDownloadItems = "https://dev.azure.com/$organization/$project/_apis/git/repositories/$Repo/items?recursionLevel=Full&api-version=5.0"
$urlDownloadItems

#This will list all the file paths in the repo
$itemPaths = Invoke-RestMethod -Uri $urlDownloadItems -Method Get -ContentType "application/text" -Headers $header


#your at the bottom of the page .
#?
$urlDownloadItem = "https://dev.azure.com/$organization/$project/_apis/git/repositories/$Repo/items?path={FILE PATH}&download=true&api-version=5.0"





##############################################################################################################################################################
get-command -module VSTeam

Show-VSTeam









#List AZ Instances
$Instances = Get-AzSqlInstance
$InstanceNames = $Instances.ManagedInstanceName
$InstanceNames

#Select an Instance Name
$SetInst = "ame-mi-lab-51-east"
$SetInst


#List Resource Groups
$ResourceGroups = Get-AzResourceGroup
$ResourceGroups

#Select a Resource Group
$ResourceGRP = "americo-database-east"


#List Databases on Instance
$DBList = Get-AzSqlInstanceDatabase -ResourceGroupName $ResourceGRP -InstanceName $SetInst
$DBlist.Name







$subscriptionId = "47b6a62d-0e97-4062-9228-0e5ab3dff8a8"
$resourceGroupName = "americo-database-east"
#$managedInstanceName = "ame-mi-lab-51-east.16559c496249.database.windows.net"
$managedInstanceName = "ame-mi-lab-51-east"
$databaseName = "CustomerPortal_Staging"
$pointInTime = "2022-12-05T08:51:39.3882806Z"
$targetDatabase = "Test_Restore"

#Get-AzSubscription -SubscriptionId $subscriptionId
#Select-AzSubscription -SubscriptionId $subscriptionId

Restore-AzSqlInstanceDatabase -FromPointInTimeBackup `
-ResourceGroupName $resourceGroupName `
-InstanceName $managedInstanceName `
-Name $databaseName `
-PointInTime $pointInTime `
-TargetInstanceDatabaseName $targetDatabase