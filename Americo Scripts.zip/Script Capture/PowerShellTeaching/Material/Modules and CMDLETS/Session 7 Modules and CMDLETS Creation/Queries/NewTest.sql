Select @@ServerName
 WAITFOR DELAY '00:00:05';