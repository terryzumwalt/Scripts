﻿#Import this script name as a module(.\Import-Module Get-Info.psm1)
#Run get-command Get-info to get commands
#Now you can use Get-info -stuffhere -stuffhere

#\\kcsan03\users\tzumwalt\Scripts\TEMP - Tasks\PowerShellTeaching\Material\Modules and CMDLETS


Function Get-Logins{

    [CmdletBinding()]
    param(
      [Parameter(Mandatory=$true)] #Mandatory Param
      [String]$ServerName

      #[String]$Path,  #Not Mandatory

      #[Parameter(Mandatory=$true)]  #Mandatory Param
      #[String]$anotherMandatoryParameter
    )


      $Error.clear()
       Try{
            Import-Module SQLServer 
       }
       Catch{
            Write-Host "The SQLServer Module is not installed"
            Exit
       }


        
       $Srv = $ServerName
       $Server = New-Object("Microsoft.SQLServer.Management.SMO.Server")$Srv
       $Logins = $Server.Logins


       #Write Ouptut to the console
       $Logins |Format-Table

}





Function Get-Query{

    [CmdletBinding()]
    param(
      [Parameter(Mandatory=$true)] #Mandatory Param
      [String]$ServerName,

      [Parameter(Mandatory=$true)] #Mandatory Param
      [String]$Database,

      [Parameter(Mandatory=$true)] #Mandatory Param
      [String]$Query


      #[String]$Path,  #Not Mandatory

      #[Parameter(Mandatory=$true)]  #Mandatory Param
      #[String]$anotherMandatoryParameter
    )
        #$ServerName = "SQLDBA01"
        #$Database = "master"
        #$Query = "select name from sys.tables"


       $Srv = $ServerName
       $Server = New-Object("Microsoft.SQLServer.Management.SMO.Server")$Srv
       $Server.Databases[$Database].ExecuteWithResults($Query).Tables[0]



}




Function get-Connections{

    
     [CmdletBinding()]
     Param(
         [Parameter(Mandatory=$true)] #Mandatory Param
         [String]$ServerName
     )

    
    
    
    $Srv = $ServerName
    $Server = New-Object("Microsoft.SQLServer.Management.SMO.Server")$Srv

    $Name = whoami
    $Query = "exec sp_who2"
    $Results = $Server.Databases["Master"].ExecuteWithResults($Query).Tables[0]


    $Results |Where-object Login -eq $Name

}
