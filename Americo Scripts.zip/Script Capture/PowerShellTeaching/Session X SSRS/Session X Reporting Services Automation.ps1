﻿#Connect to SSRS

$SrcServer = "SQLDBA51"

$URI = "http://$SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $URI -UseDefaultCredential
$svc



<###########################################################################################################>

#View SSRS Content (All Objects)

$SrcServer = "SQLDBA51"

$URI = "http://$SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $URI -UseDefaultCredential

$svc.ListChildren("/", $true) 




<###########################################################################################################>

#View Folders

$SrcServer = "SQLDBA51"

$URI = "http://$SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $URI -UseDefaultCredential

$Folders = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
$Folders






<###########################################################################################################>

#Create variables of objects


$SrcServer = "SQLDBA51"

$URI = "http://$SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $URI -UseDefaultCredential

$Folders = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
$Reports = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report"}
$DataSources = $svc.ListChildren("/",$true) | select -Property Path,TypeName  | Where{$_.TypeName -eq "DataSource"}
$DataSets = $svc.ListChildren("/",$true) | select -Property Path,TypeName  |Where{$_.TypeName -eq "DataSet"}



<###########################################################################################################>

#output folders color coded for Inheritance

$SrcServer = "SQLDBA51"

$URI = "http://$SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $URI -UseDefaultCredential

$Folders = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}

$InheritParent = $True

Foreach($Folder in $Folders)
{
    $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent)

    if($InheritParent -eq $True){Write-Host "TRUE: "$Folder.path -ForegroundColor Yellow}
    if($InheritParent -eq $False){Write-Host "False: "$Folder.path -ForegroundColor Gray}

}



<###########################################################################################################>

#Make changes if Inhertiance is False. 


$SrcServer = "SQLDBA51"

$URI = "http://$SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $URI -UseDefaultCredential

$Folders = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}

$InheritParent = $True

Foreach($Folder in $Folders)
{
    $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent)

    if($InheritParent -eq $False)
    {
        #<Task here>
    }
}



<###########################################################################################################>

#Add User to Folder

$SrcServer = "SQLDBA51"

$URI = "http://$SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $URI -UseDefaultCredential

$Folders = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}

$InheritParent = $True



<# FILTER for 1 Directory #>
$Folders = $Folders |Where{$_.Path -like "*TZ*"}
$Folders = $Folders[0]

Foreach($Folder in $Folders)
{
    $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent)

    if($InheritParent -eq $False)
    {
       
        $type = $svc.GetType().Namespace 
        $datatype = ($type + '.Property')

        $policyType = "{0}.Policy" -f $type;
        $roleType = "{0}.Role" -f $type;
        $Policy = New-Object ($policyType)
        $Policy.GroupUserName = "KCDOM01\tzumwalt"
        $Policy.Roles = @()
        $RoleName = "Content Manager"

        [array]$Policies += $Policy

        foreach($Role in $RoleName)
        {
            $r = New-Object ($roleType)
            $r.Name = $Role
            $Policy.Roles += $r
        }

        
        #Update the Folder Permissions
        $svc.SetPolicies($Folder.Path, $Policies)


    }
}














<###########################################################################################################>

#Remove user from Folder



$SrcServer = "SQLDBA51"

$URI = "http://$SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $URI -UseDefaultCredential

$Folders = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}

$InheritParent = $True

<# FILTER for 1 Directory #>
$Folders = $Folders |Where{$_.Path -like "*TZ*"}
$Folders = $Folders[0]

Foreach($Folder in $Folders)
{
    $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent)
    $Policies = $Policies |Where-Object GroupUserName -ne "kcdom01\tzumwalt"

    #Update the Folder Permissions
    $svc.SetPolicies($Folder.Path, $Policies)

}





<###########################################################################################################>




#Add Users to Reports


$SrcServer = "SQLDBA51"

$URI = "http://$SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $URI -UseDefaultCredential

#$Folders = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
$Reports = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report"}


$InheritParent = $True



<# FILTER for 1 Directory #>
#$Folders = $Folders |Where{$_.Path -like "*TZ*"}
#$Folders = $Folders[0]

$Reports = $Reports |Where{$_.Path -like "*TZ*"}
$Reports = $Reports[0]


Foreach($Report in $Reports)
{
    $Policies = $svc.GetPolicies($Report.path, [ref] $InheritParent)

    if($InheritParent -eq $False)
    {
       
        $type = $svc.GetType().Namespace 
        $datatype = ($type + '.Property')

        $policyType = "{0}.Policy" -f $type;
        $roleType = "{0}.Role" -f $type;
        $Policy = New-Object ($policyType)
        $Policy.GroupUserName = "KCDOM01\tzumwalt"
        $Policy.Roles = @()
        $RoleName = "Content Manager"

        [array]$Policies += $Policy

        foreach($Role in $RoleName)
        {
            $r = New-Object ($roleType)
            $r.Name = $Role
            $Policy.Roles += $r
        }

        
        #Update the Folder Permissions
        $svc.SetPolicies($Report.Path, $Policies)


    }
}


################################################################################################################

#Remove user from Report Policy


$SrcServer = "SQLDBA51"

$URI = "http://$SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $URI -UseDefaultCredential

#$Folders = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
$Reports = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report"}


$InheritParent = $True

<# FILTER for 1 Directory #>
#$Folders = $Folders |Where{$_.Path -like "*TZ*"}
#$Folders = $Folders[0]

$Reports = $Reports |Where{$_.Path -like "*TZ*"}
$Reports = $Reports[0]



Foreach($Report in $Reports)
{
    $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent)
    $Policies = $Policies |Where-Object GroupUserName -ne "kcdom01\tzumwalt"

    #Update the Folder Permissions
    $svc.SetPolicies($Report.Path, $Policies)

}


##################################################################################################################



# Adding and Removing users from other obejcts.


#Create variables of objects


$SrcServer = "SQLDBA51"

$URI = "http://$SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $URI -UseDefaultCredential



#Folder Objects
$Folders = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}

#Report Objects
$Reports = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report"}

#Data Source Objects
$DataSources = $svc.ListChildren("/",$true) | select -Property Path,TypeName  | Where{$_.TypeName -eq "DataSource"}

#Data Set Objects
$DataSets = $svc.ListChildren("/",$true) | select -Property Path,TypeName  |Where{$_.TypeName -eq "DataSet"}


