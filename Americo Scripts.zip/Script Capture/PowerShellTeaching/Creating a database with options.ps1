﻿#Create a database and set options

#Variable Names
$Srv = "SQLSandbox71"
$dbname = "Testing"

#Server Object
$Server = New-Object("Microsoft.SQLServer.Management.SMO.Server")$srv


#Create DB Obj with Associated instance and Name
$DB = new-Object("Microsoft.SQLServer.Management.SMO.Database") -ArgumentList $Srv, $dbname

#Create the Database on SQL Server
$DB.Create()


#Set Recovery Model
$DB.RecoveryModel = "Simple"
#Set Owner
$DB.SetOwner('sa')
$DB.Alter()



#Drop The database
#$DB.Drop()





