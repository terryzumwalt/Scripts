﻿
<#
    To get started we are going to "touch" on functionality and some of the ways to get and use data at a basic level.
#>



#Step 1: Install the SQL Server Module
#Install-Module SQLServer -AllowClobber -Force

#Step 2: Import The Module
Import-Module SQLServer


#Step 3: Create Server object
$Srv = "SQLDBA01"
$Server = New-Object("Microsoft.SQLServer.Management.SMO.Server")$Srv


#Step 4: The object (General Exploration)
$Server

$Server.Properties
$Server.Properties|Select-Object Name   #OR  $Server.Properties.name
$Server.Properties |Where{$_.Name -eq 'OSVersion'}

$Server.Logins
$Server.AffinityInfo

$Server.Databases | Sort-Object -Property RecoveryModel -Descending
$Server.Databases | Select-Object Name, RecoveryModel,Owner |format-table  #Default for the object
$Server.Databases | Select-Object Name, RecoveryModel,Owner | format-list 
$Server.Databases | Select-Object Name, RecoveryModel,Owner | Out-GridView  #Filtering
$Server.Databases | Select-Object Name, RecoveryModel,Owner | Out-File -FilePath "Path to log file HERE"

$CreateAVariable = $Server.Databases | Select-Object Name, RecoveryModel,Owner
$CreateAVariable




#Step 5: learn to Query

#--SQL Instance
$Instance = "SQLDBA01"
$Database = "DBA_WORKDB"
$Tables = Invoke-Sqlcmd -ServerInstance $Instance -Database $Database -Query "Select * from SYS.Tables" 
$Tables | Format-Table


#--Azure (Working Example in the Storage Job)
$Srv = "ame-mi-prod-01-central.16559c496249.database.windows.net"
$MaintDB = "AmericoStoragePS" 
$AzureQuery = @"

    Select * from dbo.ServerStoragePS_Staging
"@

$AZQuery = Invoke-Sqlcmd -Query $AzureQuery -ConnectionString "Server=tcp:$Srv,1433;Database=$MaintDB;Authentication=Active Directory Integrated;Encrypt=True;"        
$AZQuery|Format-Table



#Step 6: Explore the Variable

$AzQuery.GetType()
$AzQuery.count
$AZQuery[10] |format-table
$AZQuery[10].Servername




#Step 7: Bring the Data to a local Database
# Skipping Looping for this section


$FilterQuery = $AZQuery[10] | Select-object ServerName, File_Group
$TablenName = "TestTable"
$ServerName = $FilterQuery.ServerName
$FileGroup = $FilterQuery.File_Group
$LocalInsert = @"
    
    insert into $TableName (ServerName,File_Group)
    Values($ServerName,$FileGroup)
"@


#-- Check Query
$LocalInsert

#Invoke-Sqlcmd -ServerInstance "InstanceName" -Database "DBName" -Query $LocalInsert




#**************************** May want to end lesson 1 here ********************************************






#Step 8: Looping with Arrays








<#
    Thoughts on More Training Items
    -- Alternet query method to by pass SQLServer module (https://www.c-sharpcorner.com/blogs/insert-data-into-sql-server-table-using-powershell)
    1. Create your own Module and import it (Show how modules work)
    2. Cover Param in scripts
    3. Cover [PSCUSTOMOBJECT]


    Later Items
    1. SSRS Scripts 
    2. SnowSQL
#>


