﻿param(
    [string]$ReportServer = 'kcadcrsql10'
)

$RSUrl = "http://" + $ReportServer +"/ReportServer/ReportService2010.asmx"
$webSRV = New-WebServiceProxy -Uri "http://$ReportServer/ReportServer/ReportService2010.asmx" -Namespace SSRS.ReportingService2010 -UseDefaultCredential;  
$mySubsList = $webSRV.ListSubscriptions("/");  
#$mySubsList | select report, description, owner, status, lastexecuted, subscriptionid, path | format-table -auto 
#$mySubsList | select report, description, owner, status, lastexecuted, subscriptionid, path | Export-Csv -Path C:\test\Netwrix_SSRS.csv -NoTypeInformation
#$mySubsList | select select report, description, owner, status, lastexecuted, subscriptionid, path | Out-GridView
$mySubsList | select * | Out-GridView