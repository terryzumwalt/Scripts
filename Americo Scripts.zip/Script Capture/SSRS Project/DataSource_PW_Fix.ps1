﻿import-module ReportingServicesTools
Import-Module ImportExcel

$DSArray = Import-Excel -Path "\\kcsan03\technology\DBA\SSRS\SSRS Move\Phase 2\Scripts\Datasource_PW_Fix.xlsx"
$DSArray = $DSArray |Where{$_.path -ne $NULL}

$uri = "http://sqlssrs02/reportserver/ReportService2010.asmx"
$RS = New-WebServiceProxy -uri $uri -UseDefaultCredential -namespace "ReportingWebService"


#Add Logging HERE

$Datetime = (Get-Date -Format "MMddyyyy_HH_mm")
$LogFile = "PasswordFix" + "_" + $Datetime + ".txt"

Start-Transcript -Path "\\kcsan03\technology\DBA\SSRS\SSRS Move\Phase 2\Scripts\Log\$LogFile"


foreach($DS in $DSArray)
{


    Write-host "Fixing: "$DS.Path -ForegroundColor Yellow
    $dataSource = $RS.GetDataSourceContents($DS.path)[0]
    if($DS.UserName -eq "Encorr" -or $DS.UserName -eq "svcWebFocus") ## Add SQL Accounts here
    {
        #Set Credentials as SQL Accounts
        $dataSource.WindowsCredentials = $False
    }
    Else{

        #Set Credentials as Windows Accounts
        $dataSource.WindowsCredentials = $True
    }
    $dataSource.UserName = $DS.UserName
    $dataSource.Password = $DS.Password
    $RS.SetDataSourceContents($DS.Path, $dataSource)
   
}#End foreach $DS




Stop-Transcript

