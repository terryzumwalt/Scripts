﻿

import-module ReportingServicesTools



###################################
#
#    RUN IN POWERSHELL PROMPT
#
###################################




#Invoke-Command -ComputerName SQLSSRS62 {Restart-Service -Name SQLServerReportingServices} -Verbose
#Invoke-Command -ComputerName SQLSSRS61 {Restart-Service -Name ReportServer} -Verbose 



Set-Location "C:\Automation"

$Array =  "PASReports","IT","ClaimsRegister","NBUWReports"

#$Array = "PASReports"
#$Array = "Migration_Testing"
#$Array = "ClaimsRegister"
#$Array = "NBUWReports"



$Datetime = (Get-Date -Format "MMddyyyy_HH_mm")
$LogFile = "Migration" + "_" + $Datetime + ".txt"



Start-Transcript -Path "\\kcsan03\technology\DBA\SSRS\SSRS Move\Phase 2\Scripts\Log\$LogFile"



foreach($Item in $Array)
{


    $SrcRS = "http://sqlssrs01/reportserver"
    $DestRS = "http://sqlssrs02/reportserver"

    #Determine Root path for folders
    if($Item -eq "IT")
    {
        $Root = "/"
    }
    Else{

        $Root = "/Applications"
    }

    
    $path = $Item

    #Test if folder exists
    $Error.clear()
    #$ItemPath = $Root + $path
    $ItemPath = $Root + "/" + $item
    $ItemSource = "/" + $Item



    #### Test for Root folder path & Create if missing ####
    try{
        #Test for Directory on Dest
        $Test = Get-RsFolderContent -ReportServerUri $DestRS -RsFolder $ItemPath 
    }
    catch{

        If($Error)
        {
            #Create the Folder if it does not exist
            Write-Host "Creating Directory $ItemPath" -ForegroundColor Yellow            
            New-RsFolder -reportserveruri $DestRS -RsFolder $Root -foldername $Item #-ErrorAction SilentlyContinue
        }

        $Error.clear()
    }
    



    #Run Migration on a folder
    .\RS.exe -i ssrsmigration.rss -e Mgmt2010 -s $SRCRS -v f=$ItemSource -v ts=$DestRS -v tf=$ItemPath -v security="True"


}#End Foreach


Write-HOST "DISABLE JOBS on SQLSSRS02!!" -ForegroundColor yellow

stop-transcript



Set-Location "\\kcsan03\technology\DBA\SSRS\SSRS Move\Phase 2\Scripts"