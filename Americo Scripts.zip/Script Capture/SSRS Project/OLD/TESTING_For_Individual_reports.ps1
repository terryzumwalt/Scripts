﻿

Set-Location "C:\Automation"
$SrcRS = "http://sqlssrs61/reportserver"
$DestRS = "http://sqlssrs62/reportserver"

$Item = ""  #Folder
$Root = "/"         #"/"
$ItemPath = $Root + "/" + $item
$ItemSource = "/" + $Item

$Path = "/Migration_Testing/Report_02_Home_Snapshot_subscription"

Start-Transcript -Path "\\kcsan03\technology\DBA\SSRS\SSRS Move\Phase 2\Scripts\Log\Testing.txt"
#Run Migration on a folder
#.\RS.exe -i ssrsmigration.rss -e Mgmt2010 -s $SRCRS -v f=$ItemSource -v ts=$DestRS -v tf=$ItemPath -v security="True"
#.\RS.exe -i ssrsmigration.rss -e Mgmt2010 -s $SRCRS -v f=$Path -v ts=$DestRS -v tf=$Path #-v security="True"



Stop-Transcript