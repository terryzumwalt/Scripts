# Description: List SQL Server Analysis Service Role Permission By Database and Cube
# Author: Lucas Kartawidjaja
# Site: http://www.lucasnotes.com/2015/04/powershell-script-list-sql-server.html
param(
    # SSAS server name variable
    [string]$SSASServerName = "kcssas04"
)

[Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices")

$FormatEnumerationLimit = -1

# Try to connect to the SSAS server
$SSASServer = New-Object Microsoft.AnalysisServices.Server
$SSASServer.Connect($SSASServerName)

# Object to store the result
$Result = @()

# Get the SSAS databases and loop thru each of them
foreach ($DB in $SSASServer.Databases)
{
    # Get the SSAS database
    $SSASDatabase = $SSASServer.Databases.Item($DB.name)

    foreach ($Role in $SSASDatabase.Roles)
    {
        $DatabasePermission  = $DB.DatabasePermissions.GetByRole($Role.ID)

        # Get the SSAS cubes within the database
        foreach ($Cube in $DB.Cubes)
        {
            try {
                $CubePermission = $Cube.CubePermissions.GetByRole($Role.ID)
    
                $ItemResult = New-Object System.Object
                $ItemResult | Add-Member -type NoteProperty -name DatabaseName -value $DB.Name
                $ItemResult | Add-Member -type NoteProperty -name RoleName -value $Role.Name
                $ItemResult | Add-Member -type NoteProperty -name DatabaseAdministrator -value $DatabasePermission.Administer
                $ItemResult | Add-Member -type NoteProperty -name DatabaseProcess -value $DatabasePermission.Process
                $ItemResult | Add-Member -type NoteProperty -name DatabaseReadDefinition -value $DatabasePermission.ReadDefinition
                $ItemResult | Add-Member -type NoteProperty -name CubeName -value $Cube.Name
                $ItemResult | Add-Member -type NoteProperty -name CubeRead -value $CubePermission.Read.value__
                $ItemResult | Add-Member -type NoteProperty -name CubeWrite -value $CubePermission.Write.value__
                $ItemResult | Add-Member -type NoteProperty -name CubeProcess -value $CubePermission.Process
                $ItemResult | Add-Member -type NoteProperty -name CubeReadDefinition_Local -value $CubePermission.ReadDefinition.value__
                $ItemResult | Add-Member -type NoteProperty -name CubeReadSourceData_Drillthrough -value $CubePermission.ReadSourceData.value__
                $ItemResult | Add-Member -type NoteProperty -name RoleMembers -value ($Role.Members | Select -ExpandProperty Name | Out-String)
    
                $Result +=$ItemResult    
            }
            catch {
                Write-Host "$Role - $Role.ID was unable to be found"
            }
        }
    }

}

$ReportDate = $(Get-Date -f 'yyyy_MM_dd')
$ReportPath = $ReportDate + '_' + $SSASServer + '_' + 'SSASPermissions'
$ReportPath = $PSScriptRoot + '\' +$ReportPath
#Set-Content "$ReportPath.html" $HTML
#Invoke-Item "$ReportPath.html"

#$Result | Select DatabaseName, RoleName, DatabaseAdministrator, DatabaseProcess, DatabaseReadDefinition, `
#CubeName, CubeRead, CubeWrite, CubeProcess, CubeReadDefinition_Local, CubeReadSourceData_Drillthrough, RoleMembers | format-table * -Wrap -AutoSize | Out-String

$Result | Select DatabaseName, RoleName, DatabaseAdministrator, DatabaseProcess, DatabaseReadDefinition, `
CubeName, CubeRead, CubeWrite, CubeProcess, CubeReadDefinition_Local, CubeReadSourceData_Drillthrough, RoleMembers | Export-Csv -NoTypeInformation -Path "$ReportPath.csv"

Invoke-Item "$ReportPath.csv"