﻿Import-Module SQLServer

#Step 1: Get a list of SQL Servers

$SrvArray = "SQLDBA01","SQLDBA51"
$DB = "DBA_WORKDB"
$UserFilter = "tzumwalt"

$Srvlist = @()
foreach($Inst in $SrvArray)
{

    $HostList = Invoke-Sqlcmd -ServerInstance $Inst -Database $DB -Query 'Select server_name from dbo.ServerList' -TrustServerCertificate
    foreach($Item in $HostList.server_name)
    {
        $Srvlist += $Item
    }

}


Write-Host "Beginning RDP Lookup on Instances. " -ForegroundColor Green
" "
" "
$HostList = "SQLDBA51"

foreach($Srv in $HostList)
{

    if($Srv -like "SQLDBA51*"){$Srv = "SQLDBA51"}
    if($Srv -like "SQLDBA01*"){$Srv = "SQLDBA01"}

    Write-Host "Testing: "$Srv -ForegroundColor yellow
    $GetServers = Invoke-Command -ComputerName $Srv {query user} -ErrorAction SilentlyContinue

    $Array = @()
    $Result = $GetServers |Select-String $UserFilter
    if($Result)
    {
        #User Exists
        $Result = $Result -split " "
        $Result = $Result -replace " ",""
        foreach($Rslt in $Result)
        {
            if($Rslt.Length -gt 0)
            {
                $Array += $Rslt
            }
        }




        Write-Host "Dropping RDP Session On: "$Srv -ForegroundColor Gray
        $Name = $Array[0]
        $Session = $Array[2]

        $Command = "Reset Session $Session"


        #NOT WORKING
        #Invoke-Command -ComputerName $Srv -ScriptBlock {$Command} -ArgumentList $Command 
        
    }


    #Read-Host
}



