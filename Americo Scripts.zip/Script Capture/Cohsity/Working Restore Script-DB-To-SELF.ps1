﻿# To use this script please read the comments above each line

Import-Module Cohesity.PowerShell


#Connect to the Cluster (Local\TZumwalt)
Connect-CohesityCluster -Server 10.10.12.93 -Credential (Get-Credential) -MFA


###### List Restorable Objects then find what your restoring by filter ######
$RestoreList = Find-CohesityObjectsForRestore -Environments KSQL

#Find your DB List
$DBFilter = $Restorelist | Where{$_.Objectname -like "*TZTest*"}   #<--- Filter here

#Specify your DB in the array
$DB = $DBFilter[0]              #This is the array item number "if" there is more than one choice



########  Variables Needed for Restore  ######
#This is the Database ID
$SourceID = $DB.SnapshottedSource.Id

#This is the "Host" Source ID
$SourceInstanceID = $DB.SnapshottedSource.SqlProtectionSource.OwnerId
    
#JobID
$JobId = $DB.JobId

#New DBName (If your not overwriting)
$NewDB = "TZCohesityRestore"

#Create a Taks Name (Created in Cohesity for the task to run)
$TaskName = "TZTest-DB-Restore-PS"
    


#Create the Restore Job and Run it
Restore-CohesityMSSQLObject -TaskName $TaskName  -SourceId $SourceID -HostSourceId $SourceInstanceID -JobId $JobId -NewDatabaseName $NewDB -TargetDataFilesDirectory "D:\Data" -TargetLogFilesDirectory "L:\Logs"

