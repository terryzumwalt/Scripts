﻿#Open Powershell as Administrator
Install-Module -Name Cohesity.PowerShell -AllowClobber -Force

#Import the Module
Import-Module Cohesity.PowerShell

#Ensure its imported and listed
get-module -Name Cohesity.Powershell

#get the available commands from the module
get-command -Module Cohesity.PowerShell |Where-Object Name -like "*Clone*"

#Use Credentials in this config--->   americo.com\tzumwalt
Connect-CohesityCluster -Server 10.10.12.93 -Credential (Get-Credential)

#Get help with a specific Cmdlet (these are listed from get-command above)
get-help Connect-CohesityCluster -Examples



<###############################################################################################>


Import-Module Cohesity.PowerShell

#Connect to the Cluster
Connect-CohesityCluster -Server 10.10.12.194 -Credential (Get-Credential)














