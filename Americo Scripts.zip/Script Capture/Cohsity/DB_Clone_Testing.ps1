#Import the New Module
Import-Module Cohesity.PowerShell

#Connect to the Cohesity VIP and USE MFA
Connect-CohesityCluster -Server cohesity-sql.infra.local -Credential (Get-Credential) -UseMFA 









#Testing Only below
<#
-taskname "sql-clone-task1" = random name
-sourceid 2248 = Get-CohesityMSSQLObject then from particular DB object "ID"
-hostsourceid 2234 = Get-CohesityMSSQLObject then from particular DB object "parentID"
-JobId 5456 = Get-CohesityProtectionJob then from particular job which i want to clone from object "ID"
-NewDatabaseName "ClonedTest" = random name
-InstanceName "MSSQLSERVER" = instance name got from actual name
-TargetHostId 1515 = Get-CohesityMSSQLObject (again parentid of destinated host
#>


$SrcServer = "SQLDBA51"
$TargetServer = "SQLDBA51"
$DBName = "PAW"

$TaskName = "TestCloneTZ"
$NewDBName = "PAW_Clone"
$SourceID = (Get-CohesityMSSQLObject |Where-Object Name -like "*$DBName*").id
$HostSourceID = (Get-CohesityMSSQLObject |Where-Object Name -like "*$DBName*").ParentId
$TargetHostID = (Find-CohesityObjectsForRestore |Where{$_.JobName -like "*$TargetServer*" -and $_.ObjectName -like "*$DBName*"}).JobID
$JobId = (Get-CohesityProtectionJob |Where-Object Name -like "*$SrcServer*").id
$InstanceName = "MSSQLServer"


Copy-CohesityMSSQLObject -TaskName $TaskName -SourceId $SourceID -HostSourceId $HostSourceID -JobId $JobID -NewDatabaseName $NewDBName -InstanceName $InstanceName -TargetHostId $SourceID -Verbose 



<#
Get-CohesityProtectionJobRun -JobId $JobID

$TaskName
$SourceID
$HostSourceID
$JobId
$NewDBName
$InstanceName
$TargetHostID
#>
