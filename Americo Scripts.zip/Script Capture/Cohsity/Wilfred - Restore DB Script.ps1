﻿Open Powershell as Administrator
Install-Module -Name Cohesity.PowerShell -AllowClobber -Force

#Import the Module
Import-Module Cohesity.PowerShell

#Ensure its imported and listed
get-module -Name Cohesity.Powershell

#get the available commands from the module
get-command -Module Cohesity.PowerShell

#Use Credentials in this config--->   americo.com\tzumwalt
##Connect-CohesityCluster -Server 10.10.12.93 -Credential (Get-Credential)
Connect-CohesityCluster -Server 10.10.12.93 -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "Americo.com\wbalan", (ConvertTo-SecureString -AsPlainText "password here" -Force))

##Disconnect-CohesityCluster

#Find-CohesityObjectsForRestore -Search "ClaimsRegister"

.\restoreDB.ps1 -vip 10.2.100.211 -username admin -jobName SQL_KCSQL50_Default -restoreType "RESTORE-REMOTE" -targetServer 172.30.0.75 -targetInstance "MSSQLSERVER" -mdfFolder "d:\data" -ldfFolder "l:\logs" -gridViewEnabled:$true 
