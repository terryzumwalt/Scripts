﻿



#NOTE: Credentials are local\<Username>

#Install the NEW cohesity module and over write the old one
install-module Cohesity.Powershell -AllowClobber -Force

#Import the New Module
Import-Module Cohesity.PowerShell

#Connect to the Cohesity VIP and USE MFA
Connect-CohesityCluster -Server cohesity-sql.infra.local -Credential (Get-Credential) -UseMFA 


