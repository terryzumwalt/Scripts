﻿#install-module cohesity.powershell -force


#Open Powershell as Administrator
#Install-Module -Name Cohesity.PowerShell -AllowClobber -Force

#Import the Module
Import-Module Cohesity.PowerShell

#Ensure its imported and listed
get-module -Name Cohesity.Powershell

#get the available commands from the module
get-command -Module Cohesity.PowerShell

#Use Credentials in this config--->   americo.com\tzumwalt
Connect-CohesityCluster -Server 10.10.12.93 -Credential (Get-Credential)
#################################################################################

#https://cohesity.github.io/cohesity-powershell-module/#/cmdlets-reference/restore-cohesitymssqlobject?id=restore-cohesitymssqlobject

<#
INFO

Source ID = "Database ID"
HostSourceID = "database Instance ID"
JobID = "Job ID"
#>




###### List Restorable Objects then find what your restoring by filter ######
$RestoreList = Find-CohesityObjectsForRestore -Environments KSQL

#Find your DB List
$DBFilter = $Restorelist | Where{$_.Objectname -like "*TZTest*"}   #<--- Filter here

#Specify your DB in the array
$DB = $DBFilter[0]              #This is the array item number "if" there is more than one choice



########  Variables Needed for Restore  ######
#This is the Database ID
$SourceID = $DB.SnapshottedSource.Id

#This is the "Host" Source ID
$SourceInstanceID = $DB.SnapshottedSource.SqlProtectionSource.OwnerId
    
#JobID
$JobId = $DB.JobId

#New DBName (If your not overwriting)
$NewDB = "TZCohesityRestore"

#Create a Taks Name (Created in Cohesity for the task to run)
$TaskName = "TZTest-DB-Restore-PS"
    


#Create the Restore Job and Run it
Restore-CohesityMSSQLObject -TaskName $TaskName  -SourceId $SourceID -HostSourceId $SourceInstanceID -JobId $JobId -NewDatabaseName $NewDB -TargetDataFilesDirectory "D:\Data" -TargetLogFilesDirectory "L:\Logs"

