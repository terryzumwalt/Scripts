﻿# To use this script please read the comments above each line

Import-Module Cohesity.PowerShell

#Connect to the Cluster
Connect-CohesityCluster -Server 10.10.12.93 -Credential (Get-Credential)
############################################################################
#############################################################################


#DB you want to restore
$DBName = "MSSQLSERVER/TZTestDB"

#Source Server
$SrcServer = "SQLDBA51"

#Dest Server
$DestServer = "sqlsandbox71"


#############################################################################
###### List Restorable Objects then find what your restoring by filter ######
$RestoreList = Find-CohesityObjectsForRestore -Environments KSQL

#Find your DB List
$DBFilter = $Restorelist | Where{$_.Objectname -eq $DBName -and $_.JobName -like "*$SrcServer*"}
$DBFilter

#Specify your DB in the array
$DB = $DBFilter[0]              #This is the array item number "if" there is more than one choice

################################################################################
###### Find Destination Server ID ##############################################
$DestServerID = $RestoreList | Where{$_.JobName -like "*$DestServer*"}
$DestServerID = $DestServerID[0]
$DestServerID
$DestServerID = $DestServerID.SnapshottedSource.SqlProtectionSource.OwnerId
$DestServerID



########  Variables Needed for Restore  ######
#This is the Database ID
$SourceID = $DB.SnapshottedSource.Id

#This is the "Host" Source ID
$SourceInstanceID = $DB.SnapshottedSource.SqlProtectionSource.OwnerId
    
#JobID
$JobId = $DB.JobId

#New DBName (If your not overwriting)
$NewDB = "TZCohesityRestore"

#Create a Taks Name (Created in Cohesity for the task to run)
$TaskName = "TZTest-DB-Restore-PS"

#Instance Name on Target Server
$NewInstanceName = "MSSQLSERVER"
    

#### List Each File / Directory with ndf by name or using a *. #####
$patternList = @()
$pattern = [Cohesity.Model.FilenamePatternToDirectory]::new()
$pattern.Directory = "I:\Indexes"
$pattern.FilenamePattern = "*x_01.ndf"  #you cant use the filename you have to use * to identify (They will be renamed)
$patternList += $pattern

$patternList2 = @()
$pattern2 = [Cohesity.Model.FilenamePatternToDirectory]::new()
$pattern2.Directory = "D:\Data"
$pattern2.FilenamePattern = "*a_01.ndf"  #you cant use the filename you have to use * to identify (Then will be renamed)
$patternList += $pattern2


#Create the Restore Job and Run it
#Restore-CohesityMSSQLObject -TaskName $TaskName  -SourceId $SourceID -HostSourceId $SourceInstanceID -JobId $JobId -TargetHostId $DestServerID -NewDatabaseName $NewDB -NewInstanceName $NewInstanceName  -TargetDataFilesDirectory "D:\Data" -TargetLogFilesDirectory "L:\Logs" -TargetSecondaryDataFilesDirectoryList $patternList -Confirm:$false




