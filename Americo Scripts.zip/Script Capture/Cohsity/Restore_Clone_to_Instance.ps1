#Import the New Module
Import-Module Cohesity.PowerShell

#Connect to the Cohesity VIP and USE MFA
Connect-CohesityCluster -Server cohesity-sql.infra.local -Credential (Get-Credential) -UseMFA 

<###################### Begin Restore ########################################>
#DB you want to restore
$DBName = "PAW"
$ObjName = "MSSQLSERVER/$DBName"

#Source Server
$SrcServer = "SQLDBA51"

#Dest Server
$DestServer = "SQLDBA51"

#Find the database you are looking to clone and list its info
$RestoreList = Find-CohesityObjectsForRestore -Environments KSQL
$RestoreList = $RestoreList| Where-object {$_.JobName -like "*$SrcServer*"  -and $_.ObjectName -eq $ObjName}
$RestoreList
#Ensure you only have one choice
$RestoreList = $RestoreList[0]

<###############################################################################>


$JobName = $RestoreList.JobName
$SourceID = (Get-CohesityMSSQLObject |Where-Object Name -like "*$DBName*").NasProtectionSource

Restore-CohesityBackupToView -SourceName $SrcServer -TargetViewName $DestServer -ProtectionJobName $JobName -Verbose
#Restore-CohesityBackupToView [[-SourceName] <Object>] [-TargetViewName] <String> [[-QOSPolicy] <String>] [-ProtectionJobName] <String> [<CommonParameters>]

#Get-CohesityQOSPolicy |Format-table

#Remove-CohesityClone -TaskId <TaskIDNumber that Created the Clone>

<###############################################################################>





