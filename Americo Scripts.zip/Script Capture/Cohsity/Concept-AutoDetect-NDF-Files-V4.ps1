﻿# To use this script please read the comments above each line

Import-Module Cohesity.PowerShell

#Connect to the Cluster
#Connect-CohesityCluster -Server 10.10.12.93 -Credential (Get-Credential)
############################################################################
#############################################################################


#DB you want to restore
$DBName = "MSSQLSERVER/TZTestDB"

#Source Server
$SrcServer = "SQLDBA51"

#Dest Server
$DestServer = "sqlsandbox71"


#############################################################################
###### List Restorable Objects then find what your restoring by filter ######
$RestoreList = Find-CohesityObjectsForRestore -Environments KSQL

#Find your DB List
$DBFilter = $Restorelist | Where{$_.Objectname -eq $DBName -and $_.JobName -like "*$SrcServer*"}
$DBFilter

#Specify your DB in the array
$DB = $DBFilter[0]              #This is the array item number "if" there is more than one choice

################################################################################
###### Find Destination Server ID ##############################################
$DestServerID = $RestoreList | Where{$_.JobName -like "*$DestServer*"}
$DestServerID = $DestServerID[0]
$DestServerID
$DestServerID = $DestServerID.SnapshottedSource.SqlProtectionSource.OwnerId
$DestServerID



########  Variables Needed for Restore  ######
#This is the Database ID
$SourceID = $DB.SnapshottedSource.Id

#This is the "Host" Source ID
$SourceInstanceID = $DB.SnapshottedSource.SqlProtectionSource.OwnerId
    
#JobID
$JobId = $DB.JobId

#New DBName (If your not overwriting)
$NewDB = "TZCohesityRestore"

#Create a Taks Name (Created in Cohesity for the task to run)
$TaskName = "TZTest-DB-Restore-PS"

#Instance Name on Target Server
$NewInstanceName = "MSSQLSERVER"

#######################################################################################################################
###### Begin Checking for NDF Files ###################################################################################   
#Get database name
$QDB = $DBName -split"/"
$QDB = $QDB[1]

#Query DB on Source for Physical Files
$FileQuery = @"
    SELECT 
      name 'Logical Name', 
      physical_name 'File Location'
    FROM sys.database_files
"@
$PhysicalFiles = Invoke-Sqlcmd -ServerInstance $SrcServer -Database $QDB -Query $FileQuery

#Filter the Files for NDF Files
$NDF = $PhysicalFiles | where{$_.'File Location' -like "*.ndf"}

#Test for NDF Files
if($NDF.count -gt 0)
{
    $PatternList = @()
    $pattern = [Cohesity.Model.FilenamePatternToDirectory]::new()
    $pattern.Directory = "HH"
    $Pattern.FilenamePattern = "HH"
    $patternList += $pattern

    $i = 1
    foreach($File in $NDF)
    {
        $Filter1 = $File.'File Location'
        $Filter2 = $Filter1.Split("\")
        $FilterCount = $Filter2.count
        
        $Directory = $Filter2[0] + "\" + $Filter2[1]
        $FileNamePattern = $Filter2[($FilterCount - 1)] 

        #Create information for the backup file
        $pattern2 = [Cohesity.Model.FilenamePatternToDirectory]::new()
        $pattern2.Directory =  $Directory
        $pattern2.FilenamePattern =  "*$FileNamePattern"
        $patternList += $pattern2

        $i = $i + 1       

    }#End foreach $File

    $patternList = $PatternList |Where{$_.Directory -ne "HH"}

}#End if $NDF

Write-host $NDF.count

########################################################################################################################
########################################################################################################################

#Create the Restore Job and Run it

if($NDF.Count -gt 0)
{
    Restore-CohesityMSSQLObject -TaskName $TaskName  -SourceId $SourceID -HostSourceId $SourceInstanceID -JobId $JobId -TargetHostId $DestServerID -NewDatabaseName $NewDB -NewInstanceName $NewInstanceName  -TargetDataFilesDirectory "D:\Data" -TargetLogFilesDirectory "L:\Logs" -TargetSecondaryDataFilesDirectoryList $patternList
    Write-Host "NDF Files Detected"
}
if($NDF.Count -le 0)
{
    #Restore-CohesityMSSQLObject -TaskName $TaskName  -SourceId $SourceID -HostSourceId $SourceInstanceID -JobId $JobId -TargetHostId $DestServerID -NewDatabaseName $NewDB -NewInstanceName $NewInstanceName  -TargetDataFilesDirectory "D:\Data" -TargetLogFilesDirectory "L:\Logs" 
   Write-host "NO NDF Files Detected"
}






