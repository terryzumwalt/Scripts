﻿
//Actual script is on SQLSSRS61 > Desktop



#SQLSSRS61 to SQLSSRS62

#ClaimsRegister, NBUWReports, and PASReports are the folders on 61 that seem to parallel what we're running on '01.


RS.exe is located at  C:\Program Files (x86)\Microsoft SQL Server\130\Tools\Binn

#Powershell info
https://blogs.infosupport.com/managing-ssrs-reports-with-powershell/




#Reporting Services Rs.exe script
https://learn.microsoft.com/en-us/sql/reporting-services/tools/sample-reporting-services-rs-exe-script-to-copy-content-between-report-servers?view=sql-server-ver16


#Wilfred (use of Rs.exe)
#rs.exe -i d:\data\backup\ssrs_migration.rss -e Mgmt2010 -s http://sqlssrs71/reportserver -v f="/PASReports" -v ts=http://sqlssrs61/reportserver -v tf="/PASReports"

######## COPY OF THE SCRIPT ###############







<#

NOTE: A better version is on the VDI under tzumwalty-db >Desktop

#>

import-module reportservertools


Set-Location "C:\Program Files (x86)\Microsoft SQL Server\130\Tools\Binn"


#1. Connect to Instance is IF the ROOT folder (/Foldername) is not there, Create it. 
#2. Pipe output of script in to Log
#3.

Set-Location -Path "C:\Program Files (x86)\Microsoft SQL Server\130\Tools\Binn"

###################################################################################################
$RS = "http://sqlssrs62/reportserver"
$Root = "/"
$path = "ClaimsRegister"



#Create the Folder if it does not exist
New-RsFolder -reportserveruri $RS -RsFolder $Root -foldername $Path -ErrorAction SilentlyContinue
###################################################################################################


#Run Migration on a folder
rs.exe -i C:\SQL\Automation\ssrs_migration.rss -e Mgmt2010 -s http://sqlssrs61/reportserver -v f="/ClaimsRegister" -v ts=http://sqlssrs62/reportserver -v tf="/ClaimsRegister"
