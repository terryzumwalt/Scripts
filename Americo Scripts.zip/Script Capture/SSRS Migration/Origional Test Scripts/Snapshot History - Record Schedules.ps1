﻿
<#

    Table Script: Table-SnapShotHistSchedule.sql
    Table Insert Script: Table insert - SnapShotHistSchedule.sql
#>

import-Module ReportingServicesTools


$URI ='http://SQLDBA51/reportserver/ReportService2010.asmx'
$RS =  New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential; 
$Reports = $RS.ListChildren("/",$True) | Where-Object{$_.TypeName -eq "Report"}


$Reports = $Reports | where{$_.path -like "*TZ*"}
######################################################

$Reports = $Reports[1]


foreach($RPT in $Reports)
{
    $DBWorks = "SQLDBA51"
    $HistDB = "DBA_WorkDB"
    $HistTable = "SnapShotHistSchedule"
    $RPTPath = $RPT.Path

    $HistQuery = @"
    
    select * from dbo.$HistTable where Path = '$RPTPath'
"@

    #########################################################
    ### Query to get the Report Snapshot History Schedule ###
    Try
    {
        $Schedule = Invoke-Sqlcmd -ServerInstance $DBWorks -Database $HistDB -Query $HistQuery
    }
    Catch
    {
        Write-host $RPT.Path "NOT FOUND" -ForegroundColor Yellow
        Read-host "Please correct the issue and press enter to continue..."
    }
    Finally{}


    #############################################################
    ### Build the Schedule to be implemented ####################

    if($Schedule.'Recurrence Type' = "Hourly")
    {

        #Buid Schedule
        $definition = New-Object RS.ScheduleDefinition
        $scheduleID = " "
        $definition.StartDateTime =  $Schedule.StartDate
        if(($Schedule.EndDate).length -gt 1){$definition.EndDate = $Schedule.EndDate}
        $recurrence  = New-Object RS.MinuteRecurrence
        $recurrence.MinutesInterval = $Schedule.'Run every (Hours)'
        $definition.Item = $recurrence

        #### Enable and Turn on Schedule ####
        $KeepExecutionSnapshots = $True
        $EnableManualSnapshotCreation = $True
        #$RS.setItemHistoryOptions($Reports.path,[ref]$EnableManualSnapshotCreation,[ref]$KeepExecutionSnapshots,$ScheduleDefinitionOrReference)
        $RS.setItemHistoryOptions($RPT.path,[ref]$EnableManualSnapshotCreation,[ref]$KeepExecutionSnapshots,$definition)

 
    }#End IF Hourly
    if($Schedule.'Recurrence Type' = "Daily")
    {
        $definition = New-Object RS.ScheduleDefinition
        $scheduleID = " "
        $definition.StartDateTime = $Schedule.StartDate
        if(($Schedule.EndDate).length -gt 1){$definition.EndDate = $Schedule.EndDate}
        $recurrence = New-Object RS.DailyRecurrence
        $recurrence.DaysInterval = $Schedule.'Runs Every (Days)'
        $definition.Item = $recurrence


        #### Enable and Turn on Schedule ####
        $KeepExecutionSnapshots = $True
        $EnableManualSnapshotCreation = $True
        #$RS.setItemHistoryOptions($Reports.path,[ref]$EnableManualSnapshotCreation,[ref]$KeepExecutionSnapshots,$ScheduleDefinitionOrReference)
        $RS.setItemHistoryOptions($RPT.path,[ref]$EnableManualSnapshotCreation,[ref]$KeepExecutionSnapshots,$definition)

    
    }#End If Daily

    if($Schedule.'Recurrence Type' = "Weekly")
    {
        $definition = New-Object RS.ScheduleDefinition
        $scheduleID = " "
        $definition.StartDateTime = $Schedule.StartDate
        $recurrence = New-Object RS.WeeklyRecurrence
        $recurrence.WeeksInterval = $Schedule.'Runs Every (Weeks)'
        $recurrence.WeeksIntervalSpecified = $TRUE
        $DaysofWeekSelector = New-Object RS.DaysOfWeekSelector


        #Array the Days for the schedule
        $DayArray = $Schedule.'Runs Every (Week Days)'
        $DayArray = $DayArray -split ","

        #Capture the days in the Object
        if($DayArray -contains "mon"){$DaysofWeekSelector.Monday = $True}
        if($DayArray -contains "tue"){$DaysofWeekSelector.Tuesday = $True}
        if($DayArray -contains "wed"){$DaysofWeekSelector.Wednesday = $True}
        if($DayArray -contains "thu"){$DaysofWeekSelector.Thursday = $True}
        if($DayArray -contains "fri"){$DaysofWeekSelector.Friday = $True}
        if($DayArray -contains "sat"){$DaysofWeekSelector.Saturday = $True}
        if($DayArray -contains "sun"){$DaysofWeekSelector.Sunday = $True}
        

        #Set the Days of week to the Schedule
        $recurrence.DaysOfWeek = $DaysofWeekSelector
      
        $definition.Item = $recurrence
        $definition | format-list


        #### Enable and Set on Schedule ####
        $KeepExecutionSnapshots = $True
        $EnableManualSnapshotCreation = $False
        $RS.setItemHistoryOptions($RPT.path,[ref]$EnableManualSnapshotCreation,[ref]$KeepExecutionSnapshots,$definition)
        
    
    }
    if($Schedule.'Recurrence Type' = "Monthly")
    {
        $definition = New-Object RS.ScheduleDefinition
        $scheduleID = " "
        $definition.StartDateTime = $Schedule.StartDate
        $recurrence = New-Object RS.MonthlyRecurrence
        

        $MonthsOfYearSelector =  New-Object RS.MonthsOfYearSelector
        $Months = $Schedule.'Runs Every (Runs every Month)'
        $Months = $Months -split ","
        if($Months -contains "Jan"){$MonthsOfYearSelector.January = $True}
        if($Months -contains "Feb"){$MonthsOfYearSelector.February = $True}
        if($Months -contains "Mar"){$MonthsOfYearSelector.March = $True}
        if($Months -contains "Apr"){$MonthsOfYearSelector.April = $True}
        if($Months -contains "May"){$MonthsOfYearSelector.May = $True}
        if($Months -contains "Jun"){$MonthsOfYearSelector.June = $True}
        if($Months -contains "Jul"){$MonthsOfYearSelector.July = $True}
        if($Months -contains "Aug"){$MonthsOfYearSelector.August = $True}
        if($Months -contains "Sep"){$MonthsOfYearSelector.September = $True}
        if($Months -contains "Oct"){$MonthsOfYearSelector.October = $True}
        if($Months -contains "Nov"){$MonthsOfYearSelector.November = $True}
        if($Months -contains "Dec"){$MonthsOfYearSelector.December = $True}

        $recurrence.MonthsOfYear = $MonthsOfYearSelector



        ###################################


        #if($Schedule.'Runs Every (Calendar Days)'){$recurrence.Days = $Schedule.'Runs Every (Calendar Days)'}
        #if($Schedule.'Runs Every (Week of Month)'){$recurrence.Days = $Schedule.'Runs Every (Week of Month)'}
        $recurrence.days = 
        



        ####################################




        $definition.Item = $recurrence
        $definition | format-list


        #### Enable and Set on Schedule ####
        $KeepExecutionSnapshots = $True
        $EnableManualSnapshotCreation = $False
        $RS.setItemHistoryOptions($RPT.path,[ref]$EnableManualSnapshotCreation,[ref]$KeepExecutionSnapshots,$definition)
        

    }#End if Monthly


    $Schedule



}#End Foreach $RPT





