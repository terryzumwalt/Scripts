﻿#Below are two methods for updating the Datasource Username and Password. 
# Method 1 - Input just one Datasource that can be changed to itterate through a list as required.
# Method 2 - Reads the report server for all datasources and can mass apply. In this example I have limmited this range to one source.
#Note: Passwords that start with numbers will have to be delt with differently. Passing a string works well.


##################################################################
#Change Credentials for Datasource Method 1
$Datasource = Get-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -path '/Reports_Test_Migration/T1_SSRS/T1_SSRS_DataSource/T1_DS_Folder'
$Datasource.WindowsCredentials = $FALSE
$Datasource.CredentialRetrieval = "Store"
$Datasource.Extension = "SQL"
$Datasource.UserName = "ssrsreader"
$Datasource.Password = "<PASSWORDHERE>"
Set-RsDataSource -RsItem /Reports_Test_Migration/T1_SSRS/T1_SSRS_DataSource/T1_DS_Folder -DataSourceDefinition $Datasource -ReportServerUri 'http://SQLDBA51/Reportserver' -Verbose



#############################################
#Change Credentials for Datasource Method 2
$ReportingServer = "SQLDBA51"
$userName = "ssrsreader"
$password = "<PASSWORDHERE>" #UpdatedPassword
#$uri = "http://{0}/ReportServer/ReportService2010.asmx?WSDL" -f $ReportingServer
$uri = "http://sqldba51/reportserver/ReportService2010.asmx"

$reporting = New-WebServiceProxy -uri $uri -UseDefaultCredential -namespace "ReportingWebService"
$DataSources = $reporting.ListChildren('/', $true) | Where-Object {$_.TypeName -eq "DataSource"}

#This will filter for a specific test path
$DSList = $DataSources | where {$_.Path -like "*TZ*"}
$DSList = $DSList[1]  #Only TZTestDS

foreach($Object in $DSList) {
  $dataSource = $reporting.GetDataSourceContents($Object.path)[0]
  $Verify = $datasource.UserName
  if ($Verify -eq $userName) {
    $dataSource.WindowsCredentials = $FALSE
    $dataSource.UserName = $userName
    $dataSource.Password = $password
    $reporting.SetDataSourceContents($Object.Path, $dataSource)
  }
}

