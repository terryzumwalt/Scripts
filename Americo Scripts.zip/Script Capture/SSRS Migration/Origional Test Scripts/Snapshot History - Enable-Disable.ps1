﻿


$URI ='http://SQLDBA51/reportserver/ReportService2010.asmx'
$RS =  New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential; 
$Reports = $RS.ListChildren("/",$True) | Where-Object{$_.TypeName -eq "Report"}


$Reports = $Reports | where{$_.path -like "*TZ*"}
$Reports = $Reports[0]
####################################################################################################

#### LIST SnapShot Schedule ####
$KeepExecutionSnapshots = $false
$ScheduleDefinitionOrReference = New-Object RS.ScheduleDefinitionOrReference
$RS.GetItemHistoryOptions($Reports.path,[ref]$KeepExecutionSnapshots,[ref]$ScheduleDefinitionOrReference)

$ScheduleDefinitionOrReference | format-list 

#If Week is selected these are not NULL
$ScheduleDefinitionOrReference.Item.DaysOfWeek
$ScheduleDefinitionOrReference.Item.WeeksInterval
$ScheduleDefinitionOrReference.Item.WeeksIntervalSpecified
###################################
###################################




#### TURN OFF SnapShots (Leave Manual Enabled) #####
#-- ONCE OFF THE SCHEDULE IS GONE FROM DB --
$KeepExecutionSnapshots = $false
$EnableManualSnapshotCreation = $true
$RS.setItemHistoryOptions($Reports.path,[ref]$EnableManualSnapshotCreation,[ref]$KeepExecutionSnapshots,$NULL)
#########################################


###### Create a Schedule #######
$definition = New-Object RS.ScheduleDefinition
$scheduleID = ""
$definition.StartDateTime =  [DateTime] "03/03/2022 12:00:00 AM"
$recurrence = New-Object RS.DailyRecurrence
$recurrence.DaysInterval = 1
$definition.Item = $recurrence



####  Turn On SnapShot Schedule  #### (This uses the Schedule captured in "List SnapShot Schedules")
$KeepExecutionSnapshots = $True
$EnableManualSnapshotCreation = $True
#$RS.setItemHistoryOptions($Reports.path,[ref]$EnableManualSnapshotCreation,[ref]$KeepExecutionSnapshots,$ScheduleDefinitionOrReference)
$RS.setItemHistoryOptions($Reports.path,[ref]$EnableManualSnapshotCreation,[ref]$KeepExecutionSnapshots,$definition)




#################################################






