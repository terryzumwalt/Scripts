﻿Import-Module ReportingServicesTools


$DestURI = 'http://SQLDBA51/Reportserver'
#$SrcURI = 'http://KCSSRS71/Reportserver'
$DestAlt = "http://sqldba51/reportserver/ReportService2010.asmx"



####### Microsoft Method 1 - Individual Subscriptions ##########
#list all subscriptions  
$rs2010 = New-WebServiceProxy -Uri $DestAlt -Namespace SSRS.ReportingService2010 -UseDefaultCredential;  
$subscriptions = $rs2010.ListSubscriptions("/");  
$SubID = $Subscriptions[0].SubscriptionID

#disable specific subscription  
$rs2010.DisableSubscription($SubID);
$subscription | select subscriptionid, report, path

#Enable specific Subscription
$rs2010.EnableSubscription($SubID);
$subscription | select subscriptionid, report, path
#####################################################






####### Microsoft Method 2 - All Subscriptions ##########
#All subscriptions  
$rs2010 = New-WebServiceProxy -Uri $DestAlt -Namespace SSRS.ReportingService2010 -UseDefaultCredential;  
$subscriptions = $rs2010.ListSubscriptions("/Reports_Test_Migration/T1_SSRS") ;  

#Disable All Subscriptions
ForEach ($subscription in $subscriptions)  
{  
    $rs2010.DisableSubscription($subscription.SubscriptionID);  
    $subscription | select subscriptionid, report, path  
}  


#Enable All Subscriptions
ForEach ($subscription in $subscriptions)
{
    $rs2010.EnableSubscription($subscription.SubscriptionID);  
    $subscription | select subscriptionid, report, path  
   
}
