USE DBA_WorkDB

CREATE TABLE dbo.SSRSAuthPermissionsPS
(
	ROW_ID BIGINT IDENTITY(1,1) NOT NULL,
	ReportFolder NVARCHAR(200),
	UserName NVARCHAR(50),
	VIEWER NVARCHAR(10),
	Modify NVARCHAR(10),
	Browser NVARCHAR(50),
	ReportBuilder NVARCHAR(30),
	Publisher NVARCHAR(30),
	ManageAllSubscriptoins NVARCHAR(50),
	MyReports NVARCHAR(20),
	ContentManager NVARCHAR(30)

);