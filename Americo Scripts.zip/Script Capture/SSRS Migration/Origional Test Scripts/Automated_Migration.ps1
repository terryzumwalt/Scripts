﻿#This script is designed to automate fixes for the KCSSRS71 Demo Migration
#As a test this script does not Autodetect, Test or Audit for functionality
#This is only for fixing what we are aware is broken


#Import the SSRS Module for Powershell if its not already
$Module = get-module | where {$_.Name -eq "reportingservicestools"}
if($Module.ModuleType -ne "Script") {import-module reportingservicestools}


#Fix DataSources
Function fixDatasources
{
    #Here I will fix the credentials in most datasources
    #Then i will replicate the missing datasource from KCSSRS71

    ###### Begin Fixing Datasources Credentials #########
    Write-Host "Fixing Datasources with Credential issues." -ForegroundColor Yellow
    #Fetch a list of DS Paths
    $DSPaths = Get-Content "Y:\Scripts\DSPaths.txt" #List of Paths to datasources that exist
    $DSFixPath = Get-Content "Y:\Scripts\DSFix.txt" #List of Known Missing DataSources or Sources to Check

    #Variables
    $DestURI = 'http://SQLDBA51/Reportserver'
    $SrcURI = 'http://KCSSRS71/Reportserver'

    #Change Credentials for Datasource Method 1
    foreach($Path in $DSPaths)
    {
        $Datasource = Get-RsDataSource -ReportServerUri $DestURI -path $Path
        $Datasource.WindowsCredentials = $FALSE
        $Datasource.CredentialRetrieval = "Store"
        $Datasource.Extension = "SQL"
        $Datasource.UserName = "ssrsreader"
        $Datasource.Password = "P0werR3nger"
        Set-RsDataSource -RsItem $Path -DataSourceDefinition $Datasource -ReportServerUri $DestURI -Verbose
    }#End Foreach $Path
    Write-Host "COMPLETE - Datasource Credentials Set." -ForegroundColor Yellow



    ###### Begin Replicating Missing Datasources and fixing Credentials #####
    Write-Host "Fixing Datasources if they are missing." -ForegroundColor Yellow

    foreach($FixPath in $DSFixPath)
    {
        #Fetch the Datasource from the Source and read the variables
        $Datasource = Get-RsDataSource -ReportServerUri $SrcUri -path $FixPath
        $DSConnectString = $Datasource.ConnectString
        $DSUserName = "ssrsreader"
        $DSCredentialRetrieval = "None"
        $DSExtension = $Datasource.Extension

        #Fetch the DatasourceS name from the Path
        $Name1 = $FixPath -split "/"
        $NameCT = $Name1.count -1
        $Name = $Name1[$NameCT]

        #Fetch the Path to the Datasource with out the datasource name
        $Remove = "/" + $Name
        $DSPath1 = $FixPath -replace $Remove, ""
        $DSPath = $DSPath1.Trim()

        $Error.Clear()
        #Test if Datasource Exists
        $DatasourceFix = Get-RsDataSource -ReportServerUri $DestURI -path $FixPath -ErrorAction SilentlyContinue
        #If DataSource is missing, replicate it from the SourceServer
        if($DatasourceFix.ConnectString -eq $NULL -or $Error)
        {
            Write-Host "Replicating: "$Name -ForegroundColor Yellow
            New-RsDataSource -ReportServerUri $DestURI -RsFolder $DSPath -Name $Name -Extension $DSExtension -ConnectionString $DSConnectString -CredentialRetrieval $DSCredentialRetrieval
        }#End if $DatasourceFix

        $Datasource = Get-RsDataSource -ReportServerUri $DestURI -path $FixPath
        $Datasource.WindowsCredentials = $FALSE
        $Datasource.CredentialRetrieval = "Store"
        $Datasource.Extension = "SQL"
        $Datasource.UserName = "ssrsreader"
        $Datasource.Password = "P0werR3nger"
        Set-RsDataSource -RsItem $FixPath -DataSourceDefinition $Datasource -ReportServerUri $DestURI -Verbose


    }#End Foreach $FixPath

    Write-Host "Fixing Datasources - Complete." -ForegroundColor Yellow



}#End Function fixDatasources

Function fixReports
{
    ###### Begin Fixing Report Credentials #########
    Write-Host "Fixing Reports with Credential issues." -ForegroundColor Yellow
    #Fetch a list of DS Paths

    $RPTFix = Get-Content "Y:\Scripts\BrokenReports.txt"

    #Variables
    $DestURI = 'http://SQLDBA51/Reports'
    $SrcURI = 'http://KCSSRS71/Reports'
    $Log = "Y:\Scripts\ErrorItems.txt"

    foreach($Report in $RPTFix)
    { $Report = $RPTFIX[0]
       Write-host "Beginning" $Report -ForegroundColor Yellow
       $SrcReport = Get-RsItemDataSource -RsItem $Report -ReportServerUri 'http://KCSSRS71/Reportserver'
       $Outcome = $SrcReport.item
       if($Outcome.Extension)
       {
            Write-Host "Setting Credentials.." -ForegroundColor Yellow
            $dataSources = Get-RsRestItemDataSource -RsItem $Report -ReportPortalUri $DestURI
            $dataSources.ConnectionString = $SrcReport.Item.ConnectString
            $dataSources.CredentialsInServer.UseAsWindowsCredentials = $False
            $dataSources.CredentialsInServer.UserName = "ssrsreader"
            $dataSources.CredentialsInServer.Password = "P0werR3nger"
            Set-RsRestItemDataSource -RsItem $Report -RsItemType 'Report' -DataSources $dataSources -ReportPortalUri $DestURI 

       }#End if $Outcome
       if(!$outcome.extension)
       {
            Write-Host "Unable to Build the object for " $Report -ForegroundColor Red
            Write-Host "Logging Item Issue"
            "Report Password issue: $Report" | Out-file $Log -Append
       }#End IF !$Outcome
       $SrcReport = $NULL
    }#End Foreach Report  
}#End Function fixReports




### Action Script ###
fixDatasources
fixReports
