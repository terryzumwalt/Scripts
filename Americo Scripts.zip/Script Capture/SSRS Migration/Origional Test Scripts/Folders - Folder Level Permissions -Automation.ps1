﻿
#https://www.sqlshack.com/managing-ssrs-security-using-powershell-automation-scripts/
# The function gets its $Global variables from the script below it. 
# The Script looks at the source server, grabs a $GLobal:folder loops users ($Global:User) and loops that users roles($Global:Role)
# Then the function applies the global variables in a loop as its referenced in $ROLES

#NOTE: Find ($DestFolderList) and remove the filter *TZ*


Function addPolicies{

    ################################################################
    ##### Set Destination Server ###################################

    #Specify the URI
    $Desturi = "http://sqldba51/reportserver/ReportService2010.asmx"

    #Create WebProxy(Connection to SSRS Server and Data)
    $DESTsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
    $type = $DESTsvc.GetType().Namespace;

    $DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder" -and $_.Path -like "*TZ*"}
    ###################################################################

    ## Reset Policy ##
    $Policies = $Destsvc.GetPolicies( $Global:Folder.path, [ref] $InheritParent )




    ## General Info for objects ##
    $GroupUserName = "$Global:User"
    $policyType = "{0}.Policy" -f $type;
    $roleType = "{0}.Role" -f $type;
    #$RoleName = "$Global:Role"

    #Add the New Policy
    $Policy = New-Object ($policyType)
    $Policy.GroupUserName = $GroupUserName
    $Policy.Roles = @()
    #
    #Add new User to Policy
    $Policies += $Policy

    foreach($RoleName in $Global:Role)
    {
        #Add Roles to the new Policy (If they dont exist)
        $R = $policy.Roles | Where-object {$_.Name -eq $RoleName} | Select-Object -First 1
        if(-not $R)
        {
            $r = New-Object ($roleType)          
            $r.Name = $RoleName
            $Policy.Roles += $r
        
        }#End -not $r
    }#End Foreach $RoleName

    #Set The Policy
    $DESTsvc.SetPolicies($Folder.Path, $Policies);



    $Global:Folder
    $Global:User
    $Global:Role

}#End Function addPolicies






###############################################################
##### Query Source Server for Folder List #####

#Specify the URI
$SRCuri = "http://KCSSRS71/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$SRCsvc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
#$SRCtype = $SrcSvc.GetType().Namespace;

$SRCFolderList = $SRCsvc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder" -and $_.Path -like "*TZ*"}


######################################################################


##### Gather folders and permissions from Source #####
$FolderList = $SRCFolderList

foreach($Folder in $FolderList)
{
    #Create Global Var for Folder
    $Global:Folder = $Folder

    $InheritParent = $true
    $SRCPolicies = $Srcsvc.GetPolicies( $folder.path, [ref] $InheritParent )
    
    #$SrcPolicies = $SRCPolicies[2]

    #Loop Users and Roles in to a Variable and send to Function
    foreach($UN in $SRCPolicies)
    {
        $Global:User = $UN.GroupUserName

        $Global:Role = ($UN.Roles).name
        addPolicies
        
    }#End Foreach $User


    
}#End Foreach $Folder




