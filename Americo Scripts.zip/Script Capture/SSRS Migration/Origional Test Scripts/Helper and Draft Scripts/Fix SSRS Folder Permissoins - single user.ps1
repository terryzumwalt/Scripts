﻿    Import-Module sqlserver
    
    
    ################################################################
    ##### Set Destination Server ###################################

    #Specify the URI
    #$uri = "http://sqlssrs62/reportserver/ReportService2010.asmx"
    $uri = "http://kcssas71/reportserver/ReportService2010.asmx"


    #Create WebProxy(Connection to SSRS Server and Data)
    $svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
    $type = $svc.GetType().Namespace;

    $DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder" -and $_.Path -like "*Business and Implementation Support*"}


    ## FILTER FOR SINGLE FOLDER ##
    $DestFolderList = $DestFolderList[0]


    #####################################################################
    $InheritParent = $true
    $GroupUserName = "KCDOM01\tzumwalt"
    $RoleName = 'Content Manager'
    $policyType = "{0}.Policy" -f $type;
    $roleType = "{0}.Role" -f $type;

    foreach($Folder in $DestFolderList)
    {
        $Policies = $svc.GetPolicies($Folder.Path, [ref]$InheritParent)
        

        if($InheritParent -eq $False)
        {
            Write-host "Made it to: " $Folder.Path -ForegroundColor yellow
            $policy = $Policies | Where-Object { $_.GroupUserName -eq $GroupUserName } | Select-Object -First 1
            

            if(-not $policy)
            {
                $Policy = New-Object($PolicyType)
                $Policy.GroupUserName = $GroupUserName
                $Policy.Roles = @()

                #Add Policy to the Folder Policy
                $Policies += $Policy


            }#End if -not $policy

            #Add the new role to the policy
            $r = $Policy.Roles | Where-Object { $_.Name -eq $RoleName } | Select-Object -First 1

            if(-not $r)
            {
                $r = New-Object ($roleType)
                $r.Name = $RoleName
                $Policy.Roles += $r
            }

            #Set the Folder Policy
            $svc.SetPolicies($Folder.Path, $Policies);


        }#End If $InheritParent



    }#End foreach $Folder
