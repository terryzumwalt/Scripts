﻿# Rs.exe -  C:\Automation
# Run Rs.exe - .\rs.exe

Set-Location "C:\Automation"

CommandLine1:

.\rs.exe -i ssrsmigration.rss -e Mgmt2010 -s http://kcssrs71/reportserver -v f="/Reports_Test_migration/T1_SSRS" -v ts=http://sqldba51/reportserver -v tf="/Reports_Test_migration/T1_SSRS" -v tu="<networkid>" -v tp="<password here>" -v security="True"

CommandLine2:

rs.exe -i d:\ssrs_migration\ssrs_migration.rss -e Mgmt2010 -s http://kcssrs71/reportserver -v f="/Reports_Test_migration/T2_SSRS" -v ts=http://sqldba51/reportserver -v tf="/Reports_Test_migration/T2_SSRS" -v tu="<networkid>" -v tp="<password here>" -v security="True"

CommandLine3:

rs.exe -i d:\ssrs_migration\ssrs_migration.rss -e Mgmt2010 -s http://kcssrs71/reportserver -v f="/Reports_Test_migration/T3_DataSource" -v ts=http://sqldba51/reportserver -v tf="/Reports_Test_migration/T3_DataSource" -v tu="<networkid>" -v tp="<password here>" -v security="True"

CommandLine4: 

rs.exe -i d:\ssrs_migration\ssrs_migration.rss -e Mgmt2010 -s http://kcssrs71/reportserver -v f="/Reports_Test_migration/T3_SSRS" -v ts=http://sqldba51/reportserver -v tf="/Reports_Test_migration/T3_SSRS" -v tu="<networkid>" -v tp="<password here>" -v security="True"
