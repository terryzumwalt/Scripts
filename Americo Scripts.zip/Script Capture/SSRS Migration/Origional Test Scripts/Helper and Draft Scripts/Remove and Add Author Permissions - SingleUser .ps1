﻿
import-module sqlserver


#Folder Level: (https://www.sqlshack.com/managing-ssrs-security-using-powershell-automation-scripts/)
#

Function RemovePermissions
{

    #Specify the URI
    $Desturi = "http://sqldba51/reportserver/ReportService2010.asmx"

    $InheritParent = $True

    #Create WebProxy(Connection to SSRS Server and Data)
    $DESTsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $Desturi -UseDefaultCredential
    $type = $DESTsvc.GetType().Namespace;

    $DestRPTList = $Destsvc.ListChildren("/", $true) |Where{$_.TypeName -eq "Report" -and $_.Path -like "*TZ*"}

    #Variables
    $GroupUserName = "kcdom01\SQL_DBA_PROD"
    $policyType = "{0}.Policy" -f $type;
    $roleType = "{0}.Role" -f $type;
    $RoleName = 'Content Manager'



    #ADD Loop Here
    $Reports = $DestRPTList[0]

    foreach($RPT in $Reports)
    {
         #Add the New Policy
        $Policy = New-Object ($policyType)
        $Policy.GroupUserName = $GroupUserName
        $Policy.Roles = @()
        #
        #Add new User to Policy
        $Policies += $Policy


        #Add Roles to the new Policy (If they dont exist)
        $R = $policies.Roles | Where-object {$_.Name -eq $RoleName} | Select-Object -First 1
        if(-not $R)
        {
            $r = New-Object ($roleType)
            $r.Name = $RoleName
            $Policy.Roles += $r
          
        }
      
            #Set the Policy
            $Destsvc.SetPolicies($RPT.Path, $Policies);


    }#End Foreach $RPT




    
}#End Function RemovePermisisons



Function RestorePermissions
{
    ################################################################
    ##### Set Destination Server ###################################

    #Specify the URI
    $uri = "http://sqldba51/reportserver/ReportService2010.asmx"

    #Create WebProxy(Connection to SSRS Server and Data)
    $svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
    $type = $svc.GetType().Namespace;

    $DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report" -and $_.Path -like "*TZ*"}


    ## FILTER FOR SINGLE FOLDER ##
    $DestFolderList = $DestFolderList[0]
    ###############################################################
    

    #Get Info from Table
    $TableQuery = @"
        select * from [dbo].[SSRSAuthReportPermissions] where Path like '%TZ%'
"@
    #Query Table
    $TableInfo = Invoke-Sqlcmd -ServerInstance "SQLDBA51" -Database "DBA_WorkDB" -Query $TableQuery
    #$TableInfo


    #Organize Table Data (Compare Table data to DestFolderList.path)
    #/TZTestReport
    $ITEM = $TableInfo | Where{$_.Path -like $DestFolderlist.Path}
    foreach($obj in $ITEM)
    {
        $UserName = $Item.UserName
        $RoleName = $Item.RoleName
        #$Path = $Item.Path

        #####################
        $InheritParent = $true
        $Policies = $svc.GetPolicies( $Obj.path, [ref] $InheritParent )
        $Policies


        $policyType = "{0}.Policy" -f $type;
        $roleType = "{0}.Role" -f $type;

        #Add the New Policy
        $Policy = New-Object ($policyType)
        $Policy.GroupUserName = $UserName
        $Policy.Roles = @()
        #
        #Add new User to Policy
        #$Policies += $Policy # Removes Duplicates


        ####################
        $R = $policy.Roles | Where-object {$_.Name -eq $RoleName} | Select-Object -First 1
        if(-not $R)
        {
            $r = New-Object ($roleType)
            $r.Name = $RoleName
            $Policy.Roles += $r
        }

        #Set Policy
        $svc.SetPolicies($Folder.Path, $Policies);




    }#End Foreach $Obj






}#END RestorePermissions



#### Action Script #### 

#RemovePermissions
