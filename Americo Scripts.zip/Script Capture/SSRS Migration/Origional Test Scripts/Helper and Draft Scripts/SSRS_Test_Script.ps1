﻿
# SSRS Test Script

# 1. Install Powershell Module
Install-Module -Name ReportingServicesTools -RequiredVersion 0.0.6.7


# 2. Develop individual processes for later development
#Create Proxy
$Proxy = New-RsWebServiceProxy -ReportServerUri 'http://kcssrs71/reportserver'

#Get Datasource
$DataSource = Get-RsDataSource -ReportServerUri 'http://kcssrs71/reportserver' -Path '/TZTest/SQL ReportingServer DB'

#Create Datasource

#Delete Datasource

#Change Datasource
