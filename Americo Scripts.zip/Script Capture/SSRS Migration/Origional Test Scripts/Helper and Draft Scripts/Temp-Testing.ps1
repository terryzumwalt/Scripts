﻿


Set-RsRestItemDataSource -RsItem /Reports_Test_Migration/T3_SSRS/T3_SSRS_DS_Folder -RsItemType 'Report' -DataSources $dataSources -ReportPortalUri $DestURI 