﻿<#
    #Variable: $SSRSServer - This is the SSRS Server  you need to connect to.

    #Variable: $Path
    -- Path refers to the path at the Top level Folder under which all Subscriptions are effected.
    -- Using "/" will refer to the TOP level of SSRS and impact ALL SUBSCRIPTION on the host.
    -- Using "/FolderName/FolderName"  will restrict the impact to only what is under that top level folder.
    -- Additionally I have included an optional filter under the comment ##Optional Filter## below.

    #NOTE:
    -- At the bottom of this script there are TWO Sections. One for ENABLING subscriptions and One for DISABLING.

#>

$SSRSServer = "SQLDBA51"
$Path = "/?"


#Uri to SSRS Server
$URI = "http://$SSRSServer/reportserver/ReportService2010.asmx"

#list all subscriptions  
$rs2010 = New-WebServiceProxy -Uri $URI -Namespace SSRS.ReportingService2010 -UseDefaultCredential;  
$subscriptions = $rs2010.ListSubscriptions("$Path");  


##OPTIONAL Filter##
#$subscriptions = $subscriptions[0]  #Enable this to Filter out a single Subscription (Ask Terry Zumwalt if you have questions.)


########### Enable and Disable Subscriptions ############

#Disable All Subscriptions
ForEach ($subscription in $subscriptions)
{  
    $rs2010.DisableSubscription($subscription.SubscriptionID);  
    $subscription | select subscriptionid, report, path  
}  



#Enable All Subscriptions
ForEach ($subscription in $subscriptions)
{
    $rs2010.EnableSubscription($subscription.SubscriptionID);  
    $subscription | select subscriptionid, report, path  
   
}
