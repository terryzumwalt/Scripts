﻿#import-module reportingservicestools

#get-command -Module reportingservicestools

#$session = New-RsRestSession -ReportPortalUri http://kcssrs71/Reportserver/ 

#Old: kcssrs71
#New: SQLDBA51


### Working ####

#Create Proxy
$Proxy = New-RsWebServiceProxy -ReportServerUri 'http://SQLDBA51/reportserver' 

#http://sqldba51/reportserver/ReportService2010.asmx


#Get a DataSource
$Datasource = Get-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -path '/TZTest/TZTestDS'
$Datasource.ConnectString
#OR
Get-RsRestItemDataSource -RsItem '/Reports_Test_Migration/T1_SSRS/T1_SSRS_Root' -ReportPortalUri 'http://sqldba51/reports'



 

#Create DataSource
New-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -RsFolder '/TZTest' -Name 'TestDS1' -Extension 'SQL' -ConnectionString 'Data Source=.;Initial Catalog=ReportServer;' -CredentialRetrieval 'Integrated'
New-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -RsFolder '/TZTest' -Name 'TZTestDS' -Extension 'SQL' -ConnectionString 'Data Source=.;Initial Catalog=TZTestDB;' -CredentialRetrieval 'Integrated'
## Uses Creds from Data Store
New-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -RsFolder '/Reports_Test_migration/T3_DataSource' -Name 'T3_DS_Root' -Extension 'SQL' -ConnectionString 'data source=kcsqlclust54;initial catalog=americodw;' -CredentialRetrieval 'Integrated' 
## Windows Account
New-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -RsFolder '/Reports_Test_migration/T3_DataSource' -Name 'T3_DS_Root' -Extension 'SQL' -ConnectionString 'data source=kcsqlclust54;initial catalog=americodw;' -WindowsCredentials = "Store" -DatasourceCredentials "kcdom01\tzumwalt" 
# SQL Server Account
New-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -RsFolder '/Reports_Test_migration/T3_DataSource' -Name 'T3_DS_Root2' -Extension 'SQL' -ConnectionString 'data source=kcsqlclust54;initial catalog=americodw;' -DatasourceCredentials "ssrsreader" -CredentialRetrieval "Store"


#Delete DataSource (1.View Items > 2.Remove item based on /path/name)
$CatalogItems = Get-RsCatalogItems -ReportServerUri 'http://SQLDBA51/Reportserver' -RsFolder '/TZTest'
Remove-RsCatalogItem -ReportServerUri 'http://SQLDBA51/Reportserver' -RsItem '/TZTest/TestDS1'


#Change DataSource (Makes Changes to the Connection String based on DatraSource)
Set-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -RsItem '/TZTest/TZTestDS' -DataSourceDefinition $Datasource #$DataSourceDefinition
#####################################################
####### Working with Reports #########
####################################################

#Get Data Source from Report
$SrcReport = Get-RsItemReference -ReportServerUri 'http://kcssrs71/Reportserver' -Path '/TZTest/TZTestReport'
#Get-RsItemReference -ReportServerUri 'http://kcssrs71/Reportserver' -Path '/Reports_Test_Migration/T1_SSRS/T1_SSRS_Folder_DS'
$Test = $SrcReport.Reference

$SrcReport = Get-RsItemReference -ReportServerUri 'http://SQLDBA51/Reportserver' -Path '/TZTest/TZTestReport'
$SrcReport.Reference


#Change Datasource On report
Set-RsDataSourceReference -Path /TZTest/TZTestReport -DataSourceName DataSource1 -DataSourcePath /TZTest/TestDS1 -ReportServerUri 'http://SQLDBA51/Reportserver'


##################################################################
#Change Credentials for Datasource Method 1
$Datasource = Get-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -path '/Reports_Test_Migration/T1_SSRS/T1_SSRS_DataSource/T1_DS_Folder'
$Datasource.WindowsCredentials = $FALSE
$Datasource.CredentialRetrieval = "Store"
$Datasource.Extension = "SQL"
$Datasource.UserName = "ssrsreader"
$Datasource.Password = "P0werR3nger"
Set-RsDataSource -RsItem /Reports_Test_Migration/T1_SSRS/T1_SSRS_DataSource/T1_DS_Folder -DataSourceDefinition $Datasource -ReportServerUri 'http://SQLDBA51/Reportserver' -Verbose



#############################################
#Change Credentials for Datasource Method 2
$ReportingServer = "SQLDBA51"
$userName = "ssrsreader"
$password = "P0werR3nger" #UpdatedPassword
#$uri = "http://{0}/ReportServer/ReportService2010.asmx?WSDL" -f $ReportingServer
$uri = "http://sqldba51/reportserver/ReportService2010.asmx"

$reporting = New-WebServiceProxy -uri $uri -UseDefaultCredential -namespace "ReportingWebService"
$DataSources = $reporting.ListChildren('/', $true) | Where-Object {$_.TypeName -eq "DataSource"}

#This will filter for a specific test path
$DSList = $DataSources | where {$_.Path -like "*TZ*"}
$DSList = $DSList[2]  #Only TZTestDS

foreach($Object in $DSList) {
  $dataSource = $reporting.GetDataSourceContents($Object.path)[0]
  $Verify = $datasource.UserName
  if ($Verify -eq $userName) {
    $dataSource.WindowsCredentials = $FALSE
    $dataSource.UserName = $userName
    $dataSource.Password = $password
    $reporting.SetDataSourceContents($Object.Path, $dataSource)
  }
}

###########################################################
############ Fix Credentials Imbedded in the Report #########

$dataSources = Get-RsRestItemDataSource -RsItem '/Reports_Test_migration/T3_SSRS/T3_SSRS_DS_CUSTOM' -ReportPortalUri 'http://SQLDBA51/Reports'
$dataSources.CredentialsInServer.UserName = "<AD Account>"
$dataSources.CredentialsInServer.Password = "<PASS>"
Set-RsRestItemDataSource -RsItem '/Reports_Test_migration/T3_SSRS/T3_SSRS_DS_CUSTOM' -RsItemType 'Report' -DataSources $dataSources -ReportPortalUri 'http://SQLDBA51/Reports'



### SEE: Fix_Broken_Migrated_Report.ps1  for more info
