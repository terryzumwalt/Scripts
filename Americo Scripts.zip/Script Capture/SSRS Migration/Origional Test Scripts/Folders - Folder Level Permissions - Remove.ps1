﻿
#https://www.sqlshack.com/managing-ssrs-security-using-powershell-automation-scripts/


################################################################
##### Set Destination Server ###################################

#Specify the URI
$uri = "http://sqlssrs62/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential

$SRCFolderList = $svc.ListChildren("/", $true) | select -Property Path ,TypeName #|Where{$_.TypeName -eq "Folder" -and $_.Path -like "*Wilfred*"}
################################################################


$InheritParent = $true

foreach($Folder in $SRCFolderList)
{
    write-Host $Folder.path -ForegroundColor Yellow
    $Policies = $svc.GetPolicies( $folder.path, [ref] $InheritParent )
    $Policies = $Policies | Where {$_.GroupUserName -ne "KCDOM01\tzumwalt"}

    #Add these to array if needed per the link (Security auditing Section)


        #Set the Policy
    $svc.SetPolicies($Folder.Path, $Policies);



}#end foreach $Folder



 