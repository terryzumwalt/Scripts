﻿import-module ReportingServicesTools


$uri = "http://sqldba51/reportserver/ReportService2010.asmx"



######### Get a list of Datasources #######
$RS = New-WebServiceProxy -uri $uri -UseDefaultCredential -namespace "ReportingWebService"
$DataSources = $RS.ListChildren('/', $true) | Where-Object {$_.TypeName -eq "DataSource"}



#This will filter for a specific test path
$DSList = $DataSources | where {$_.Path -like "*TZ*"}
$DSList = $DSList[2]  #Only TZTestDS



#Specify Credentials for the Datasource and Set them
foreach($DS in $DSList) 
{
    $dataSource = $RS.GetDataSourceContents($DS.path)[0]
    $dataSource.WindowsCredentials = $FALSE
    $dataSource.UserName = "ssrsreader"
    $dataSource.Password = "P0werR3nger"
    $RS.SetDataSourceContents($DS.Path, $dataSource)
}#End Foreach $DS





