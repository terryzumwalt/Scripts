﻿
##### Currently this does not work #########




## Change UN and Pass in Subscriptions

## Data Source=.;Initial Catalog=TZTestDB;

## NOTE: Requires a connection to the datasource
#Place: TZTestReport


$DestURI = 'http://SQLDBA51/Reportserver'

#Change Credentials for Subscription
$ReportingServer = "SQLDBA51"
$userName = "ssrsreader"
$password = "P0werR3nger" #UpdatedPassword
#$uri = "http://{0}/ReportServer/ReportService2010.asmx?WSDL" -f $ReportingServer
$uri = "http://sqldba51/reportserver/ReportService2010.asmx"

#$reporting = New-WebServiceProxy -uri $uri -UseDefaultCredential -namespace "ReportingWebService"
$reporting = New-WebServiceProxy -uri $uri -UseDefaultCredential
$Reports = $reporting.ListChildren('/', $true) | Where-Object {$_.TypeName -eq "Report"}

$Reports = $Reports | Where {$_.Path -like "*TZ*"}

#Fetch Subscription for a Report
$Subscriptions = $Reporting.ListSubscriptions($Reports[0].Path)
$Subscriptions.DeliverySettings.ParameterValues



$reporting.SetSubscriptionProperties($Reports[0].Path,"DefaultCredentials")

######################################
#### Figure this out ################
#######################################

$type = $Reporting.GetType().Namespace

#Define Object Types for Subscription property call
$ExtensionSettingsDataType = ($type + '.ExtensionSettings')
$ActiveStateDataType = ($type + '.ActiveState')
$ParmValueDataType = ($type + '.ParameterValue')

$ExtensionSettingsObj = New-Object ($ExtensionSettingsDataType)
$ActiveStateObj = New-Object ($ActiveStateDataType)
$ParmValueObj = New-Object ($ParmValueDataType)
$Description = $null
$Status = $null
$EventType = $null
$MatchData = $null

$SubscriptionProperties = $Reporting.GetSubscriptionProperties($Subscriptions.SubscriptionID.ToString(),` 
[ref]$ExtensionSettingsObj, ` 
[ref]$Description, ` 
[ref]$ActiveStateObj, ` 
[ref]$status, ` 
[ref]$eventType, ` 
[ref]$matchdata, ` 
[ref]$ParmValueObj)            

$ExtensionSettingsObj.ParameterValues


$SubscriptionProperties


#
#https://www.warrenestes.com/update-multiple-ssrs-subscriptions/







#########################################################################################
<#
#Filter for Specific Path
$Reports  = $Reports| Where{$_.Path -like "*TZTest*"}


$subscription = $reporting.ListSubscriptions($Reports.path)
$ReportSubscriptionID = [String]$subscription.SubscriptionID
$subscription.DeliverySettings.ParameterValues
$details = $reporting.GetSubscriptionProperties($Subscription.SubscriptionID, [REF]$ExtensionSettings, [REF]$Description, [REF]$Active, [REF]$Status, [REF]$EventType, [REF]$MatchData, [REF]$ParametersValue)


$reporting.GetSubscriptionProperties($Subscription)






###########################

$RPT = Get-RsSubscription  -ReportServerUri $DestURI -rsitem /tztest/tztestreport
$RPT.SubscriptionID = "$ReportSubscriptionID"
#$RPT.DeliverySettings

$RPT.Owner

$RPT.DeliverySettings.ParameterValues
Set-RsSubscription - -ReportServerUri $DestURI               

#>












