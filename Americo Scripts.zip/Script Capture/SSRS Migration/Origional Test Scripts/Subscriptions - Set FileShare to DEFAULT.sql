--https://www.spheregen.com/update-existing-windows-file-share-subscriptions-to-use-common-file-share-account/
use ReportServer

/*T-Sql Script to update all FileShare Subscriptions to use common FileShare Account*/

Declare @SubscriptionID nvarchar(1000),@ExtensionSettings Nvarchar(MAX),@XMLDATA XML;

declare

cur_FIXED_Subscriptions CURSOR for Select SubscriptionID,[ExtensionSettings]

from dbo.Subscriptions

where DeliveryExtension='Report Server FileShare'and SubscriptionID = '1D719732-869A-4238-A18A-58BDA01D14DF';

 



Open cur_FIXED_Subscriptions

Fetch Next from cur_FIXED_Subscriptions into @SubscriptionID,@ExtensionSettings

While @@FETCH_STATUS=0

Begin

Set @XMLDATA=CAST(@ExtensionSettings AS XML)

--Delete Nodes related to file subscription username and password

Set @XMLDATA.modify('delete /ParameterValues/ParameterValue[Name="USERNAME"]' )

Set @XMLDATA.modify('delete /ParameterValues/ParameterValue[Name="PASSWORD"]' )

--Delete Nodes related to file subscription DEFAULTCREDENTIALS (if any) related to fileshare common account

Set @XMLDATA.modify('delete /ParameterValues/ParameterValue[Name="DEFAULTCREDENTIALS"]' )

--Insert new node DEFAULTCREDENTIALS=True to use common file share account

Set @XMLDATA.modify('insert <ParameterValue><Name>DEFAULTCREDENTIALS</Name><Value>True</Value></ParameterValue> into (/ParameterValues)[1]' )

--Update OLD Render format to NEW Render format

Update Subscriptions

Set [ExtensionSettings]=cast(@XMLDATA as nvarchar(max))

where Convert(nvarchar(1000),SubscriptionID)=@SubscriptionID

 

Fetch Next from cur_FIXED_Subscriptions into @SubscriptionID,@ExtensionSettings

End

 

Close cur_FIXED_Subscriptions

DeAllocate cur_FIXED_Subscriptions