﻿import-module ReportingServicesTools


$SSRSHost = "sqldba51"
$uri = "http://$SSRSHost/reportserver/ReportService2010.asmx"
$Path = "/TZTest"


#list all subscriptions in $Path 
$rs2010 = New-WebServiceProxy -Uri $uri -Namespace SSRS.ReportingService2010 -UseDefaultCredential;  
$subscriptions = $rs2010.ListSubscriptions($Path);  


foreach($Sub in $subscriptions)
{
    $SubID = $Sub.SubscriptionID

    $Query = @"
        --use ReportServer

        /*T-Sql Script to update all FileShare Subscriptions to use common FileShare Account*/

        Declare @SubscriptionID nvarchar(1000),@ExtensionSettings Nvarchar(MAX),@XMLDATA XML;

        declare

        cur_FIXED_Subscriptions CURSOR for Select SubscriptionID,[ExtensionSettings]

        from dbo.Subscriptions

        where DeliveryExtension='Report Server FileShare'and SubscriptionID = '$SubID';

 



        Open cur_FIXED_Subscriptions

        Fetch Next from cur_FIXED_Subscriptions into @SubscriptionID,@ExtensionSettings

        While @@FETCH_STATUS=0

        Begin

        Set @XMLDATA=CAST(@ExtensionSettings AS XML)

        --Delete Nodes related to file subscription username and password

        Set @XMLDATA.modify('delete /ParameterValues/ParameterValue[Name="USERNAME"]' )

        Set @XMLDATA.modify('delete /ParameterValues/ParameterValue[Name="PASSWORD"]' )

        --Delete Nodes related to file subscription DEFAULTCREDENTIALS (if any) related to fileshare common account

        Set @XMLDATA.modify('delete /ParameterValues/ParameterValue[Name="DEFAULTCREDENTIALS"]' )

        --Insert new node DEFAULTCREDENTIALS=True to use common file share account

        Set @XMLDATA.modify('insert <ParameterValue><Name>DEFAULTCREDENTIALS</Name><Value>True</Value></ParameterValue> into (/ParameterValues)[1]' )

        --Update OLD Render format to NEW Render format

        Update Subscriptions

        Set [ExtensionSettings]=cast(@XMLDATA as nvarchar(max))

        where Convert(nvarchar(1000),SubscriptionID)=@SubscriptionID

 

        Fetch Next from cur_FIXED_Subscriptions into @SubscriptionID,@ExtensionSettings

        End

 

        Close cur_FIXED_Subscriptions

        DeAllocate cur_FIXED_Subscriptions
"@

    Invoke-Sqlcmd -ServerInstance $SSRSHost -Database "ReportServer" -Query $Query

}#End Foreach $SUb


