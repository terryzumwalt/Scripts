use DBA_WorkDB

create table SSRSAuthReportPermissions
(
	ROW_ID BIGINT IDENTITY(1,1) NOT NULL,
	UserName NVARCHAR(100),
	RoleName NVARCHAR(100),
	Path NVARCHAR(100),
	Name NVARCHAR(100)
)