USE ReportServer
GO


;with foldersec as
(
	select u.UserName, r.RoleName, c.Path, c.Name 
	from dbo.PolicyUserRole pur
	   inner join dbo.Users u on pur.UserID = u.UserID
	   inner join dbo.Roles r on pur.RoleID = r.RoleID
	   inner join dbo.Catalog c on pur.PolicyID = c.PolicyID
	 

)
insert into [DBA_WorkDB].[dbo].[SSRSAuthReportPermissions] 
Select * 
from foldersec

--select * from foldersec
--select * from [DBA_WorkDB].[dbo].[SSRSAuthReportPermissions] 


