﻿Import-Module ReportingServicesTools


#$SrcURI = 'http://KCSSRS01/Reportserver'
$DestAlt = "http://KCSSRS01/reportserver/ReportService2010.asmx"

#list all subscriptions  
$rs2010 = New-WebServiceProxy -Uri $DestAlt -Namespace SSRS.ReportingService2010 -UseDefaultCredential;  
$subscriptions = $rs2010.ListSubscriptions("/");  
#$SubID = $Subscriptions[0].SubscriptionID

foreach($Sub in $subscriptions)
{

    if(($Sub.DeliverySettings).Extension -like "*Report Server FileShare*")
    {

        $SubSettings = $sub.DeliverySettings.ParameterValues 

        $Table = New-Object psobject -Property @{
               
            PathINSubscription = ($SubSettings |Where{$_.Name -eq "PATH"}).Value
            Username = ($SubSettings |Where{$_.Name -eq "USERNAME"}).Value
            PathToSubscription = $Sub | select Path
        }

        $Table |Export-Csv -Path "Y:\Scripts\SSRS Migration\Origional Test Scripts\KCSSRS01.csv" -Append
    }

    
    " "
}#End Foreach $Sub




<#

        $SubSettings = $sub.DeliverySettings.ParameterValues 

        $Table = New-Object psobject -Property @{
               
            PathINSubscription = ($SubSettings |Where{$_.Name -eq "PATH"}).Value
            Username = ($SubSettings |Where{$_.Name -eq "USERNAME"}).Value
            PathToSubscription = $Sub | select Path
        }

        $Table |Export-Csv -Path "Y:\Scripts\SSRS Migration\Origional Test Scripts\KCSSRS01.csv" -Append
        #$Sub | Select Owner, Path |Export-Csv -Path "Y:\Scripts\SSRS Migration\Origional Test Scripts\KCSSRS01.csv" -Append


#>





