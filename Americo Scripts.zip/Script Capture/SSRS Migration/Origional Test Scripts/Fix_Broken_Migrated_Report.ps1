﻿#### Fix DataSource ####

#### Source Datasources ####
$ReportingServer = "kcssrs71"
$userName = "ssrsreader"
$password = "P0werR3nger" #UpdatedPassword
#$uri = "http://{0}/ReportServer/ReportService2010.asmx?WSDL" -f $ReportingServer
$uri = "http://sqldba51/reportserver/ReportService2010.asmx"

$reporting = New-WebServiceProxy -uri $uri -UseDefaultCredential -namespace "ReportingWebService"
#$DataSources = $reporting.ListChildren('/', $true) | Where-Object {$_.TypeName -eq "DataSource"}
$SRCDS = $reporting.ListChildren('/', $true) | Where-Object {$_.TypeName -eq "DataSource" -and $_.Name -eq "T3_DS_Root"}
$SRCDS.name
$SRCDS.Path
$SRCDS.count
$SRCDS.




#### Dest Datasources ####
$ReportingServer = "SQLDBA51"
$userName = "ssrsreader"
$password = "P0werR3nger" #UpdatedPassword
#$uri = "http://{0}/ReportServer/ReportService2010.asmx?WSDL" -f $ReportingServer
$uri = "http://sqldba51/reportserver/ReportService2010.asmx"

$reporting = New-WebServiceProxy -uri $uri -UseDefaultCredential -namespace "ReportingWebService"
$DSTDS = $reporting.ListChildren('/', $true) | Where-Object {$_.TypeName -eq "DataSource" -and $_.Name -eq "T3_DS_Root"}
$DSTDS.name
$Path = $DSTDS.Path
$DSTDS.count

############ Solve the error #########

##### Read Datasource from SOURCE ####
$Path = $DSTDS.Path
$DSobj = Get-RsDataSource -ReportServerUri 'http://kcssrs71/Reportserver' -path '/Reports_Test_migration/T3_DataSource/T3_DS_Root'
<#
    #Gather Variables from SRC to create new Dest obj
#>
#OR
$DSTest = Get-RsDataSource -ReportServerUri 'http://KCSSRS71/reportserver' -path '/Reports_Test_migration/T3_DataSource/T3_DS_Root'


#### Remove DST Broken Datasource from DESTINATION ####
Remove-RsCatalogItem -ReportServerUri 'http://SQLDBA51/Reportserver' -RsItem $Path 


#### Rebuild DST Datasource on DESTINATION ####
#Notice "Windows Credentials" at the end of the command
## Uses Creds from Data Store
New-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -RsFolder '/Reports_Test_migration/T3_DataSource' -Name 'T3_DS_Root' -Extension 'SQL' -ConnectionString 'data source=kcsqlclust54;initial catalog=americodw;' -CredentialRetrieval 'Integrated' 
## Windows Account
New-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -RsFolder '/Reports_Test_migration/T3_DataSource' -Name 'T3_DS_Root' -Extension 'SQL' -ConnectionString 'data source=kcsqlclust54;initial catalog=americodw;' -WindowsCredentials = "Store" -DatasourceCredentials "kcdom01\tzumwalt" 
# SQL Server Account
New-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -RsFolder '/Reports_Test_migration/T3_DataSource' -Name 'T3_DS_Root2' -Extension 'SQL' -ConnectionString 'data source=kcsqlclust54;initial catalog=americodw;' -DatasourceCredentials "ssrsreader" -CredentialRetrieval "Store"


#### Fix Credentials on New Datasource ####
$Datasource = Get-RsDataSource -ReportServerUri 'http://SQLDBA51/Reportserver' -path '/Reports_Test_migration/T3_DataSource/T3_DS_Root'
$Datasource.WindowsCredentials = $FALSE
$Datasource.CredentialRetrieval = "Store"
$Datasource.Extension = "SQL"
$Datasource.UserName = "ssrsreader"
$Datasource.Password = "P0werR3nger"
Set-RsDataSource -RsItem /Reports_Test_migration/T3_DataSource/T3_DS_Root -DataSourceDefinition $Datasource -ReportServerUri 'http://SQLDBA51/Reportserver' -Verbose




#### Set New Data Source for Report ####
Set-RsDataSourceReference -Path /Reports_Test_migration/T3_SSRS/T3_SSRS_DS_Folder -DataSourceName DataSource1 -DataSourcePath /Reports_Test_migration/T3_DataSource/T3_DS_Root -ReportServerUri 'http://SQLDBA51/Reportserver' 




## If datasource is shared NO change. "WindowsCredentials = $False"
### This Step is not always Necessary if the Report uses standard credentials from the Datasource ####
#### Fix Report (Embeded Credentials) ####
$dataSources = Get-RsRestItemDataSource -RsItem '/Reports_Test_migration/T3_SSRS/T3_SSRS_DS_Folder/' -ReportPortalUri 'http://SQLDBA51/Reports'
$dataSources.CredentialsInServer.UserName = "<AD Account>"
$dataSources.CredentialsInServer.Password = "<PASS>"
Set-RsRestItemDataSource -RsItem '/Reports_Test_migration/T3_SSRS/T3_SSRS_DS_CUSTOM' -RsItemType 'Report' -DataSources $dataSources -ReportPortalUri 'http://SQLDBA51/Reports'


