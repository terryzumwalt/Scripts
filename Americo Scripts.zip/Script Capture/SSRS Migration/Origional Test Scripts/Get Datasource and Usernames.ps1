﻿Import-Module ReportingServicesTools

$SRV = "SQLNETWRX01"
$uri = "http://$SRV/reportserver/ReportService2010.asmx"
$RSUri = 'http://$SRV/Reportserver'

$reporting = New-WebServiceProxy -uri $uri -UseDefaultCredential -namespace "ReportingWebService"
$DataSources = $reporting.ListChildren('/', $true) | Where-Object {$_.TypeName -eq "DataSource"}
$DataSources

