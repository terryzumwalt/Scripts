
use DBA_WorkDB
GO
Create table dbo.SnapShotHistSchedule
(
	path Nvarchar(400),
	ScheduleName NVarchar(200),
	[Recurrence Type] NVarchar(20),
	[Recurrence Sub Type] NVarchar(20),
	[Run every (Hours)] NVarchar(20),
	[Runs Every (Days)] int,
	[Runs Every (Weeks)] int,
	[Runs Every (Week Days)] NVarchar(30),
	[Runs Every (Week of Month)] NVarchar(30),
	[Runs Every (Runs every Month)] NVarchar(200),
	[Runs Every (Calendar Days)] NVarchar(30),
	StartDate datetime,
	NextRunTime datetime,
	LastRunTime datetime,
	EndDate datetime,
	EventType NVarchar(50)
);


