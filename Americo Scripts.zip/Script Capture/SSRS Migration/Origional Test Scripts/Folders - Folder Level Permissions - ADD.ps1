﻿
#https://www.sqlshack.com/managing-ssrs-security-using-powershell-automation-scripts/


################################################################
##### Set Destination Server ###################################

#Specify the URI
$uri = "http://SQLSSRS72/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
$type = $svc.GetType().Namespace;


$DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder" -and $_.Path -like "*TZ*"}


###############################################################
##### Query Source Server for Folder List #####

#Specify the URI
$SRCuri = "http://SQLSSRS62/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$SRCsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
#$type = $SRCsvc.GetType().Namespace;


$SRCFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder" -and $_.Path -like "*TZ*"}


############ List Folder Permissions ##############

$InheritParent = $true

foreach($Folder in $SRCFolderList)
{
    $Policies = $svc.GetPolicies( $folder.path, [ref] $InheritParent )
    $Policies

    #Add these to array if needed per the link (Security auditing Section)

}#end foreach $Folder


########### Set Permissions on the Folder ######

$GroupUserName = 'KCDOM01\TZumwalt'
$policyType = "{0}.Policy" -f $type;
$roleType = "{0}.Role" -f $type;
$RoleName = 'Content Manager'

foreach($Folder in $SrcFolderList)
{
    #Add the New Policy
    $Policy = New-Object ($policyType)
    $Policy.GroupUserName = $GroupUserName
    $Policy.Roles = @()
    #
    #Add new User to Policy
    $Policies += $Policy


    #Add Roles to the new Policy (If they dont exist)
    $R = $policy.Roles | Where-object {$_.Name -eq $RoleName} | Select-Object -First 1
    if(-not $R)
    {
        $r = New-Object ($roleType)
        $r.Name = $RoleName
        $Policy.Roles += $r
    }

    #Set the Policy
    $svc.SetPolicies($Folder.Path, $Policies);

}#End foreach $Folder 