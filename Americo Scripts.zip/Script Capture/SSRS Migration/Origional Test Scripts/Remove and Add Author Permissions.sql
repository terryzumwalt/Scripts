-- This script adds the Auth Permissions to a secondary table
-- This is because we want them recorded when they are removed
USE ReportServer


; with FolderSec as (
select c.Path as ReportFolder, u.UserName, r.RoleName
from catalog c
Join PolicyUserRole pur on
c.PolicyID = pur.PolicyID
Join Users u on pur.UserID = u.UserID
join Roles r on pur.RoleID = r.RoleID
where type = 1
--order by c.path, u.UserName, r.RoleName
)


INSERT INTO [DBA_WorkDB].dbo.SSRSAuthPermissionsPS
SELECT ReportFolder, UserName,
Max(Case when RoleName in ('Browser','Report Builder','Publisher','Content Manager') then 'View' else '' End) as [View],
Max(Case when RoleName in ('Publisher','Content Manager') then 'Modify' Else '' End) as [Modify],
Max(Case when RoleName = 'Browser' then 'Browser' Else '' End) as Browser,
Max(Case when RoleName = 'Report Builder' then 'Report Builder' Else '' End) as [Report Builder],
Max(Case when RoleName = 'Publisher' then 'Publisher' Else '' End) as Publisher,
Max(Case when RoleName = 'Manage All Subscriptions' then 'Manage All Subscriptions' Else '' End) as [Manage All Subscriptions],
Max(Case when RoleName = 'My Reports' then 'My Reports' Else '' End) as [My Reports],
Max(Case when RoleName = 'Content Manager' then 'Content Manager' Else '' End) as [Content Manager]
FROM FolderSec
group by ReportFolder, Username
order by reportfolder, username


SELECT * FROM DBA_WorkDB.dbo.SSRSAuthPermissionsPS







