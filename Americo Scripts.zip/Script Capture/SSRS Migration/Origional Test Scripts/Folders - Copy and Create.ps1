﻿
#TO use this script
#1.  Sections one / Two creates a connection to A ssrs server and discovers paths
#2. Section Three will take the array ($SrcItemList) and creates the Root and subfolders from the list on the Dest Server
#3. Section Four was for testing the concept and can be used for AdHoc





#Import-Module ReportingServicesTools
######################################################
####### Query Source for List of Folder Paths ########
#Specify the URI (SRC Server)
$Srcuri = "http://kcssrs71/reportserver/ReportService2010.asmx"


#Create WebProxy(Connection to SSRS Server and Data)
$Srcsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $Srcuri -UseDefaultCredential

$SrcItemList = $Srcsvc.ListChildren("/", $true) | Where{$_.TypeName -eq "Folder" -and $_.Path -like "*TZ*"}
$SrcItemList.path





###############################################################
##### Query Dest for list of existing paths #####

#Specify the URI (used for Obtaining the path list)
$uri = "http://sqldba51/reportserver/ReportService2010.asmx"

#This is used for the CMDLet New-RSFolder
$RS = "Http://sqldba51/ReportServer"


#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential

$ItemList = $svc.ListChildren("/", $true) | Where{$_.TypeName -eq "Folder" -and $_.Path -like "*TZ*"}
$ItemList.path


########################################################################################
################# (Automated) Test Folder Path for subdirectory Creation ###############

#Array of Paths Obtained from (Src Server)
$ArrayListItem = $SrcItemList.path


foreach($DirPath in $ArrayListItem)
{
    
    $PathArray = ($DirPath -split '/') | Where{$_ -ne ""}

    $i = 0
    foreach($Item in $PathArray)
    {
        if($i -eq 0){$Test = "/" + $PathArray[0]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}
        if($i -eq 1){$Test = "/" + $PathArray[0] + "/" + $PathArray[1]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}
        if($i -eq 2){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}
        if($i -eq 3){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2] + "/" + $PathArray[3]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}
        if($i -eq 4){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2] + "/" + $PathArray[3] + "/" + $PathArray[4]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}



        if($Verify.length -gt 0){Write-Host "Existing Path:" $Test;}
        if($Verify.length -lt 1){Write-Host "Creating Path:" $Test;}



        if($Verify.length -lt 1)#Path does not exist
        {
            if($i -eq 0){$Root = "/"; $Path = $Item }
            if($i -eq 1){$Root = "/" + $PathArray[0]; $Path = $Item }
            if($i -eq 2){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]; $Path = $Item }
            if($i -eq 3){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2]; $Path = $Item }
            if($i -eq 4){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2]  + "/" + $PathArray[3]; $Path = $Item }

            New-RsFolder -reportserveruri $RS -RsFolder $Root -foldername $Path -ErrorAction SilentlyContinue
            
       
        }#End if $Verify

        $i++

    }#End foreach $Item

}#End foreach $DIRPath




<#
#########################################################
############ Create Folders - Manual List ###############



$RS = "Http://sqldba51/ReportServer"


#Input your Path Here (Or Loop Paths)
$ArrayListItem = "/TZNF/NewFolder/NF2/NF3.stuff"

#Remove / from the path and create an array of folders (In order)
$PathArray = ($ArrayListItem -split '/') | Where{$_ -ne ""}


#Loop the Array creating ROOT then the subfolders
$i = 0
foreach($Item in $PathArray)
{
    
    if($i -eq 0){$Root = "/"; $Path = $Item }
    if($i -eq 1){$Root = "/" + $PathArray[0]; $Path = $Item }
    if($i -eq 2){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]; $Path = $Item }
    if($i -eq 3){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2]; $Path = $Item }
    if($i -eq 4){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2]  + "/" + $PathArray[3]; $Path = $Item }

    Write-Host "Root is "$Root -ForegroundColor Yellow
    Write-Host "Building Folder "$Path -ForegroundColor Gray

    New-RsFolder -reportserveruri $RS -RsFolder $Root -foldername $Path
    $i++
    $i

   
}#End Foreach Item





###################
#Import List of Reports as Objects
#$reports = $svc.ListChildren("/", $true) | Where-Object { $_.TypeName -eq "Report" }
#$report = $reports | Where{$_.Path -like "*/TZTest/TZTestReport2*"}
#>