﻿Import-Module ReportingServicesTools


#$SrcURI = 'http://KCSSRS01/Reportserver'
$DestAlt = "http://KCSSRS01/reportserver/ReportService2010.asmx"

#list all subscriptions  
$rs2010 = New-WebServiceProxy -Uri $DestAlt -Namespace SSRS.ReportingService2010 -UseDefaultCredential;  
$subscriptions = $rs2010.ListSubscriptions("/");  
#$SubID = $Subscriptions[0].SubscriptionID

foreach($Sub in $subscriptions)
{
    $Sub | Select Owner, Path |Export-Csv -Path "Y:\Scripts\SSRS Migration\Origional Test Scripts\KCSSRS01.csv" -Append
    
    " "
}#End Foreach $Sub





