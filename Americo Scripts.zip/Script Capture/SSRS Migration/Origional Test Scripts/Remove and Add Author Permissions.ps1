﻿
import-module sqlserver


#Folder Level: (https://www.sqlshack.com/managing-ssrs-security-using-powershell-automation-scripts/)
#

Function RemovePermissions
{

    #Specify the URI
    $Desturi = "http://sqldba51/reportserver/ReportService2010.asmx"

    $InheritParent = $True

    #Create WebProxy(Connection to SSRS Server and Data)
    $DESTsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $Desturi -UseDefaultCredential
    $type = $DESTsvc.GetType().Namespace;

    $DestRPTList = $Destsvc.ListChildren("/", $true) |Where{$_.TypeName -eq "Report" -and $_.Path -like "*TZ*"}

    #Variables
    $GroupUserName = "kcdom01\SQL_DBA_PROD"
    $policyType = "{0}.Policy" -f $type;
    $roleType = "{0}.Role" -f $type;
    $RoleName = 'Content Manager'



    #Loop Here
    #$Reports = $DestRPTList[1]

    foreach($RPT in $Reports)
    {
         #Add the New Policy
        $Policy = New-Object ($policyType)
        $Policy.GroupUserName = $GroupUserName
        $Policy.Roles = @()
        #
        #Add new User to Policy
        $Policies += $Policy


        #Add Roles to the new Policy (If they dont exist)
        $R = $policies.Roles | Where-object {$_.Name -eq $RoleName} | Select-Object -First 1
        if(-not $R)
        {
            $r = New-Object ($roleType)
            $r.Name = $RoleName
            $Policy.Roles += $r
          
        }
      
            #Set the Policy
            $Destsvc.SetPolicies($RPT.Path, $Policies);


    }#End Foreach $RPT




    
}#End Function RemovePermisisons



Function RestorePermissions
{
    ################################################################
    ##### Set Destination Server ###################################

    #Specify the URI
    $uri = "http://sqldba51/reportserver/ReportService2010.asmx"

    #Create WebProxy(Connection to SSRS Server and Data)
    $svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
    $type = $svc.GetType().Namespace;

    $DestReportList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report" -and $_.Path -like "*TZ*"}


    ## FILTER FOR SINGLE FOLDER ##
    #$DestReportList = $DestReportList[1]
    ###############################################################
    
    foreach($RPT in $DestReportList)
    {
        #Get Info from Table
        $RPTPath = $RPT.path
        $TableQuery = @"
            select * from [dbo].[SSRSAuthReportPermissions] where Path like '$RPTPath'
"@
        #Query Table
        $TableInfo = Invoke-Sqlcmd -ServerInstance "SQLDBA51" -Database "DBA_WorkDB" -Query $TableQuery
        #$TableInfo

        ######
        $InheritParent = $true
        $Policies = $svc.GetPolicies( $Rpt.path, [ref] $InheritParent )
        $policyType = "{0}.Policy" -f $type;
        $roleType = "{0}.Role" -f $type;

        #$Policies

        #Remove Users that are alreayd on the Report
        $UNArray = @()
        $UserNames = $TableInfo.UserName |Select -Unique 
        foreach($UN in $UserNames)
        {
            if($Policies.GroupUserName -notcontains $UN)
            {
                $UNArray += $UN
            }
        }#End foreach $UN
        $UserNames = $UNArray


        #Run One name at a time and Gather UserName and Role Array
        foreach($UserName in $UserNames)
        {
            $Policy = New-Object ($policyType)
            $Policy.Roles = @()

            $UserInfo = $Tableinfo | Where{$_.UserName -eq $UserName}

            #Work with One User at a time
            $Roles = $userInfo.RoleName
            $RoleArray = @()

            #Gather an array of Roles for the User ($Not adding Roles to Policy at this step just arraying them)
            foreach($Role in $Roles)
            {
                #Array Of Roles
                $RoleArray += $Role

            }#End Foreach $Role



            #Add the New Policy and USERNAME
            $Policy.GroupUserName = $UserName
            #Add new User to Policy
            $Policies += $Policy # Removes Duplicates


            $R = $policy.Roles #| Where-object {$_.Name -eq $RoleName} | Select-Object -First 1

            foreach($RoleName in $RoleArray)
            {
                #Add New Roles
                if(-not $R)
                {
                    $r = New-Object ($roleType)
                    $r.Name = $RoleName
                    $Policy.Roles += $r
                }

            }#End Foreach $RoleName

            
           #Set new Policy on the Report
           $svc.SetPolicies($RPT.Path, $Policies) 


            
        }#End Foreach $UserName









    }#End Foreach $RPT



}#END RestorePermissions



#### Action Script #### 

#RemovePermissions
RestorePermissions
