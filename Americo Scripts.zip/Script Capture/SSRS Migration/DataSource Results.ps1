﻿Import-Module ReportingServicesTools


$uri = "http://kcssrs01/reportserver/ReportService2010.asmx"
#$RSUri = 'http://SQLDBA51/Reportserver'

$reporting = New-WebServiceProxy -uri $uri -UseDefaultCredential -namespace "ReportingWebService"
$DataSources = $reporting.ListChildren('/', $true) | Where-Object {$_.TypeName -eq "DataSource"}
$DataSources.count


foreach($DS in $DataSources)
{
    $DataSrc = $reporting.GetDataSourceContents($DS.path)[0]
    $DataSrc.ConnectString
    $DS.Path
    Read-host "Next"
}






