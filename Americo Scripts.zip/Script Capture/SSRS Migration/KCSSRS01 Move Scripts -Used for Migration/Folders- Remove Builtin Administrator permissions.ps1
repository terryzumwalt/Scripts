﻿
$Datetime = (Get-Date -Format "MMddyyyy_HH_mm")
$RMAdmin = "RemoveAdministratorGroup" + "_" + $Datetime + ".txt"
$Log = "\\kcsan03\technology\DBA\SSRS\SSRS Move\SSRS Move Scripts\Logs\$RMAdmin"




################################################################
##### Set Destination Server ###################################

#Specify the URI
$uri = "http://sqlssrs02/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential

$SRCFolderList = $svc.ListChildren("/", $true) | select -Property Path ,TypeName |Where{$_.TypeName -eq "Folder"} 
################################################################


$InheritParent = $true

foreach($Folder in $SRCFolderList)
{
    
    $Policies = $svc.GetPolicies( $folder.path, [ref] $InheritParent )
    
    if($Policies.GroupUserName -contains "BUILTIN\Administrators")
    {
        $out1 = $Folder.path + " " + ": Removing KCDOM01\BuiltinAdministrators" >> $Log

        write-Host $Folder.path -ForegroundColor Yellow
        $Policies = $Policies | Where {$_.GroupUserName -ne "BUILTIN\Administrators"}

        #Set the Policy
        $svc.SetPolicies($Folder.Path, $Policies);
    
    }#End if $Policies

}#end foreach $Folder



 