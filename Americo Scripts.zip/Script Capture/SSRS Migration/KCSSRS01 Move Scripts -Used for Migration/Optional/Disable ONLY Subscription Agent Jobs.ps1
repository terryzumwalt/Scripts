﻿Import-Module ReportingServicesTools
Import-Module SQLServer

$Server = "SQLSSRS62"
$URI = "http://SQLSSRS62/reportserver/ReportService2010.asmx"
$Srv = New-Object("Microsoft.SQLServer.Management.SMO.Server")$Server

#list all subscriptions  
$rs2010 = New-WebServiceProxy -Uri $URI -Namespace SSRS.ReportingService2010 -UseDefaultCredential;  
$subscriptions = $rs2010.ListSubscriptions("/");  
#$SubID = $Subscriptions[0].SubscriptionID

foreach($Sub in $subscriptions)
{
    $SubPath = $Sub.Path

    #Build Query to find Agent jobs for Subscriptions
    $Query = @"
    USE ReportServer
    ;With Sch as (
             SELECT ScheduleID 
                   ,Name  
              FROM Schedule  
    )
    select --* from sch
	    c.path,  -- ,rs.*,
	    sch.name as ScheduleName
		     ,rs.ScheduleID AS SQLAgentJobName

    from Catalog c
	    join ReportSchedule rs on c.ItemID = rs.ReportID
	    join sch on rs.ScheduleID = sch.ScheduleID
	    where c.path like '%$SubPath%'
    
"@


    #Run the Query
    $Result = Invoke-Sqlcmd -ServerInstance $Server -Database "ReportServer" -Query $Query


    #Disable the Snapshot job (or mulitle on same report)
    foreach($item in $Result)
    {
        Write-Host "Disabling" $Item.SQLAgentJobName -ForegroundColor Yellow
        $JobItem = $Srv.JobServer.Jobs | Where{$_.Name -eq $item.SQLAgentJobName}
        $JobItem.IsEnabled = $False
        $JobItem.Alter()
    }


    
}#End Foreach $Sub





