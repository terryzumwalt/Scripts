﻿Import-Module ReportingServicesTools


#Specify the URI
$uri = "http://SQLSSRS62/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Uri $uri -UseDefaultCredential
$type = $svc.GetType().Namespace
$datatype = ($type + '.Property')

$DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}  

$InheritParent = $true
foreach($Folder in $DestFolderList)
{
    $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent)

    $SVCArray = "KCDOM01\smoberg","KCDOM01\SQL_DBA_PROD","KCDOM01\PROD_DB"

    foreach($User in $Policies)
    {
        if($user.GroupUserName -notin $SVCArray)
        {
            if(($User.Roles).name -Match "Content Manager" -or ($User.Roles).name -match "AME Content Manager")
            {
                  Write-Host $Folder.Path
                  Write-Host $User.GroupUserName
                  " "
                  " "

                 #Remove user from Policies
                 $Policies = $Policies|Where{$_.GroupUserName -ne $User.GroupUserName}   
                 $svc.SetPolicies($Folder.Path, $Policies)


                 $RoleList = "AME Publisher","AME Report Builder","AME Manage All Subscriptions"

                 $policyType = "{0}.Policy" -f $type
                 $roleType = "{0}.Role" -f $type
                 $Policy = New-Object ($policyType)
                 $Policy.GroupUserName = $User.GroupUserName
                 $Policy.Roles = @()

                 foreach($Role in $RoleList)
                 {
                    $r = New-Object ($roleType)
                    $r.Name = $Role
                    $Policy.Roles += $r

                 }#End foreach $Role

                 $Policies += $Policy
                 $svc.SetPolicies($Folder.Path, $Policies)


            }#End if $User
        }#End foreach $User
        
    }#End foreach $User


}#End foreach $Folder
