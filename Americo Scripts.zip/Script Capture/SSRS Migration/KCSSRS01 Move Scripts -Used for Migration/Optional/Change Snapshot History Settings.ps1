﻿
#This secton reads the snapshot schedule and Sets the number of Copies #######
#Import-module ReportingServicesTools

#Specify the URI
$uri = "http://sqlssrs62/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential

#Import List of Reports as Objects
$reports = $svc.ListChildren("/", $true) | Where-Object { $_.TypeName -eq "Report" }

#Specify an array of paths
#$Array = Get-Content "C:\Automation\TSTFileShare\HistoryChange.txt"
#$Array = "/Testing SSRS Wilfred/PolicyData"
$Array = $reports.path



#Loop throug the Array of paths to specify Individual Reports
#Set Snapshot History for each (the INT is the # of Snapshots)
foreach($Report in $Array)
{
    Write-host "Setting History for "$Report -ForegroundColor Yellow
    #Set Snapshot History Limmit
    $svc.SetItemHistoryLimit($Report,$False,90)
}





