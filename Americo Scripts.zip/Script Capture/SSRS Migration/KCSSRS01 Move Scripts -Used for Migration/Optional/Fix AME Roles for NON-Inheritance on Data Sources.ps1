﻿$Server = "SQLSSRS62"
$uri = "http://$Server/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $uri -UseDefaultCredential
$type = $svc.GetType().Namespace;



#$DataSources = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "DataSource" -and $_.Path -like "/Operations/OSS/Individual Productivity/*"}  
$DataSources = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "DataSource" -and $_.Path -like "/TZ*"}  
  


$InheritParent = $True
foreach($DS in $DataSources)
{

    $Policies = $svc.GetPolicies($DS.path, [ref] $InheritParent)
    $policyType = "{0}.Policy" -f $type;
    $roleType = "{0}.Role" -f $type;

    
    if(-Not $InheritParent)
    {

        foreach($User in $Policies)
        {
            if($User.GroupUserName -ne "KCDOM01\Prod_DB" -and $User.GroupUserName -ne "KCDOM01\SQL_DBA_PROD")
            {
                

                $Array = @()
                if(($User.roles).Name -contains "Content Manager"){$Array += "AME Content Manager"}
                if(($User.roles).Name -contains "Browser"){$Array += "AME View Only"}
                if(($User.roles).Name -contains "Manage All Subscriptions"){$Array += "AME Manage All Subscriptions"}
                if(($User.roles).Name -contains "Publisher"){$Array += "AME Publisher"}
                if(($User.roles).Name -contains "My Reports"){$Array += "My Reports"}
                if(($User.roles).Name -contains "Report Builder"){$Array += "AME Report Builder"}


                $Array = $Array | Select-Object -Unique
                
                if($Array -ne $NULL)
                {
                    Write-host $Report.Path -ForegroundColor Yellow
                    Write-Host $User.GroupUserName

                    $Policies = $Policies |Where{$_.GroupUserName -ne $User.GroupUserName}
                    $svc.SetPolicies($Report.Path, $Policies);


                    $Policy = New-Object ($policyType)
                    $Policy.GroupUserName = $User.GroupUserName
                    $Policy.Roles = @()
                    $Policies += $Policy


                    foreach($Role in $Array)
                    {
                        $r = New-Object ($roleType)
                        $r.Name = $Role
                        $Policy.Roles += $r

                    }#End foreach $Role in $Array

                    #Set the Policy
                    $svc.SetPolicies($DS.Path, $Policies);
                    
                }#End if $Array

            }#End if $User ne "SQLAccountName"
            
        }#End foreach $User

    }#End if NOT $InheritParent

}#End Foreach $Report
