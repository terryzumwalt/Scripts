

IF OBJECT_ID(N'tempdb..#list') IS NOT NULL
BEGIN
	DROP TABLE #List
END
GO

--##################################

Create Table #List
(
	ID int Identity(1,1),
	job_id NVarchar(200)
);
GO
insert into #List
(
	[job_id]
)
select NAME from msdb.dbo.sysjobs where description like '%Report Server%'

GO
--select * from #List

--#######################################

declare @counter int
set @counter=(Select Count(*) from #List)

use msdb
while(@counter > 0)
	BEGIN

		declare @Jid NVarchar(100)
		set @Jid = (select job_id from #List where ID = @Counter)

		EXEC msdb.dbo.sp_update_job @job_name=@Jid,@enabled = 1

	Set @Counter = @Counter - 1
END




