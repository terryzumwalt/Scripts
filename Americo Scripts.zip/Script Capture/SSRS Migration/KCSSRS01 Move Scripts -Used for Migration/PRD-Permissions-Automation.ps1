﻿Import-Module importexcel
$Perm = import-excel "\\kcsan03\technology\DBA\SSRS\SSRS Move\SSRS Move Scripts\CombinedNewPermissions_v7.xlsx"

$Datetime = (Get-Date -Format "MMddyyyy_HH_mm")
$DeploymentLog = "DeploymentLog" + "_" + $Datetime + ".txt"
$Log = "\\kcsan03\technology\DBA\SSRS\SSRS Move\SSRS Move Scripts\Logs\$DeploymentLog"
#############################################################################################

$Server = "SQLSSRS02"
$uri = "http://$Server/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $uri -UseDefaultCredential
$type = $svc.GetType().Namespace;

$InheritParent = $True

#Make list of unique paths
$Uniq = $Perm.ReportFolder|Select-Object -Unique
#Flush Folder Permission
foreach($Path in $Uniq)
{
    Write-Host "Flushing Path $Path" -ForegroundColor Yellow
    $Policies = $svc.GetPolicies($Path, [ref] $InheritParent)
    $Policies = $Policies|Where{$_.GroupUserName -eq 'BUILTIN\Administrators'}
    $svc.SetPolicies($Path, $Policies);

}

$InheritParent = $True
foreach($Row in $Perm)
{
    $Error.Clear()
    Write-Host $Row.ReportFolder -ForegroundColor Yellow
    Write-Host $Row.UserName -ForegroundColor Green
    " "
    
    $out1 = $Row.ReportFolder >> $Log
    $out2 = $Row.UserName >> $Log
    $out3 = " "

    $Policies = $svc.GetPolicies($Row.ReportFolder, [ref] $InheritParent)

    $policyType = "{0}.Policy" -f $type;
    $roleType = "{0}.Role" -f $type;
    $GroupUserName = $Row.UserName
    $Policy = New-Object ($policyType)
    $Policy.GroupUserName = $GroupUserName
    $Policy.Roles = @()
    $Policies += $Policy

    #Sort the Roles
    $Roles = $Row.CombinedPermissions -split ","

    foreach($Role in $Roles)
    {
        $r = New-Object ($roleType)
        $r.Name = $Role
        $Policy.Roles += $r

    }#End Foreach $Role


    $svc.SetPolicies($Row.ReportFolder, $Policies);


    if($Error){$Error >> $Log}
    $out4 = " " >> $LOG
    

}#End foreach $Row