﻿
#Import-Module ReportingServicesTools

$Datetime = (Get-Date -Format "MMddyyyy_HH_mm")
$SQLGroupAddLog = "SQLGroupAdd_Log" + "_" + $Datetime + ".txt"
$Log = "\\kcsan03\technology\DBA\SSRS\SSRS Move\SSRS Move Scripts\Logs\$SQLGroupAddLog"


$Global:SrcServer = "SQLSSRS62"


#Source SSRS
$SRCuri = "http://$Global:SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$type = $svc.GetType().Namespace 
$datatype = ($type + '.Property')

$SRCFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}



$InheritParent = $True

foreach($Folder in $SRCFolderList)
{
    

    $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent)


    $AccountArray = "KCDOM01\SQL_DBA_PROD","KCDOM01\PROD_DB"

    foreach($Account in $AccountArray)
    {
        $out1 = $Folder.path + " " + ":Adding User" + " " + $Account >> $Log
        
        if($Policies.GroupUserName -notcontains $Account)
        {
            $policyType = "{0}.Policy" -f $type;
            $roleType = "{0}.Role" -f $type;
            $Policy = New-Object ($policyType)
            $Policy.GroupUserName = $Account
            $Policy.Roles = @()

            $r = New-Object ($roleType)
            $RoleName = "Content Manager"
            $r.Name = $RoleName
            $Policy.Roles += $r
            $Policies += $Policy

            $svc.SetPolicies($Folder.Path, $Policies)

        }#end if $Policies
    }#End foreach $Account
    
}#End foreach $Folder








