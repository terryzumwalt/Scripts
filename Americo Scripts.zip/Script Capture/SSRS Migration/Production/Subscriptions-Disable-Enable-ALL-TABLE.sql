use AmericoSQLMaintenance

--drop table SubscriptionCopy

create table SubscriptionCopy
(
	ReportName NVarchar(50),
	JobName NVarchar(100),
	SubscriptionDescription NVarchar(100),
	SubscriptionType NVarchar(50),
	ReportFolderPath NVarchar(100),
	rn int,
	enabled int
);