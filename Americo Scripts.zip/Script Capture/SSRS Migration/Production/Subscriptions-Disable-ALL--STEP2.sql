--Step 2: Disable All Subscription Jobs. 


DECLARE
	@count INT,
	@maxCount INT
SET @COUNT=1  
SELECT @maxCount=MAX(RN)
FROM
	[AmericoSQLMaintenance].[dbo].[SubscriptionCopy]
DECLARE
	@job_name VARCHAR(MAX)                  
WHILE @COUNT <=@maxCount        
BEGIN      
	SELECT @job_name=jobname FROM [AmericoSQLMaintenance].[dbo].[SubscriptionCopy] WHERE RN=@COUNT 
	exec msdb..sp_update_job @job_name = @job_name,@enabled = 0 
	SET @COUNT=@COUNT+1   
	PRINT @job_name   
END   
PRINT @COUNT 



