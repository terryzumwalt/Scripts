--Step 1: Backup subscription job settings (Currently Enabled or Disabled) to a perm table.


-- Drop Temp table if exists
Use ReportServer
GO

if object_id(N'tempdb..#temp') is not null
Begin
	drop table #temp
end
GO

--Create Temp Table
Create Table #Temp(
	ReportName NVarchar(200),
	JobName NVarchar(200),
	SubscriptionDescription NVarchar(200),
	SubscriptionType NVarchar(200),
	ReportFolderPath NVarchar(200),
	rn int
)
GO

USE ReportServer
-- Get Subscription Jobs and Add to #TEMP
Insert into #Temp with (Tablock)(
	ReportName,
	JobName,
	SubscriptionDescription,
	SubscriptionType,
	ReportFolderPath,
	rn
)
SELECT
c.[Name] ReportName
, CAST(s.ScheduleID AS NVARCHAR(100)) AS JobName
, ss.[Description] SubscriptionDescription
, ss.DeliveryExtension SubscriptionType
, c.[Path] ReportFolderPath
, ROW_NUMBER () OVER (ORDER BY s.ScheduleID) AS rn
FROM
ReportSchedule rs
INNER JOIN
Schedule s
ON rs.ScheduleID = s.ScheduleID
INNER JOIN
Subscriptions ss
ON rs.SubscriptionID = ss.SubscriptionID
INNER JOIN
[Catalog] c
ON rs.ReportID = c.ItemID AND ss.Report_OID = c.ItemID;
GO






-- Populate the Perm Table
use AmericoSQLMaintenance 
insert into [AmericoSQLMaintenance].[dbo].[SubscriptionCopy]
SELECT 
	t.ReportName,
	t.JobName,
	t.SubscriptionDescription,
	t.SubscriptionType,
	t.ReportFolderPath,
	t.rn,
	s.enabled
FROM
#Temp AS [t]
INNER JOIN
[msdb].dbo.[sysjobs] AS [s]
ON [t].[JobName] = CONVERT(NVARCHAR(128),[s].[name])
GO



-- Drop Temp table if exists
Use ReportServer
GO

if object_id(N'tempdb..#temp') is not null
Begin
	drop table #temp
end
GO


select * from AmericoSQLMaintenance.dbo.SubscriptionCopy


--SELECT * FROM #Temp