﻿import-module ReportingServicesTools

########### Source Data Sources ##################################################################

$Srv = "SQLSSRS61"

$SrcUri = "http://$Srv/reportserver/ReportService2010.asmx"
$RS = New-WebServiceProxy -uri $SrcUri -UseDefaultCredential -namespace "ReportingWebService"
$SrcDataSources = $RS.ListChildren('/', $true) | Where-Object {$_.TypeName -eq "DataSource"}

foreach($DS in $SrcDataSources)
{
    Write-Host "DataSource Name: "$DS.Name
    Write-Host "DataSource Path: "$DS.Path

    $RSDataSource = "http://$Srv/reportserver"
    $Datasource = Get-RsDataSource -ReportServerUri $RsDataSource -path $DS.Path


    Write-Host "User Name: "$Datasource.UserName
  


    " "
}








