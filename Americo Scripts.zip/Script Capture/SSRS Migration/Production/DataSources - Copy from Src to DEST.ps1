﻿import-module ReportingServicesTools



########### Source Data Sources ##################################################################
$SrcUri = "http://SQLSSRS62/reportserver/ReportService2010.asmx"
$RS = New-WebServiceProxy -uri $SrcUri -UseDefaultCredential -namespace "ReportingWebService"
$SrcDataSources = $RS.ListChildren('/', $true) | Where-Object {$_.TypeName -eq "DataSource"}

########## Destination Connection ###############################################################
$DestUri = "http://SQLSSRS72/reportserver/ReportService2010.asmx"
$RS = New-WebServiceProxy -uri $DestUri -UseDefaultCredential -namespace "ReportingWebService"
$DataSources = $RS.ListChildren('/', $true) | Where-Object {$_.TypeName -eq "DataSource"}
##################################################################################################


$RsDataSource = "http://SQLSSRS62/reportserver"
$DestDataSource = "http://SQLSSRS72/reportserver"


foreach($DS in $SrcDataSources)
{
    
    $Datasource = Get-RsDataSource -ReportServerUri $RsDataSource -path $DS.Path

    $Name = $DS.Name
    $Path = $DS.Path
    $Ext = $Datasource.Extension
    $Connectstring = $Datasource.ConnectString
    " "
    " "

    #Remove the DS Name from Path
    $Replace = "/" + $Name
    $Path = $Path -replace $Replace,""

    New-RsDataSource -ReportServerUri $DestDataSource -RsFolder $Path -Name $Name -Extension $Ext -ConnectionString $Connectstring -CredentialRetrieval 'Integrated'



    
}#End foreach $DS



