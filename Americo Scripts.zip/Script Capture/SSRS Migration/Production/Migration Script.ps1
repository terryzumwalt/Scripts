﻿# Rs.exe -  C:\Automation
# Run Rs.exe - .\rs.exe


#1. Login to: KCSSAS71
#2. Set-Location "C:\SSRS\TZ"
#3. Run test Migration (Below)


#ALL At ONCE --- FAILURES
rs.exe -i ssrsmigration.rss -e Mgmt2010 -s http://KCSSAS71/reportserver -v f="/" -v ts=http://SQLSSRS62/reportserver -v tf="/" -v tu="kcdom01\tzumwalt" -v tp="JayC0Tr@l3R$" -v security="True"



#ASI Production
rs.exe -i ssrsmigration.rss -e Mgmt2010 -s http://KCSSAS71/reportserver -v f="/ASI Production" -v ts=http://SQLSSRS62/reportserver -v tf="/ASI Production" -v tu="kcdom01\tzumwalt" -v tp="JayC0Tr@l3R$" -v security="True"


#DataSources
rs.exe -i ssrsmigration.rss -e Mgmt2010 -s http://KCSSAS71/reportserver -v f="/Data Sources" -v ts=http://SQLSSRS62/reportserver -v tf="/Data Sources" -v tu="kcdom01\tzumwalt" -v tp="JayC0Tr@l3R$" -v security="True"

#Business and Implementation Support
rs.exe -i ssrsmigration.rss -e Mgmt2010 -s http://KCSSAS71/reportserver -v f="/Business and Implementation Support" -v ts=http://SQLSSRS62/reportserver -v tf="/Business and Implementation Support" -v tu="kcdom01\tzumwalt" -v tp="JayC0Tr@l3R$" -v security="True"


#Heathers Folder
rs.exe -i ssrsmigration.rss -e Mgmt2010 -s http://KCSSAS71/reportserver -v f="/Heathers Folder" -v ts=http://SQLSSRS62/reportserver -v tf="/Heathers Folder" -v tu="kcdom01\tzumwalt" -v tp="JayC0Tr@l3R$" -v security="True"


#Information Technology
rs.exe -i ssrsmigration.rss -e Mgmt2010 -s http://KCSSAS71/reportserver -v f="/Information Technology" -v ts=http://SQLSSRS62/reportserver -v tf="/Information Technology" -v tu="kcdom01\tzumwalt" -v tp="JayC0Tr@l3R$" -v security="True"


#Internal Audit
rs.exe -i ssrsmigration.rss -e Mgmt2010 -s http://KCSSAS71/reportserver -v f="/Internal Audit" -v ts=http://SQLSSRS62/reportserver -v tf="/Internal Audit" -v tu="kcdom01\tzumwalt" -v tp="JayC0Tr@l3R$" -v security="True"


################## DB Account ###########################
#DataSources
rs.exe -i ssrsmigration.rss -e Mgmt2010 -s http://KCSSAS71/reportserver -v f="/Data Sources" -v ts=http://SQLSSRS62/reportserver -v tf="/Data Sources" -v tu="kcdom01\tzumwalt-db" -v tp="0n_cS?U.g+rW~vs" -v security="True"

#Business and Implementation Support
rs.exe -i ssrsmigration.rss -e Mgmt2010 -s http://KCSSAS71/reportserver -v f="/Business and Implementation Support" -v ts=http://SQLSSRS62/reportserver -v tf="/Business and Implementation Support" -v tu="kcdom01\tzumwalt-db" -v tp="0n_cS?U.g+rW~vs" -v security="True"





<#

1. Add KCDOM01\SQL_DBA_PROD to every folder and sub folder
-- also check Data Sources
2. Run scripts as DB Account




####### INVESTIGATE ###########
Re-linking references for item PAS Grace and Lapse Dashboard reporting ... FAILURE:
The item '/Business and Implementation Supportint' cannot be found. ---> Microsoft.ReportingServices.Diagnostics.Utiliti
es.ItemNotFoundException: The item '/Business and Implementation Supportint' cannot be found.



Re-linking references for item PAS Drafts ... FAILURE:
The item '/Business and Implementation SupporticoDW' cannot be found. ---> Microsoft.ReportingServices.Diagnostics.Utili
ties.ItemNotFoundException: The item '/Business and Implementation SupporticoDW' cannot be found.



Schedules Failing: Verify when the job creates that its re-creating the schedule and the Schedule matches Src. 




############ Accurate Errors / Expect these #########################
The report server cannot process the report or shared dataset. The shared data source 'KCSQL16' for the report server is
 not valid. Browse to the server or site and select a shared data source. ---> Microsoft.ReportingServices.Diagnostics.U
tilities.InvalidDataSourceReferenceException: The report server cannot process the report or shared dataset. The shared
data source 'KCSQL16' for the report server is not valid. Browse to the server or site and select a shared data source.


The report server cannot process the report or shared dataset. The shared data source 'DataSource1' for the report serve
r is not valid. Browse to the server or site and select a shared data source. ---> Microsoft.ReportingServices.Diagnosti
cs.Utilities.InvalidDataSourceReferenceException: The report server cannot process the report or shared dataset. The sha
red data source 'DataSource1' for the report server is not valid. Browse to the server or site and select a shared data
source.
#>



#     0n_cS?U.g+rW~vs
#     KCDOM01\SQL_DBA_PROD