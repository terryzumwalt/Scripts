﻿#NOTE:  This script is ran from SQLSSRS72 > C:\SQL\Automation
#The Job is on that server too.

Import-Module ReportingServicesTools


$Global:SrcServer = "SQLSSRS62"
$Global:DestServer = "SQLSSRS72"



Function Logging
{
    $Global:DestDB = "Replication_SSRS_PS"

    $Query = @"
        insert into Logging
        Values('$Global:TimeCollected','$Global:LogType','$Global:ItemPath','$Global:Info','$Global:Source_Users','$Global:Source_Roles','$Global:Destination_Users','$Global:Destination_Roles')
"@

    
    invoke-sqlcmd -ServerInstance $Global:DestServer -Database $Global:DestDB -Query $Query


    $Global:TimeCollected = $NULL
    $Global:LogType = $Null
    $Global:ItemPath = $NULL
    $Global:Info = $NULL
    $Global:Source_Users = $NULL
    $Global:Source_Roles = $NULL
    $Global:Destination_Users = $NULL
    $Global:Destination_Roles = $NULL

    
    
}#End Function Logging






Function FoldersMain
{
    $Error.clear()
    ######################################################
    ####### Query Source for List of Folder Paths ########
    #Specify the URI (SRC Server)
    $Srcuri = "http://$Global:SrcServer/reportserver/ReportService2010.asmx"
    #Create WebProxy(Connection to SSRS Server and Data)
    #$Srcsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $Srcuri -UseDefaultCredential
    $Srcsvc = New-WebServiceProxy -Class 'RS' -Uri $Srcuri -UseDefaultCredential
    $Srctype = $Srcsvc.GetType().Namespace
    $Srcdatatype = ($type + '.Property')
    $SrcFolders = $Srcsvc.ListChildren("/", $true) | Where{$_.TypeName -eq "Folder"}
  
    ###############################################################
    ##### Query Dest for list of existing paths #####
    #Specify the URI (used for Obtaining the path list)
    $uri = "http://$Global:DestServer/reportserver/ReportService2010.asmx"
    #Create WebProxy(Connection to SSRS Server and Data)
    #$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
    $svc = New-WebServiceProxy -Class 'RS' -Uri $uri -UseDefaultCredential
    $type = $svc.GetType().Namespace
    $datatype = ($type + '.Property')
    $DestFolders = $svc.ListChildren("/", $true) | Where{$_.TypeName -eq "Folder"}
    $RS = "http://$Global:DestServer/ReportServer"

    

    ### Ensure there were no failures ###
    if($Srcsvc -eq $NULL -or $svc -eq $NULL -or $Error)
    {
        if($Srcsvc -eq $NULL){$Failed = $Global:SrcServer}
        if($svc -eq $NULL){$Failed = $Global:DestServer}
        

        ## Write Log Entery ####
        $Global:TimeCollected = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $Global:LogType = "Connect Failure $Failed"
        $Global:ItemPath = "Error On Connect"
        $Global:Info = "Please Check $Failed for connection issues."
        $Global:Source_Users = $NULL
        $Global:Source_Roles = $NULL
        $Global:Destination_Users = $NULL
        $Global:Destination_Roles = $NULL

        Logging
        ########################

        
    }#End If
    
    ########################################################################################

    $InheritParent = $true


    #Test for Folders
    foreach($Folder in $SrcFolders)
    {
        
        #Add Folder to Dest if missing
        if($DestFolders.path -notcontains $Folder.path)
        {
            #Write-Host "Missing" $Folder.Path -ForegroundColor Yellow

            ## Write Log Entery ####
            $Global:TimeCollected = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            $Global:LogType = "Folder"
            $Global:ItemPath = $Folder.Path
            $Global:Info = "Replicating a missing folder on $Global:DestServer"
            $Global:Source_Permissions = $NULL
            $GLobal:Source_Roles = $NULL
            $Global:Destination_Permissions = $NULL
            $Global:Destination_Roles = $NULL
            Logging
            ########################


            $i = 0
            $PathArray = ($Folder.path -split '/') | Where{$_ -ne ""}
            foreach($item in $PathArray)
            {
                

                #Test folder levels starting at 0 then see if it exists on the Dest side
                if($i -eq 0){$Test = "/" + $PathArray[0]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}
                if($i -eq 1){$Test = "/" + $PathArray[0] + "/" + $PathArray[1]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}
                if($i -eq 2){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}
                if($i -eq 3){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2] + "/" + $PathArray[3]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}
                if($i -eq 4){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2] + "/" + $PathArray[3] + "/" + $PathArray[4]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}

                if($Verify.length -gt 0){Write-Host "Existing Path:" $Test;}
                if($Verify.length -lt 1){Write-Host "Creating Path:" $Test;}


                if($Verify.length -lt 1)#Path does not exist
                {
                    if($i -eq 0){$Root = "/" ; $Path = $Item }
                    if($i -eq 1){$Root = "/" + $PathArray[0] ;$Path = $Item }
                    if($i -eq 2){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]; $Path = $Item }
                    if($i -eq 3){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2]; $Path = $Item }
                    if($i -eq 4){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2]  + "/" + $PathArray[3]; $Path = $Item }

                    New-RsFolder -reportserveruri $RS -RsFolder $Root -foldername $Path       #-ErrorAction SilentlyContinue
               
                }#End if $Verify




                $i = $i+ 1

            }#End foreach $item

        }#End if $DestFolder


    }#End Foreach Folder
   
}#End Function FoldersMain


Function PermissionsMain
{
    Sleep -Seconds 10
    
    #Dest SSRS
    $uri = "http://SQLSSRS72/reportserver/ReportService2010.asmx"
    $svc = New-WebServiceProxy -Class 'RS' -Uri $uri -UseDefaultCredential
    $type = $svc.GetType().Namespace #------ Remove NameSpace from $Svc and use this only to prevent permissions looking issues.
    $datatype = ($type + '.Property')

    #Source SSRS
    $SRCuri = "http://SQLSSRS62/reportserver/ReportService2010.asmx"
    $SRCsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $SRCuri -UseDefaultCredential
    ##################################################################################################################################
    $InheritParent = $true

    $SRCFolderList = $SRCsvc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
    $DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"} 

    
    
    ########################################### Add Missing Users ######################################################################
    foreach($Folder in $SRCFolderList)
    {
        #$Folder = $SRCFolderList|Where{$_.Path -eq "/Legal"}

        #$svc = New-WebServiceProxy -Class 'RS' -Uri $uri -UseDefaultCredential
        #$SRCsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $SRCuri -UseDefaultCredential

        
        $SRCPolicies = $SRCsvc.GetPolicies($Folder.path, [ref] $InheritParent )
        $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent )

        foreach($User in $SRCPolicies)
        {
            
            if($User.GroupUserName -ne "BUILTIN\Administrators")
            { 
                if($Policies.GroupUserName -notcontains $User.GroupUserName)
                {

                    $policyType = "{0}.Policy" -f $type
                    $roleType = "{0}.Role" -f $type
                    $Policy = New-Object ($policyType)
                    $Policy.GroupUserName = $User.GroupUserName
                    $Policy.Roles = @()  

                    foreach($Role in ($User.Roles).name)
                    {
                        $r = New-Object ($roleType)      
                        $r.Name = $Role
                        $Policy.Roles += $r
                    }

                    $Policies += $Policy

                    $svc.SetPolicies($Folder.Path, $Policies)

                    ############################################
                    #Logging
                    $SrcUsers = $SRCPolicies.GroupUserName
                    $SrcRoles = ($SRCPolicies.Roles).name
                    $DestUsers = $Policies.GroupUserName
                    $DestRoles = ($Policies.Roles).Name

                    ## Write Log Entery ####
                    $Global:TimeCollected = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
                    $Global:LogType = "Permissions"
                    $Global:ItemPath = $Folder.Path
                    $Global:Info = "Replicating a missing Permissions for $Folder.path on $Global:DestServer."
                    $Global:Source_Users = $SrcUsers
                    $GLobal:Source_Roles = $SrcRoles
                    $Global:Destination_Users = $DestUsers
                    $Global:Destination_Roles = $DestRoles
                    Logging



                }#End if $Policies
            }#End if $User
        }#End foreach $User
    }#End Foreach $Folder



    ########################################### Delete Removed Accounts ######################################################################
    foreach($Folder in $SRCFolderList)
    {
        #$svc = New-WebServiceProxy -Class 'RS' -Uri $uri -UseDefaultCredential
        #$SRCsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $SRCuri -UseDefaultCredential

        
        $SRCFolderList = $SRCsvc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
        $DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"} 

        $SRCPolicies = $SRCsvc.GetPolicies($Folder.path, [ref] $InheritParent )
        $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent )

        $Policies = $Policies|Where{$_.GroupUserName -ne "BUILTIN\Administrators" -and $_.GroupUserName -ne "KCDOM01\SQL_DBA_PROD" -and $_.GroupUserName -ne "KCDOM01\Prod_DB" -and $_.GroupUserName -ne "KCDOM01\svc_SQLAutomation_L"}
        $SRCPolicies = $SRCPolicies|Where{$_.GroupUserName -ne "BUILTIN\Administrators"}

        $Counter = 0
        $BadNames = @()
        #Compare User List
        foreach($UserName in $Policies.groupUserName)
        {
            if($SrcPolicies.GroupUserName -notcontains $UserName)
            {
                $BadNames += $UserName
                #$UserName
                $Counter = $Counter + 1
            }
        }#End foreach $Username


        if($Counter -gt 0)
        {
            foreach($Name in $BadNames)
            {
                $Policies = $Policies|Where{$_.GroupUserName -ne $Name}
                $svc.SetPolicies($Folder.Path, $Policies)
            }
        }


        <#

        ##Above Im resetting the policy with out the name instead of rebuilding it here. ###
        #Restore Src permissions
        if($Counter -gt 0)
        {
            $Policies = $Policies|Where{$_.GroupUserName -eq "BUILTIN\Administrators"} #Do this to flush the policy for rebuild

            foreach($User in $SRCPolicies)
            {
                if($user.GroupUserName -ne "BUILTIN\Administrators")
                {
                    $policyType = "{0}.Policy" -f $type
                    $roleType = "{0}.Role" -f $type
                    $Policy = New-Object ($policyType)
                    $Policy.GroupUserName = $User.GroupUserName
                    $Policy.Roles = @()

                    foreach($Role in ($User.Roles).name)
                    {
                        $r = New-Object ($roleType)
                        $r.Name = $Role
                        $Policy.Roles += $r
                    }

                    $Policies += $Policy
                    $svc.SetPolicies($Folder.Path, $Policies)


                    ############################################
                    #Logging
                    $SrcUsers = $SRCPolicies.GroupUserName
                    $SrcRoles = ($SRCPolicies.Roles).name
                    $DestUsers = $Policies.GroupUserName
                    $DestRoles = ($Policies.Roles).Name

                    ## Write Log Entery ####
                    $Global:TimeCollected = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
                    $Global:LogType = "Permissions"
                    $Global:ItemPath = $Folder.Path
                    $Global:Info = "Removing Deleted User for $Folder.path on $Global:DestServer."
                    $Global:Source_Users = $SrcUsers
                    $GLobal:Source_Roles = $SrcRoles
                    $Global:Destination_Users = $DestUsers
                    $Global:Destination_Roles = $DestRoles
                    Logging


                }#End if $user
            }#End foreach $User
            
        }#End If Counter
        #>

    }#end foreach $Folder








    ########################################### Update Missing Permissions ######################################################################
    foreach($Folder in $SRCFolderList)
    {
        #$svc = New-WebServiceProxy -Class 'RS' -Uri $uri -UseDefaultCredential
        #$SRCsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $SRCuri -UseDefaultCredential


        $SRCFolderList = $SRCsvc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
        $DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"} 

        $SRCPolicies = $SRCsvc.GetPolicies($Folder.path, [ref] $InheritParent )
        $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent )

        foreach($User in $SRCPolicies)
        {
            if($User.GroupUserName -ne "BUILTIN\Administrators")
            {

                $Compare = $Policies | Where{$_.GroupUserName -eq $User.GroupUserName}

                #Compare roles on each user
                $SrcRoles = ($User.Roles).Name
                $DestRoles = ($Compare.Roles).Name


                foreach($Role in $SrcRoles)
                {
                    if($DestRoles -notcontains $Role -or $DestRoles.count -ne $SrcRoles.Count)
                    {

                        $Folder.Path
                        $User.GroupUserName
                        $Role
                        " "
                        " "

                        ### Remove user from policy and re-ad
                        $Policies = $Policies|Where{$_.GroupUserName -ne $User.GroupUserName}

                        $policyType = "{0}.Policy" -f $type
                        $roleType = "{0}.Role" -f $type
                        $Policy = New-Object ($policyType)
                        $Policy.GroupUserName = $User.GroupUserName
                        $Policy.Roles = @()

                        foreach($Role in ($User.Roles).name)
                        {
                            $r = New-Object ($roleType)
                            $r.Name = $Role
                            $Policy.Roles += $r
                        }

                        $Policies += $Policy

                        $svc.SetPolicies($Folder.Path, $Policies)

                        ############################################
                        #Logging
                        $SrcUsers = $SRCPolicies.GroupUserName
                        $SrcRoles = ($SRCPolicies.Roles).name
                        $DestUsers = $Policies.GroupUserName
                        $DestRoles = ($Policies.Roles).Name

                        ## Write Log Entery ####
                        $Global:TimeCollected = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
                        $Global:LogType = "Permissions"
                        $Global:ItemPath = $Folder.Path
                        $Global:Info = "Updating missing Permissions for $Folder.path on $Global:DestServer."
                        $Global:Source_Users = $SrcUsers
                        $GLobal:Source_Roles = $SrcRoles
                        $Global:Destination_Users = $DestUsers
                        $Global:Destination_Roles = $DestRoles
                        Logging


                    }
                }#End foreach $Role
            }#End if $Username -ne
        }#End foreach $User

    }#End foreach $Folder


    ###############




    ########################################### Add Alternate Groups and Accounts ######################################################################
    foreach($Folder in $SRCFolderList)
    {
        #$svc = New-WebServiceProxy -Class 'RS' -Uri $uri -UseDefaultCredential
        #$SRCsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $SRCuri -UseDefaultCredential

        $SRCFolderList = $SRCsvc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
        $DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"} 

        $SRCPolicies = $SRCsvc.GetPolicies($Folder.path, [ref] $InheritParent )
        $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent )


        $AccountArray = "KCDOM01\SQL_DBA_PROD","KCDOM01\PROD_DB","KCDOM01\svc_SQLAutomation_L"

        foreach($Account in $AccountArray)
        {
            if($Policies.GroupUserName -notcontains $Account)
            {
                $policyType = "{0}.Policy" -f $type;
                $roleType = "{0}.Role" -f $type;
                $Policy = New-Object ($policyType)
                $Policy.GroupUserName = $Account
                $Policy.Roles = @()

                $r = New-Object ($roleType)
                $RoleName = "Content Manager"
                $r.Name = $RoleName
                $Policy.Roles += $r
                $Policies += $Policy

                $svc.SetPolicies($Folder.Path, $Policies)

            }#end if $Policies
        }#End foreach $Account
    
    }#End foreach $Folder







}#End Function Permissions Main



##### Action Script ######
FoldersMain
PermissionsMain

