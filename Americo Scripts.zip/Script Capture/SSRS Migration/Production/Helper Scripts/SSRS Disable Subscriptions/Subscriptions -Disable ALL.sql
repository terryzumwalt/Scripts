/*
Process Testing:
-- Simulate the Migration
-- Do the Databse Restore (Do the jobs transfer)



Changes: 
1. Dump #Temp in to a permenant table (try to filter for only enabled jobs)(How to do that?)
2. get your data from that table
3. Disable based on that table
4. (Complete)-- fix tsql formating

INFO: AmericoSQLMaintenance.dbo.SubscriptionCopy
-- Filter for enabled Jobs
/*
-- Add If job is enabled or not
-- add enabled Column to the Perm table if the job is enabled or not
Join from JobName - both tables
--NOTE: Look at Datatypes and my be convert (Cast) or force colliation keyword Collate 

-- for JobName use this convert:  SELECT CONVERT(VARCHAR(100),NEWID())

--	SELECT @job_name=jobname ,@Enabled = Enabled FROM [AmericoSQLMaintenance].[dbo].[SubscriptionCopy] WHERE RN=@COUNT 
--	exec msdb..sp_update_job @job_name = @job_name,@enabled = @enabled  
-- if @enabled = 1 then ()
*/

*/

--select * from dbo.Subscriptions


--Drop Perm Table if Exists
Use AmericoSQLMaintenance
GO
if OBJECT_ID(N'dbo.SubscriptionCopy',N'U') IS NOT NULL
	Drop Table [dbo].[SubscriptionCopy];
GO

-- Drop Temp table if exists
Use ReportServer
GO

if object_id(N'tempdb..#temp') is not null
Begin
	drop table #temp
end
GO

--Create Temp Table
Create Table #Temp(
	ReportName NVarchar(50),
	JobName NVarchar(100),
	SubscriptionDescription NVarchar(100),
	SubscriptionType NVarchar(50),
	ReportFolderPath NVarchar(100),
	rn int
)


-- Get Subscription Jobs and Add to #TEMP
Insert into #Temp with (Tablock)(
	ReportName,
	JobName,
	SubscriptionDescription,
	SubscriptionType,
	ReportFolderPath,
	rn
)
SELECT
c.[Name] ReportName
--s.ScheduleID JobName, -- Wrap Convert around this line
, CAST(s.ScheduleID AS NVARCHAR(100)) AS JobName
, ss.[Description] SubscriptionDescription
, ss.DeliveryExtension SubscriptionType
, c.[Path] ReportFolderPath
, ROW_NUMBER () OVER (ORDER BY s.ScheduleID) AS rn
FROM
ReportSchedule rs
INNER JOIN
Schedule s
ON rs.ScheduleID = s.ScheduleID
INNER JOIN
Subscriptions ss
ON rs.SubscriptionID = ss.SubscriptionID
INNER JOIN
[Catalog] c
ON rs.ReportID = c.ItemID AND ss.Report_OID = c.ItemID;


-- Populate the Perm Table
use AmericoSQLMaintenance 
insert into [AmericoSQLMaintenance].[dbo].[SubscriptionCopy]
SELECT 
	t.ReportName,
	t.JobName,
	t.SubscriptionDescription,
	t.SubscriptionType,
	t.ReportFolderPath,
	t.rn,
	s.enabled
FROM
#Temp AS [t]
INNER JOIN
[msdb].dbo.[sysjobs] AS [s]
ON [t].[JobName] = CONVERT(NVARCHAR(128),[s].[name])





--select * from dbo.SubscriptionCopy



-- Disable Subscription Jobs

DECLARE
	@count INT,
	@maxCount INT,
	@Enabled INT
SET @COUNT=1  
SELECT @maxCount=MAX(RN)
FROM
	[AmericoSQLMaintenance].[dbo].[SubscriptionCopy]
DECLARE
	@job_name VARCHAR(MAX)                  
WHILE @COUNT <=@maxCount        
BEGIN      
	SELECT @job_name=jobname,@Enabled=enabled FROM [AmericoSQLMaintenance].[dbo].[SubscriptionCopy] WHERE RN=@COUNT 
	exec msdb..sp_update_job @job_name = @job_name,@enabled = @enabled  
	SET @COUNT=@COUNT+1   
	PRINT @job_name   
END   
PRINT @COUNT 
PRINT @Enabled


