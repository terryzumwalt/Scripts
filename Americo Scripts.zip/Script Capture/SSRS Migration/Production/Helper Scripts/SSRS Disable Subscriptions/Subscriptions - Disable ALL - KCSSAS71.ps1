﻿Import-Module ReportingServicesTools


$URI = "http://KCSSAS71/reportserver/ReportService2010.asmx"

####### Microsoft Method 1 - Individual Subscriptions ##########
#list all subscriptions  
$rs2010 = New-WebServiceProxy -Uri $URI -Namespace SSRS.ReportingService2010 -UseDefaultCredential;  
$subscriptions = $rs2010.ListSubscriptions("/"); 
 



#Disable All Subscriptions
ForEach ($subscription in $subscriptions)  
{  
    #Disable Subscription
    $rs2010.DisableSubscription($subscription.SubscriptionID);
    
    #Output what was disabled  
    $subscription | select subscriptionid, report, path  

}  



<#
#Enable All Subscriptions
ForEach ($subscription in $subscriptions)
{
    #Enable Subscription
    $rs2010.EnableSubscription($subscription.SubscriptionID);
    
    #Output what was enabled  
    $subscription | select subscriptionid, report, path  
   
}
#>