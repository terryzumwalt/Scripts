﻿
#https://www.sqlshack.com/managing-ssrs-security-using-powershell-automation-scripts/

Import-Module ReportingServicesTools

<#

Servers:
 
SQLSSRS62 > SQLSSRS72


#>




####################################################################################
##### Set Destination Server and get Folder list ###################################

#Specify the URI
$uri = "http://SQLSSRS72/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
$type = $svc.GetType().Namespace;

$DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder" -and $_.Path -like "*TZ*"} #


###############################################################
##### Query Source Server for Folder List #####

#Specify the URI
$SRCuri = "http://SQLSSRS62/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$SRCsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $SRCuri -UseDefaultCredential

$SRCFolderList = $SRCsvc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder" -and $_.Path -like "*TZ*" } #


############ Get Folder Policy and Apply to Dest ##############
$InheritParent = $true



foreach($Folder in $SRCFolderList)
{
    Write-Host "Folder:" $Folder.Path -ForegroundColor DarkYellow

    ## Get Policy from Source Folder ##
    $SRCPolicies = $SRCsvc.GetPolicies($Folder.path, [ref] $InheritParent )
    
    


    if(-not $InheritParent)
    {

        $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent )
        

        

        foreach($Name in $SRCPolicies)
        {
            $policyType = "{0}.Policy" -f $type;
            $roleType = "{0}.Role" -f $type;
            $Policy = New-Object ($policyType)
            $Policy.Roles = @()

            Write-Host "Using: "$Name.GroupUserName -ForegroundColor yellow
            $Policy.GroupUserName = $Name.GroupUserName

            #Test that the new name is not already in Policies
            if($Policies.groupusername -notcontains $Policy.GroupUserName)
            {
                Write-Host "Adding Policy for: " $Name.GroupUserName

                #Add GroupUserName to Policy
                $Policies += $Policy

            



                #Add Roles to Policy
                foreach($Role in $Name.Roles)
                {
                                
                    $RoleName = $role.name 

                    $R = $policy.Roles | Where-object {$_.Name -eq $RoleName} | Select-Object -First 1
                    if(-not $R)
                    {
                        if($RoleName -notlike "*Manage All Subscriptions*") #Were bringing this role to the environment
                        {
                            $r = New-Object ($roleType)          
                            $r.Name = $RoleName
                            $Policy.Roles += $r
                        }
                                       
                    }#End IF -Not $r
                
                }#End Foreach $Role

                $Policies

                #Set new policy on the folder
                $svc.SetPolicies($Folder.Path, $Policies);

            }#End If $Policies
    

        }#End foreach $Name

    " "
    " "
    " "
    
    }#End if NOT $Inheritparent



}#end foreach $Folder





