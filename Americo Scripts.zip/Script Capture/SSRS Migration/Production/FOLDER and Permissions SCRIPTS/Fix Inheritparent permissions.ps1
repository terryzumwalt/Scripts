﻿#https://www.sqlshack.com/managing-ssrs-security-using-powershell-automation-scripts/

Import-Module ReportingServicesTools

<#

Servers:
 
SQLSSRS62 > SQLSSRS72


#>





#####################################################################################
##### Query Source Server for Folder List #####

#Specify the URI
$SRCuri = "http://SQLSSRS62/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$SRCsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $SRCuri -UseDefaultCredential

$SRCFolderList = $SRCsvc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder" -and $_.Path -like "*TZ*" } 

####################################################################################
##### Set Destination Server and get Folder list ###################################

#Specify the URI
$uri = "http://SQLSSRS72/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
$type = $svc.GetType().Namespace;

$DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder" -and $_.Path -like "*TZ*"} #

######################################################################################

$InheritParent = $true


foreach($Folder in $SRCFolderList)
{
    if($InheritParent)
    {
        #Fix Permissions on Dest
        $svc.InheritParentSecurity($Folder.path)
    }
}









