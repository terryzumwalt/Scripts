﻿
#https://www.sqlshack.com/managing-ssrs-security-using-powershell-automation-scripts/


<#
    Manually add permissions to the HOME Folder /

#>


Import-Module ReportingServicesTools

################################################################
##### Set Destination Server ###################################

#Specify the URI
$uri = "http://SQLSSRS62/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
$type = $svc.GetType().Namespace;

$DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"} #-and $_.Path -like "*TZ*"





$InheritParent = $true
foreach($Folder in $DestFolderList)
{
    
    
    $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent)
    $policyType = "{0}.Policy" -f $type;
    $roleType = "{0}.Role" -f $type;
    #$GroupUserName = 'KCDOM01\SQL_DBA_Prod'
    $GroupUserName = 'KCDOM01\Prod_DB'
    $RoleName = 'Content Manager'


    #This loop filters for folders NOT inheriting permissions
    if( -not $InheritParent)
    {
        Write-Host $Folder -ForegroundColor Yellow
        
        #Add the New Policy
        $Policy = New-Object ($policyType)
        $Policy.GroupUserName = $GroupUserName
        $Policy.Roles = @()
        
        #Add new User to Policy
        $Policies += $Policy


        #Add Roles to the new Policy
        $R = $policy.Roles | Where-object {$_.Name -eq $RoleName} | Select-Object -First 1
        if(-not $R)
        {
            $r = New-Object ($roleType)
            $r.Name = $RoleName
            $Policy.Roles += $r
        }


        #Set the Policy
        $svc.SetPolicies($Folder.Path, $Policies);

    
    }#End if NOT $inheritparent
}#End Foreach $Folder




