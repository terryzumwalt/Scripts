﻿
#https://www.sqlshack.com/managing-ssrs-security-using-powershell-automation-scripts/


################################################################
##### Set Destination Server ###################################

#Specify the URI
$uri = "http://sqlssrs62/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential

$SRCFolderList = $svc.ListChildren("/", $true) | select -Property Path ,TypeName |Where{$_.TypeName -eq "Folder"} #-and $_.Path -like "*TZ*"
################################################################


$InheritParent = $true

foreach($Folder in $SRCFolderList)
{
    
    $Policies = $svc.GetPolicies( $folder.path, [ref] $InheritParent )

    if(-not $InheritParent)
    {
        write-Host $Folder.path -ForegroundColor Yellow
        $Policies = $Policies | Where {$_.GroupUserName -ne "BUILTIN\Administrators"}

        #Set the Policy
        $svc.SetPolicies($Folder.Path, $Policies);
    }


}#end foreach $Folder



 