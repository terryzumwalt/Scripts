﻿
Import-Module ReportingServicesTools

<#
    This script DOES NOT make changes.
    Use this script to determind what SSRS Folders are inheriting permissions. 
    By changing if($InheritParent) to if( -not $InheritParent) you can look for custom permissions folders.

#>


$ServerName = "SQLSSRS62"


###############################################################
##### Query Source Server for Folder List #####

#Specify the URI
$SRCuri = "http://$ServerName/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$SRCsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $SRCuri -UseDefaultCredential

$SRCFolderList = $SRCsvc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"} 


$InheritParent = $true

foreach($Folder in $SRCFolderList)
{
    $Policies = $SRCsvc.GetPolicies($Folder.path, [ref] $InheritParent)
    if($InheritParent)
    {
        $Folder.path
    }

}


