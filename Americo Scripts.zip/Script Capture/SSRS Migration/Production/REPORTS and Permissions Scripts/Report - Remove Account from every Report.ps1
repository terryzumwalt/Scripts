﻿
#https://www.sqlshack.com/managing-ssrs-security-using-powershell-automation-scripts/

import-module ReportingServicesTools
################################################################
##### Set Destination Server ###################################

#Specify the URI
$uri = "http://sqlssrs62/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential

$Reports = $svc.ListChildren("/", $true) | select -Property Path ,TypeName |Where{$_.TypeName -eq "Report"} # -and $_.Path -like "*Wilfred*"
################################################################


$InheritParent = $true

foreach($Report in $Reports)
{
    
    $Policies = $svc.GetPolicies( $Report.path, [ref] $InheritParent )


    #### MODIFY This with if ACCOUNT exists, make the change. ###########

    if(-not $InheritParent)
    {
        write-Host $Folder.path -ForegroundColor Yellow
        #$Policies = $Policies | Where {$_.GroupUserName -ne "KCDOM01\SQL_DBA_Prod"}
        $Policies = $Policies | Where {$_.GroupUserName -ne "BUILTIN\Administrators"}

        #Set the Policy
        $svc.SetPolicies($Report.Path, $Policies);
    }


}#end foreach $Folder



 