﻿

Import-Module ReportingServicesTools
###############################################################
##### Query Source Server for Folder List #####

#Specify the URI
$SRCuri = "http://KCSSAS71/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $SRCuri -UseDefaultCredential
$type = $svc.GetType().Namespace;

$Reports = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report" -and $_.Path -like "*Wilfred*"} # -and $_.Path -like "*TZ*" 

$Reports


###############################################################
##### Query Destniation Server for Folder List #####

#Specify the URI
$Desturi = "http://SQLSSRS72/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $Desturi -UseDefaultCredential
$type = $svc.GetType().Namespace;

$Reports = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report" -and $_.Path -like "*Wilfred*"} # -and $_.Path -like "*TZ*" 

$Reports

#################################################################

$InheritParent = $True
foreach($Rpt in $Reports)
{
    $Policies = $svc.GetPolicies($Rpt.path, [ref] $InheritParent)
    $policyType = "{0}.Policy" -f $type;
    $roleType = "{0}.Role" -f $type;
    $GroupUserName = 'KCDOM01\tzumwalt'
    $RoleName = 'Content Manager','Browser'


    if(-not $InheritParent)
    {
        #Add the New Policy
        $Policy = New-Object ($policyType)
        $Policy.GroupUserName = $GroupUserName
        $Policy.Roles = @()
        
        #Add new User to Policy
        $Policies += $Policy

        #Add Roles to the new Policy
        foreach($Role in $RoleName)
        {
            $R = $policy.Roles | Where-object {$_.Name -eq $RoleName} | Select-Object -First 1
            if(-not $R)
            {
                $r = New-Object ($roleType)
                $r.Name = $Role
                $Policy.Roles += $r
            }
        }#End Foreach $Role

        #Set the Policy
        $svc.SetPolicies($Rpt.Path, $Policies);

    }#End if NOT $inheritparent



}#End foreach $Rpt







