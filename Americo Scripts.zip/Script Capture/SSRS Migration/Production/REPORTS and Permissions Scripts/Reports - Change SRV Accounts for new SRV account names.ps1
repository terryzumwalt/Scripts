﻿#Import-Module ReportingServicesTools



<#

    To use this script
    Add the role you want to change to these variables in the script:
    $BadRole   <---- Old account to be replaced
    $NewRole   <---- The new account

    This script will also NOT make chagnes to the following:
     "KCDOM01\SQL_DBA_PROD" 
     "KCDOM01\Prod_DB"
#>





################################################################
##### Set Destination Server ###################################

#Specify the URI
$uri = "http://SQLSSRS62/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
$type = $svc.GetType().Namespace;

$Reports = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report"} #-and $_.Path -like "*TZ*" 




$InheritParent = $true
foreach($Report in $Reports)
{
    ##################################################################
    ###### The Role you want to Change and What to change it to ######
    #$BadRole = "Content Manager"
    #$NewRole = "AME Content Manager"

    $BadRole = 'Publisher'
    $NewRole = 'AME Publisher'
    ###################################################################
    ###################################################################

    #Get the Folders Policies
    $Policies = $svc.GetPolicies($Report.path, [ref] $InheritParent)

    $policyType = "{0}.Policy" -f $type;
    $roleType = "{0}.Role" -f $type;


    if(-not $InheritParent)
    {

         #Loop through the users (Exclude accounts that need to keep permissions)
        foreach($User in $Policies | Where{$_.GroupUserName -ne "KCDOM01\SQL_DBA_PROD" -and $_.GroupUserName -ne "KCDOM01\Prod_DB"})
        {
            #Cache the user roles
            $Roles = $user.roles
        
            #Check User for the Role that needs changed (Make Change if Exists)
            if($Roles.name -contains $BadRole)
            {
                Write-host "Processing.... "$user.GroupUserName -ForegroundColor Yellow
                Write-host "Path: " $Report.path -ForegroundColor DarkYellow

                #Remove user from Policy list(Do this to flush the roles)
                $Policies = $Policies | Where{$_.GroupUserName -ne $User.GroupUserName}

                ####################### Add the New Policy #######################
                $Policy = New-Object ($policyType)
                $Policy.GroupUserName = $User.GroupUserName
                $Policy.Roles = @()

                #Add new User to Policy
                $Policies += $Policy

               

                ####################### Alter the users Roles to include the new role set #######################
                # $Array was added as a bug fix. (Report builder & Publisher wanted to share a cell in the array "$Role")
                $Array = @()
                $Roles = $Roles | Where{$_.name -ne $BadRole} 
                $Roles = $Roles.Name
                $Array += $NewRole
                foreach($Item in $Roles){$Array += $Item}
                $Roles = $Array
                

                foreach($Role in $Roles)
                {
                    #Add the new role set to the Policy
                    $R = $policy.Roles | Where-object {$_.Name -eq $Role} | Select-Object -First 1
                    if(-not $R)
                    {
                        $r = New-Object ($roleType)
                        $r.Name = $Role
                        $Policy.Roles += $r
                    }

               }#End foreach $Role

                
                ##################### Set the new Policy with the new Role included #########################
                $svc.SetPolicies($Report.Path, $Policies);
                



            }#End if $Roles

            #Read-host "Waiting......"
        
        }#End Foreach $User
        
    }#End if NOT $InheritParent

}#End Foreach $Folder