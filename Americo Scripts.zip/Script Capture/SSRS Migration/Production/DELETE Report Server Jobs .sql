--Written by Tery Zumwalt

if object_id(N'tempdb..#RSJobs') is not null
Begin
	drop table #RSJobs
end
GO

--####################################

Create Table #RSJobs
(
	ID int Identity(1,1),
	NAME NVarchar(200)
);
GO
insert into #RSJobs
(
	[NAME]
)
select NAME from msdb.dbo.sysjobs where description like '%Report Server%'

GO
--select * from #RSJobs

--##########################################

declare @counter int
set @counter=(Select Count(*) from #RSJobs)

use msdb
while(@counter > 0)
	BEGIN

		declare @name NVarchar(100)
		set @name = (select name from #RSJobs where ID = @Counter)

		exec sp_delete_job @job_Name = @name

	Set @Counter = @Counter - 1
END


--##################################

/*
-- By Bill R
Declare @SQL nvarchar(max) = ''
Select @SQL = @SQL + 'Drop Job '+name+';' -- Or something like that
Print @SQL -- Always look before you leap
-- Execute (@SQL) -- No loop!
*/