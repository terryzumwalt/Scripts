﻿
# Add Time Stamp


Write-host "Setting Variables and Establishing a Connection to SSRS, Please wait...." -ForegroundColor Yellow
" "
" "
" "
$Server = "KCSSAS71"
$Global:Server = $Server

#RollBack
$Global:Array = Get-Content "C:\Users\tzumwalt\Desktop\SSRS_Folder_Move\Rollback.txt"


################################################################################
#Specify the URI
$uri = "http://$Server/reportserver/ReportService2010.asmx"
$RS = "Http://$Server/ReportServer"


#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
##################################################################################

$Datetime = (Get-Date -Format "MMddyyyy_HH_mm")
$Global:Log = "C:\Users\tzumwalt\Desktop\SSRS_Folder_Move\" + "Migration_Log_" + $DateTime + ".txt"
$TestDir = Test-Path $Global:Log


### Fix Extra lines in the .TXT File ####
$NewArray = @()
foreach($Item in $Global:Array)
{
    if($Item.length -gt 0)
    {
        $NewArray += $Item
    }

    $Global:Array = $NewArray
}




Function MoveReports
{
    ## Begin Migration ##
    Foreach($Item in $Global:Array)
    {

        #Set Array paths to variables
        $SplitPaths = $Item.Split("|")
        $Src = $SplitPaths[0]
        $Dest = $SplitPaths[1]
        $Src = $Src.Trim()
        $Dest = $Dest.Trim()

        #Verify the Report Exists
        $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Src -and $_.TypeName -eq "Report"}
        if($Verify -eq $NULL){Write-Host "$Src   Does not exist on Source...skipping" -ForegroundColor Red ;$OUT = $Src + "Does not exist on Source...skipping" | out-file $Global:Log -Append }
        if($Verify -ne $NULL -and $SRC.Length -gt 0)
        {
   
            $Error.Clear()
            Try{
                Write-host "Moving:  $Src  > $Dest" -ForegroundColor Yellow
                $OUT = "Moving:  $Src  > $Dest" | out-file $Global:Log -Append
                #Move Report
                $svc.MoveItem("$Src","$Dest")

            }
            Catch{
                Write-Host "Error Occurred with $Src   or    $Dest" -ForegroundColor RED
                $OUT = "Error Occurred with $Src   or    $Dest" | out-file $Global:Log -Append
                $Error
            }


        
        }#End if $Verify
          
    }#End Foreach $Item

    if($Error)
    {
        $Out = $Error | out-file $Global:Log -Append
        $Error.clear()
    }#End $Error


}#MoveReports





##### Action Script #####
MoveReports           #Move Reports to new location



