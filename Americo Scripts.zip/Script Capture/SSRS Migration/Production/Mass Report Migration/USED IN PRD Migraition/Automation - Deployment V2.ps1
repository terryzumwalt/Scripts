﻿
# Add Time Stamps
#

#$ErrorActionPreference = 'continue'

Write-host "Setting Variables and Establishing a Connection to SSRS, Please wait...." -ForegroundColor Yellow
" "
" "
" "
$Server = "KCSSAS71" 
$Global:Server = $Server

#Deploy
$Global:Array = Get-Content "C:\Users\tzumwalt-db\Desktop\SSRS_Folder_Move_PRD\Deploy.txt"

#Permissions
$Global:Perm = import-Excel "C:\Users\tzumwalt-db\Desktop\SSRS_Folder_Move_PRD\Permissions.xlsx"


#RollBack
#$Global:Array = Get-Content "C:\Users\tzumwalt-db\Desktop\SSRS_Folder_Move_PRD\Rollback.txt"
################################################################################
################################################################################
#Specify the URI
$uri = "http://$Server/reportserver/ReportService2010.asmx"
$RS = "Http://$Server/ReportServer"


#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
##################################################################################

$Datetime = (Get-Date -Format "MMddyyyy_HH_mm")
$Global:Log = "C:\Users\tzumwalt-db\Desktop\SSRS_Folder_Move_PRD\" + "Migration_Log_" + $DateTime + ".txt"
$TestDir = Test-Path $Global:Log

$HeaderOUT = "Starting Migration" | out-file $Global:Log -Append
$DateOut = get-date | out-file $Global:Log -Append

### Fix Extra lines in the .TXT File ####
$NewArray = @()
foreach($Item in $Global:Array)
{
    if($Item.length -gt 0)
    {
        $NewArray += $Item
    }

    $Global:Array = $NewArray
}


Function InhPerm
{
    #$Global:PermDest  
    $InheritParent=$True
    " "
    " "
    $DateOut = get-date | out-file $Global:Log -Append

    foreach($Obj in $Global:Array)
    {
        #Set Array paths to variables
        $SplitPaths = $Obj.Split("|")
        $Src = $SplitPaths[0]
        $Dest = $SplitPaths[1]
        $Src = $Src.Trim()
        $Dest = $Dest.Trim()

        $Reports = $svc.ListChildren("/", $true) | Where{$_.TypeName -eq "Report"}  
        $Reports = $Reports | Where{$_.Path -like "$Dest*"}


        if($Reports.count -eq 1)
        {
            $PolicyTest = $svc.GetPolicies($Reports.Path, [ref] $InheritParent)
            if(-not $InheritParent)
            {
                $Error.Clear()
                Write-Host "Updating Permissions for Report :: $Dest" -ForegroundColor Gray 
                $OUT = "Updating Permissions for Report :: $Dest"  | out-file $Global:Log -Append
                  
                Try
                {
                    $Svc.InheritParentSecurity($Reports.Path)
                    if($Error){Throw "Can not set Permissions"}
                }
                Catch
                {
                    Write-Host "Unable to set Inheritance for $Dest"  -ForegroundColor Red
                    $OUT = "Unable to set Inheritance for" + $Dest | out-file $Global:Log -Append
                }
            }#End if not $inheritParent
        if($InheritParent){write-host "Inherit - Permissions on this report are GOOD: " $Reports.Path; $OUT = "Inherit - Permissions on this report are GOOD:" + $Reports.Path | out-file $Global:Log -Append}


        }#End if $Reports

        if($Error)
        {
            $Out = $Error | out-file $Global:Log -Append
            $Error.clear()
        }#End $Error

    }#End forach $Obj

    $DateOut = get-date | out-file $Global:Log -Append
    " "
    " "

}#End Function InhPerm


Function CreateFolders
{
    " "
    " "
    $DateOut = get-date | out-file $Global:Log -Append
    ####### Parse Rows ########
    $FilteredArray = @()
    foreach($Item in $Global:Array)
    {
        #Set Array paths to variables
        $SplitPaths = $Item.Split("|")
        $Src = $SplitPaths[0]
        $Dest = $SplitPaths[1]
        $Src = $Src.Trim()
        $Dest = $Dest.Trim()


        #Removes the report from the end of the path
        $NewPath = $Dest.Substring(0,$Dest.LastIndexOf('/'))


        $FilteredArray += $NewPath
        
        #Write-Host "ITEM: "$Item -ForegroundColor Yellow

    }

    #Unique Pathing
    $FilteredArray = $FilteredArray | Sort | Get-Unique




    foreach($Item in $FilteredArray)
    {
 
        $Dest = $Item.Trim()

        #Reform $FILEPATH with out the report
        $TestPath = ($Dest -split '/') | Where{$_ -ne ""}
        #$TPCount = ($TestPath.count - 1)
        $TPCount = $TestPath.count

        if($TPCount -eq 1){$Filepath = "/" + $TestPath[0]}
        if($TPCount -eq 2){$Filepath = "/" + $TestPath[0] + "/" + $TestPath[1]}
        if($TPCount -eq 3){$Filepath = "/" + $TestPath[0] + "/" + $TestPath[1] + "/" + $TestPath[2]}
        if($TPCount -eq 4){$Filepath = "/" + $TestPath[0] + "/" + $TestPath[1] + "/" + $TestPath[2] + "/" + $TestPath[3]}
        if($TPCount -eq 5){$Filepath = "/" + $TestPath[0] + "/" + $TestPath[1] + "/" + $TestPath[2] + "/" + $TestPath[3] + "/" + $TestPath[4]}
        if($TPCount -eq 6){$Filepath = "/" + $TestPath[0] + "/" + $TestPath[1] + "/" + $TestPath[2] + "/" + $TestPath[3] + "/" + $TestPath[4] + "/" + $TestPath[5]}



        #Test IF $FILEPATH Exists
        $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -Like "$FilePath" -and $_.TypeName -eq "Folder"}

        if($Verify -eq $NULL)
        {
            #Prep the Folder Path's
            $PathArray = ($Dest -split '/') | Where{$_ -ne ""}
            $Count = ($PathArray.count) #Remove Report and set 1 = 0
            
            $i = 0
            While($i -lt $Count)
            {
                #Build the Folder Structures
                if($i -eq 0){$Test = "/" + $PathArray[0];$Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Test -and $_.TypeName -eq "Folder"}}
                if($i -eq 1){$Test = "/" + $PathArray[0] + "/" + $PathArray[1];$Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Test -and $_.TypeName -eq "Folder"}}
                if($i -eq 2){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2];$Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Test -and $_.TypeName -eq "Folder"}}
                if($i -eq 3){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2] + "/" + $PathArray[3];$Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Test -and $_.TypeName -eq "Folder"}}
                if($i -eq 4){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2] + "/" + $PathArray[3] + "/" + $PathArray[4];$Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Test -and $_.TypeName -eq "Folder"}}
                if($i -eq 5){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2] + "/" + $PathArray[3] + "/" + $PathArray[4] + "/" + $PathArray[5];$Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Test -and $_.TypeName -eq "Folder"}}


                if($Verify.length -gt 0){Write-Host "Existing Path:" $Test;$OUT = "Existing Path:" + $Test | out-file $Global:Log -Append}
                if($Verify.length -lt 1){Write-Host "Creating Path:" $Test;$OUT = "Creating Path:" + $Test | out-file $Global:Log -Append}


                if($Verify.length -lt 1)
                {
                    if($i -eq 0){$Root = "/";$Path = $PathArray[0]}
                    if($i -eq 1){$Root = "/" + $PathArray[0];$Path = $PathArray[1]}
                    if($i -eq 2){$Root = "/" + $PathArray[0] + "/" + $PathArray[1];$Path = $PathArray[2]}
                    if($i -eq 3){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2];$Path = $PathArray[3]}
                    if($i -eq 4){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2] + "/" + $PathArray[3];$Path = $PathArray[4]}
                    if($i -eq 5){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2] + "/" + $PathArray[3] + "/" + $PathArray[4];$Path = $PathArray[5]}


                    New-RsFolder -reportserveruri $RS -RsFolder $Root -foldername $Path #-ErrorAction SilentlyContinue
                    

                }#End if $Verify

                $i = $i + 1

            }#End While
            
        }#If $Verify

        if($Verify -ne $NULL)
        {
            Write-host "Existing Path: " $Dest
            $Out = "Existing Path:  $Dest" | out-file $Global:Log -Append
        }


    }#End Foreach $Item

        if($Error)
        {
            $Out = $Error |format-list -force| out-file $Global:Log -Append
            $Error.clear()
        }#End $Error


        $DateOut = get-date | out-file $Global:Log -Append
        " "
        " "

}#CreateFolders



Function FlushFolderPerm
{

    $Server = $Global:Server

    " "
    " "
    $DateOut = get-date | out-file $Global:Log -Append

    ##### SSRS ############
    #Specify the URI
    $SRCuri = "http://$Server/reportserver/ReportService2010.asmx"

    #Create WebProxy(Connection to SSRS Server and Data)
    $svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
    $type = $svc.GetType().Namespace;

    $Folder = $svc.ListChildren("/", $true) | Where{$_.TypeName -eq "Folder"}



    #### FILES ##########
    $PermDir = $Global:Perm
    $ImportPerm = $PermDir

    #Get Unique Folder Paths
    $Paths = $ImportPerm.'New Report Folder' | Sort | Get-Unique

    $InheritParent = $True
    foreach($Path in $Paths)
    {
        Write-Host "Flushing Folder Permissions for::" $Path -ForegroundColor Gray
        $OUT = "Flushing Folder Permissions for:: $Path" | out-file $Global:Log -Append

        #Get Existing Policy
        $Policies = $svc.GetPolicies($Path, [ref] $InheritParent)

        #Remove every user but Administrator
        $Policies = $Policies|Where{$_.GroupUserName -eq 'BUILTIN\Administrators'}

        #Set The new Policy
        $svc.SetPolicies($Path, $Policies);

      
    }#End foreach $Path

        if($Error)
        {
            $Out = $Error | out-file $Global:Log -Append
            $Error.clear()
        }#End $Error


        $DateOut = get-date | out-file $Global:Log -Append
        " "
        " "

} # End Funciton FlushFolderPerm


Function FolderPermissions
{
    ## -- Complete > ADD: Remove existing user before re-adding.
    ## -- Complete > Strip: Unlisted Users (Except "BUILTIN\Administrators")
    ## Manually set folder to Custom Inheritance+
    ## #$svc.EndInheritParentSecurity($Path)

    " "
    " "
    $DateOut = get-date | out-file $Global:Log -Append
    

    


    ##### SSRS ############
    #Specify the URI
    $SRCuri = "http://$Server/reportserver/ReportService2010.asmx"

    #Create WebProxy(Connection to SSRS Server and Data)
    $svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
    $type = $svc.GetType().Namespace;

    $Folder = $svc.ListChildren("/", $true) | Where{$_.TypeName -eq "Folder"}
    #$Folder = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
    #$Reports = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report"} 



    #### FILES ##########
    $PermDir = $Global:Perm
    $ImportPerm = $PermDir

   

    $InheritParent = $True
    foreach($Row in $ImportPerm)
    {
        ## Compare Permissions in the folders ##
        $NewFolder = $Row.'New Report Folder'
        $CompareFolder = $Folder | Where{$_.Path -eq "$NewFolder"}
        #$PolicyTest = $svc.GetPolicies($CompareFolder.Path, [ref] $InheritParent)

        $Policies = $svc.GetPolicies($CompareFolder.Path, [ref] $InheritParent)


        #Continue if the permissions dont already exist.
        if($Policies.GroupUserName -notcontains $Row.Username)
        {
            Write-Host "Adding Permissions" -ForegroundColor Yellow
            Write-Host "Adding User to Policy:" $Row.Username ">" $Row.'New Report Folder' -ForegroundColor Yellow
            $OUT = "Adding user to Policy:" + $Row.Username + ">" + $Row.'New Report Folder' | out-file $Global:Log -Append


            $View = "Browser"
            $Modify = "Manage All Subscriptions","Publisher","Report Builder"
            $Vo = $View
            $VM = $View,$Modify


            $policyType = "{0}.Policy" -f $type;
            $roleType = "{0}.Role" -f $type;
            $GroupUserName = $Row.UserName
            ### Determine $RoleName ###
            if($Row.Modify -eq $NULL){$RoleName = $Vo}  
            if($Row.Modify -ne $NULL){$RoleName = $VM}

            ## Fix RolenName Array ##
            $Array = @()
            foreach($RN in $RoleName)
            {
                $Array += $RN
            }
            $RoleName = $Array

            
            ### Add The New Policy ###
            $Policy = New-Object ($policyType)
            $Policy.GroupUserName = $GroupUserName
            $Policy.Roles = @()


            #Add new User to Policy
            $Policies += $Policy

            #Add Roles to the new Policy
            foreach($Role in $RoleName)
            {
                $R = $policy.Roles | Where-object {$_.Name -eq $RoleName} | Select-Object -First 1
                if(-not $R)
                {
                    $r = New-Object ($roleType)
                    $r.Name = $Role
                    $Policy.Roles += $r
                }


            }#End Foreach $Role



            ### Set the Policy ###
            $Error.clear()
            Try
            {
                $svc.SetPolicies($Row.'New Report Folder', $Policies);
                #if(-not $Error){$Policies}
                if($Error){Throw "Error in Permissions"}
            }
            catch
            {
                Write-Host "An error was captured during the Attempt to SET the policy:" -ForegroundColor Red
                $OUT = "An error was captured during the Attempt to SET the policy" | out-file $Global:Log -Append
                $Out = $Error | out-file $Global:Log -Append
                Write-Host "You may need to elevate your credentials" -ForegroundColor Green
                $Error
            }

            $Error.Clear()

        
        }#End if $PolicyTest

    

    }#End foreach $Row

    if($Error)
    {
        $Out = $Error | out-file $Global:Log -Append
        $Error.clear()
    }#End $Error



    " "
    " "
    $DateOut = get-date | out-file $Global:Log -Append

}#End FunctionFolderPermissions



Function MoveReports
{
    " "
    " "
    $DateOut = get-date | out-file $Global:Log -Append


    ## Begin Migration ##
    Foreach($Item in $Global:Array)
    {

        #Set Array paths to variables
        $SplitPaths = $Item.Split("|")
        $Src = $SplitPaths[0]
        $Dest = $SplitPaths[1]
        $Src = $Src.Trim()
        $Dest = $Dest.Trim()

        #Verify the Report Exists
        $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Src -and $_.TypeName -eq "Report"}
        if($Verify -eq $NULL){Write-Host "$Src   Does not exist on Source...skipping" -ForegroundColor Red ;$OUT = $Src + "Does not exist on Source...skipping" | out-file $Global:Log -Append }
        if($Verify -ne $NULL -and $SRC.Length -gt 0)
        {
   
            $Error.Clear()
            Try{
                Write-host "Moving:  $Src  > $Dest" -ForegroundColor Yellow
                $OUT = "Moving:  $Src  > $Dest" | out-file $Global:Log -Append
                #Move Report
                $svc.MoveItem("$Src","$Dest")
                if($Error){Throw "Issue Moving the Report"}

            }
            Catch{
                Write-Host "Error Occurred with $Src   or    $Dest" -ForegroundColor RED
                $OUT = "Error Occurred with $Src   or    $Dest" | out-file $Global:Log -Append
                $Error
                $OUT = $Error | out-file $Global:Log -Append
            }


        
        }#End if $Verify

        $Error.Clear()
          
    }#End Foreach $Item

    if($Error)
    {
        $Out = $Error | out-file $Global:Log -Append
        $Error.clear()
    }#End $Error


    $DateOut = get-date | out-file $Global:Log -Append
    " "
    " "
}#MoveReports





##### Action Script #####
CreateFolders         #Create any new folders
FlushFolderPerm       #Remove all but admin
FolderPermissions     #Add Custom Permissions
MoveReports           #Move Reports to new location
InhPerm               #Ensure all reports inherit the parent folder 

$DateOut = get-date | out-file $Global:Log -Append

Write-Host "COMPLETE!!!!"

