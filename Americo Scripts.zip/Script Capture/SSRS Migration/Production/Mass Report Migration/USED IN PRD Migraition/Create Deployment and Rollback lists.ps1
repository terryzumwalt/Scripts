﻿import-module ImportExcel

$DocDir = "C:\Users\tzumwalt-db\Desktop\SSRS_Folder_Move_PRD\Reports.xlsx"
$Deploy = "C:\Users\tzumwalt-db\Desktop\SSRS_Folder_Move_PRD\Deploy.txt"
$Rollback = "C:\Users\tzumwalt-db\Desktop\SSRS_Folder_Move_PRD\Rollback.txt"


$ImportList = Import-Excel $DocDir

foreach($Item in $ImportList)
{
    $SrcRpt = $Item.'Old ReportPath'
    $DestRpt = $Item.'Concatenated New Report Path'
    
    #$Entry = $Item.'Old ReportPath' + "|" + "/" + $Item.'Concatenated New Report Path' | Out-File $Deploy -Append

    #$Exit = "/" + $item.'Concatenated New Report Path' + "|" + $Item.'Old ReportPath' | Out-File $Rollback -Append


    if($SrcRpt -ne $DestRpt)
    {
        $Entry = $SrcRpt + "|" + $DestRpt | Out-File $Deploy -Append
        $Exit = $DestRpt + "|" + $SrcRpt | Out-File $Rollback -Append
    }

}


$Test = Get-Content $Deploy
$Test2 = Get-Content $Rollback

$Test.count
$Test2.count