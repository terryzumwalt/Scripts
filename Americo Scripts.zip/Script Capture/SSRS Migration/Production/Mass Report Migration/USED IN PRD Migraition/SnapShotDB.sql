Declare       @Database_Name nvarchar(128) = 'ReportServer'

Set Nocount on

DECLARE @Snapshot_Name nvarchar(128), @Last_Row_Inserted int

--------- Parameter Validation

If not exists(select 1 from sys.databases where name = @Database_Name)
Begin
       RaisError('No such database',16,1)
       Return
End

Set @Snapshot_Name = Left(@Database_Name,119) + '_Snapshot'

If exists(select 1 from sys.databases where name = @Snapshot_Name)
Begin
       RaisError('Snapshot already exists. Cannot create another one.',16,1) -- Not supporting multiple snapshots at this time.
       Return
End

--------- Work Table to hold the script

If Object_Id(N'tempdb..#Script') is not null
       Drop table #Script

Create table #Script (
       Id int identity primary key,
       ScriptText nvarchar(1000)
)

--------- Begin inserting script parts

Insert into #Script (ScriptText) Values (N'CREATE DATABASE '+QUOTENAME(@Snapshot_Name) + N' ON ')

-- define data files based on existing database. Adds "_Snapshot" to end of base name. e.g. D:\data\Mydb.mdf --> D:\data\Mydb_Snapshot.mdf
Insert into #Script (ScriptText)
Select 
       char(13)+char(10)+N'    (NAME = N'''+mf.name+''', FILENAME = N'''+
       case CHARINDEX('.',reverse(mf.physical_name))
              When 0 Then mf.physical_name + '_Snapshot'  -- If there is no extension. (issue/todo: a "." in a folder name will cause problems if the data file does not have an extension.)
              Else Left(mf.physical_name,Len(mf.physical_name) - CHARINDEX('.',reverse(mf.physical_name))) + 
                     + '_Snapshot' 
                     + Right(mf.physical_name,CHARINDEX('.',reverse(mf.physical_name))) End
       + ''' ),'
from sys.master_files mf
       join sys.databases d on 
              mf.database_id = d.database_id
Where 
       type_desc = 'Rows' and
       d.name = @Database_Name

Set @Last_Row_Inserted = SCOPE_IDENTITY()

-- Remove the trailing comma from the last row inserted
Update #Script Set
       ScriptText = Left(ScriptText,Len(ScriptText) - 1)
Where Id = @Last_Row_Inserted

Insert into #Script (ScriptText) Values (char(13)+char(10)+N' As Snapshot of '+QUOTENAME(@Database_Name))
--Insert into #Script (ScriptText) Values (char(13)+char(10)+N' GO') -- Execute does not like the "Go"

--------- Convert script table to a string and execute the script

Declare @SQL nvarchar(max)
Set @SQL = ''
select @SQL = @SQL + ScriptText from #Script

-- Execute the script
Print @SQL

Begin Try
       Execute (@SQL)
End Try
Begin Catch
       Print 'Snapshot creation failed.'
       Print Error_Message()
       Return
End Catch
Print 'Snapshot created successfully.'

