﻿
#Specify the URI
$uri = "http://kcssas71/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential

#$Reports = $svc.ListChildren("/", $true) | select -Property Path ,TypeName |Where{$_.TypeName -eq "Report"  -and $_.Path -like "*wil*"} #



$svc.MoveItem("/Testing SSRS Wilfred/PolicyData","/TZ1/PolicyData")


