﻿


$Server = "KCSSAS71"
$Array = Get-Content "C:\Temp\ReportPaths.txt"

################################################################################
#Specify the URI
$uri = "http://$Server/reportserver/ReportService2010.asmx"

#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
##################################################################################


## Begin Migration ##
Foreach($Item in $Array)
{
    #Set Array paths to variables
    $SplitPaths = $Item.Split("|")
    $Src = $SplitPaths[0]
    $Dest = $SplitPaths[1]

   
    $Error.Clear()
    Try{
        Write-host "Moving:  $Src  > $Dest" -ForegroundColor Yellow
        #Move Report
        $svc.MoveItem("$Src","$Dest")
    }
    Catch{
        Write-Host "Error Occurred with $Src   or    $Dest" -ForegroundColor RED
        $Error
    }   
}#End Foreach $Item


