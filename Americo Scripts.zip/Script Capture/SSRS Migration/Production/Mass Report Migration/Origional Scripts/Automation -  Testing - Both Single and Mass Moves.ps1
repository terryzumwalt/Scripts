﻿Import-Module ReportingServicesTools

###########################################################################
$URI = "http://sqlssrs62/reports"
$Svc = New-RsRestSession -ReportPortalUri $URI -RestApiVersion v1.0
##########################################################################
$WebURI = "http://sqlssrs62/reports"
$Session = New-RsRestSession -ReportPortalUri $WebURI -RestApiVersion v1.0
###########################################################################

############################################################################################################

### Manage One Report at a time

$SaveDir = "C:\Temp"
$Report = "All Outgoing Wire_EFT (AML)"
$NewSave = $SaveDir + "\" + $Report + ".rdl"

$OldPath = "/Operations/Legal - Compliance/All Outgoing Wire_EFT (AML)"
$NewPath = "/Operations/Legal/Compliance"

$SaveNewDir = $NewPath + "/" + $Report

#######
#Export the .RDL (Report) - SINGLE Report
#Out-RsRestCatalogItem -RsItem "$OldPath" -Destination "$SaveDir" -WebSession $Svc -RestApiVersion v1.0

#Import the .RDL
#Write-RsRestCatalogItem -Path "$NewSave" -RsFolder "$NewPath" -WebSession $Session -RestApiVersion v1.0
################################################################################################################






####### Manage and Entire Folder at a time ########

$OldPath = "/Operations/Legal - Compliance/"
$NewPath = "/Operations/Legal/Compliance"


#Backup Every Report
Out-RsRestFolderContent -RsFolder "$OldPath" -Destination "C:\Temp\TestMigration" -WebSession $Svc -RestApiVersion v1.0

#Import Entire Folder
Write-RsRestFolderContent -Path "C:\Temp\TestMigration" -RsFolder "$NewPath" -WebSession $Session -RestApiVersion v1.0
