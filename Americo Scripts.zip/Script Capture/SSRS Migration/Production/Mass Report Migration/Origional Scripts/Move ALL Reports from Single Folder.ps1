﻿Import-Module ReportingServicesTools

###########################################################################
$URI = "http://sqlssrs62/reports"
$Svc = New-RsRestSession -ReportPortalUri $URI -RestApiVersion v1.0
##########################################################################
$WebURI = "http://sqlssrs62/reports"
$Session = New-RsRestSession -ReportPortalUri $WebURI -RestApiVersion v1.0
###########################################################################


####### Manage and Entire Folder at a time ########

$OldPath = "/Operations/Legal - Compliance/"
$NewPath = "/Operations/Legal/Compliance"


#Backup Every Report
Out-RsRestFolderContent -RsFolder "$OldPath" -Destination "C:\Temp\TestMigration" -WebSession $Svc -RestApiVersion v1.0

#Import Entire Folder
Write-RsRestFolderContent -Path "C:\Temp\TestMigration" -RsFolder "$NewPath" -WebSession $Session -RestApiVersion v1.0
