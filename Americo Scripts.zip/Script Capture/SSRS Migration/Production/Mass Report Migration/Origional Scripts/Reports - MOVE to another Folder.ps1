﻿Import-Module ReportingServicesTools
$URI = "http://sqlssrs62/reports"
$Svc = New-RsRestSession -ReportPortalUri $URI -RestApiVersion v1.0

#Export the .RDL (Report) - SINGLE Report
Out-RsRestCatalogItem -RsItem "/Testing SSRS Wilfred/PolicyData" -Destination "C:\Temp" -WebSession $Svc -RestApiVersion v1.0

#Every Report
Out-RsRestFolderContent -RsFolder "/Testing SSRS Wilfred/" -Destination "C:\Temp" -WebSession $Svc -RestApiVersion v1.0


##################################################################################################################
$WebURI = "http://sqlssrs62/reports"
$Session = New-RsRestSession -ReportPortalUri $WebURI -RestApiVersion v1.0



#Import the .RDL(Report) - Single Report
Write-RsRestCatalogItem -Path "C:\Temp\PolicyData.rdl" -RsFolder "/TZTest" -WebSession $Session -RestApiVersion v1.0
del "C:\Temp\*"

#Entire Folder
#Write-RsRestFolderContent -Path "C:\Temp" -RsFolder "/" -WebSession $Session -RestApiVersion v1.0