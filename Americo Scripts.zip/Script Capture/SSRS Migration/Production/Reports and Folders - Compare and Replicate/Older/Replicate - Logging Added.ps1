﻿

#Import-Module ReportingServicesTools


$Global:SrcServer = "SQLSSRS62"
$Global:DestServer = "SQLSSRS72"



Function Logging
{
    $Global:DestDB = "Replication_SSRS_PS"

    $Query = @"
        insert into Logging
        Values('$Global:TimeCollected','$Global:LogType','$Global:ItemPath','$Global:Info','$Global:Source_Users','$Global:Source_Roles','$Global:Destination_Users','$Global:Destination_Roles')
"@

    
    invoke-sqlcmd -ServerInstance $Global:DestServer -Database $Global:DestDB -Query $Query


    $Global:TimeCollected = $NULL
    $Global:LogType = $Null
    $Global:ItemPath = $NULL
    $Global:Info = $NULL
    $Global:Source_Users = $NULL
    $Global:Source_Roles = $NULL
    $Global:Destination_Users = $NULL
    $Global:Destination_Roles = $NULL

    
    
}#End Function Logging






Function FoldersMain
{
    $Error.clear()
    ######################################################
    ####### Query Source for List of Folder Paths ########
    #Specify the URI (SRC Server)
    $Srcuri = "http://$Global:SrcServer/reportserver/ReportService2010.asmx"
    #Create WebProxy(Connection to SSRS Server and Data)
    #$Srcsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $Srcuri -UseDefaultCredential
    $Srcsvc = New-WebServiceProxy -Class 'RS' -Uri $Srcuri -UseDefaultCredential
    $Srctype = $Srcsvc.GetType().Namespace
    $Srcdatatype = ($type + '.Property')
    $SrcFolders = $Srcsvc.ListChildren("/", $true) | Where{$_.TypeName -eq "Folder"} #  -and $_.Path -like "*TZ*"
  
    ###############################################################
    ##### Query Dest for list of existing paths #####
    #Specify the URI (used for Obtaining the path list)
    $uri = "http://$Global:DestServer/reportserver/ReportService2010.asmx"
    #Create WebProxy(Connection to SSRS Server and Data)
    #$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
    $svc = New-WebServiceProxy -Class 'RS' -Uri $uri -UseDefaultCredential
    $type = $svc.GetType().Namespace
    $datatype = ($type + '.Property')
    $DestFolders = $svc.ListChildren("/", $true) | Where{$_.TypeName -eq "Folder"} #  -and $_.Path -like "*TZ*"
    $RS = "http://$Global:DestServer/ReportServer"



    ### Ensure there were no failures ###
    if($Srcsvc -eq $NULL -or $svc -eq $NULL -or $Error)
    {
        if($Srcsvc -eq $NULL){$Failed = $Global:SrcServer}
        if($svc -eq $NULL){$Failed = $Global:DestServer}
        

        ## Write Log Entery ####
        $Global:TimeCollected = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $Global:LogType = "Connect Failure $Failed"
        $Global:ItemPath = "Error On Connect"
        $Global:Info = "Please Check $Failed for connection issues."
        $Global:Source_Users = $NULL
        $Global:Source_Roles = $NULL
        $Global:Destination_Users = $NULL
        $Global:Destination_Roles = $NULL

        Logging
        ########################

        
    }#End If
    
    ########################################################################################

    $InheritParent = $true



    #Test for Folders
    foreach($Folder in $SrcFolders)
    {
        #Add Folder to Dest if missing
        if($DestFolders.path -notcontains $Folder.path)
        {
            #Write-Host "Missing" $Folder.Path -ForegroundColor Yellow

            ## Write Log Entery ####
            $Global:TimeCollected = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            $Global:LogType = "Folder"
            $Global:ItemPath = $Folder.Path
            $Global:Info = "Replicating a missing folder on $Global:DestServer"
            $Global:Source_Permissions = $NULL
            $GLobal:Source_Roles = $NULL
            $Global:Destination_Permissions = $NULL
            $Global:Destination_Roles = $NULL
            Logging
            ########################


            $i = 0
            $PathArray = ($Folder.path -split '/') | Where{$_ -ne ""}
            foreach($item in $PathArray)
            {
                

                #Test folder levels starting at 0 then see if it exists on the Dest side
                if($i -eq 0){$Test = "/" + $PathArray[0]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}
                if($i -eq 1){$Test = "/" + $PathArray[0] + "/" + $PathArray[1]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}
                if($i -eq 2){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}
                if($i -eq 3){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2] + "/" + $PathArray[3]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}
                if($i -eq 4){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2] + "/" + $PathArray[3] + "/" + $PathArray[4]; $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq "$Test" -and $_.TypeName -eq "Folder"}}

                #if($Verify.length -gt 0){Write-Host "Existing Path:" $Test;}
                #if($Verify.length -lt 1){Write-Host "Creating Path:" $Test;}


                if($Verify.length -lt 1)#Path does not exist
                {
                    if($i -eq 0){$Root = "/"; $Path = $Item }
                    if($i -eq 1){$Root = "/" + $PathArray[0]; $Path = $Item }
                    if($i -eq 2){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]; $Path = $Item }
                    if($i -eq 3){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2]; $Path = $Item }
                    if($i -eq 4){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2]  + "/" + $PathArray[3]; $Path = $Item }

                    New-RsFolder -reportserveruri $RS -RsFolder $Root -foldername $Path #-ErrorAction SilentlyContinue
               
                }#End if $Verify


                $i = $i+ 1

            }#End foreach $item

        }#End if $DestFolder
    }#End Foreach Folder
   
}#End Function CompareFolders


Function PermissionsMain
{
    ####################################################################################
    ##### Set Destination Server and get Folder list ###################################

    #Specify the URI
    $uri = "http://SQLSSRS72/reportserver/ReportService2010.asmx"

    #Create WebProxy(Connection to SSRS Server and Data)
    #$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
    $svc = New-WebServiceProxy -Class 'RS' -Uri $uri -UseDefaultCredential

    $type = $svc.GetType().Namespace #------ Remove NameSpace from $Svc and use this only to prevent permissions looking issues.
    $datatype = ($type + '.Property')


    $DestFolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"} #  -and $_.Path -like "*TZ*"


    ###############################################################
    ##### Query Source Server for Folder List #####

    #Specify the URI
    $SRCuri = "http://SQLSSRS62/reportserver/ReportService2010.asmx"

    #Create WebProxy(Connection to SSRS Server and Data)
    $SRCsvc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $SRCuri -UseDefaultCredential

    $SRCFolderList = $SRCsvc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"} #  -and $_.Path -like "*TZ*"


    ################################################################################
    $InheritParent = $true

  

    foreach($Folder in $SRCFolderList)
    {
        Write-Host "Folder:" $Folder.Path -ForegroundColor DarkYellow

        ## Get Policy from Source Folder ##
        $SRCPolicies = $SRCsvc.GetPolicies($Folder.path, [ref] $InheritParent )
        $SRCPolicies = $SRCPolicies| Where{$_.GroupUserName -ne "KCDOM01\Domain Users"}


        if(-not $InheritParent -or $InheritParent)
        {

            $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent )
            $Policies = $Policies | Where{$_.GroupUserName -ne "KCDOM01\Domain Users" -and $_.GroupUserName -ne "KCDOM01\svc_SQLAutomation_L"}

            #############################################################################
            ######################### Begin Comparing Permissions #######################


            $Offset = 0

            ## Compare whole policy for a match  ##
            $SGUN = $SrcPolicies.GroupUserName
            $PGUN = $Policies.GroupUserName


            #Compare Name Count
            if($SGun.count -ne $PGUN.count){$Offset = $Offset + 1}
            #$Offset

            #Match Names
            foreach($Name in $SGUN)
            {
                if($PGUN -notcontains $Name)
                {
                    $Offset = $Offset + 1
                }
            }#End foreach #Name
            #$Offset



            #Match Roles
            foreach($SItem in $SRCPolicies)
            {
                $PItem = $Policies | Where{$_.GroupUserName -eq $SItem.GroupUserName}

                if(($PITem.Roles).name -ne ($SItem.Roles).name){ $Offset = $Offset + 1}

            }#end foreach $SItem
            #$Offset

            ################ END Compare Permissions #####################
            ##############################################################


            ### Replace Permissions of "$Offest" showed a difference ###

            ##### This section removes Permissions from the Destination that are not accurate on the Source #####
            foreach($item in $Policies.GroupUserName)
            {
                if($SrcPolicies.GroupUsername -notcontains $Item)
                {
                    $Policies = $Policies |Where{$_.GroupUserName -ne $Item}
                }#End if $SrcPolicies
            }#End Foreach $Item
            ######################################################################################################




            if($Offset -gt 0)
            {
                #Write-Host "Offest Shown for "$Folder -ForegroundColor Yellow


                $SrcUsers = $SRCPolicies.GroupUserName
                $SrcRoles = ($SRCPolicies.Roles).name
                $DestUsers = $Policies.GroupUserName
                $DestRoles = ($Policies.Roles).Name

                ## Write Log Entery ####
                $Global:TimeCollected = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
                $Global:LogType = "Permissions"
                $Global:ItemPath = $Folder.Path
                $Global:Info = "Replicating a missing Permissions for $Folder.path on $Global:DestServer."
                $Global:Source_Users = $SrcUsers
                $GLobal:Source_Roles = $SrcRoles
                $Global:Destination_Users = $DestUsers
                $Global:Destination_Roles = $DestRoles
                Logging
                ########################

                

                ### Begin Copying Permissions ###
                foreach($Name in $SRCPolicies)
                {

                    $policyType = "{0}.Policy" -f $type;
                    $roleType = "{0}.Role" -f $type;
                    $Policy = New-Object ($policyType)
                    $Policy.Roles = @()

                    #Write-Host "Using: "$Name.GroupUserName -ForegroundColor yellow
                    $Policy.GroupUserName = $Name.GroupUserName 

                    #Test that the new name is not already in Policies
                    if($Policies.groupusername -notcontains $Policy.GroupUserName)
                    {
                        #Write-Host "Adding Policy for: " $Name.GroupUserName

                        #Add GroupUserName to Policy
                        $Policies += $Policy


                        #Add Roles to Policy
                        foreach($Role in $Name.Roles)
                        {
                                
                            $RoleName = $role.name 

                            $R = $policy.Roles | Where-object {$_.Name -eq $RoleName} | Select-Object -First 1
                            if(-not $R)
                            {
                                if($RoleName -notlike "*Manage All Subscriptions*") #Were bringing this role to the environment
                                {
                                    $r = New-Object ($roleType)          
                                    $r.Name = $RoleName
                                    $Policy.Roles += $r
                                }
                                       
                            }#End IF -Not $r
                
                        }#End Foreach $Role

                        #$Policies

                        ## Moved below $svc.SetPolicies($Folder.Path, $Policies);


                    }#End If $Policies


                    if($Offset -gt 0){$svc.SetPolicies($Folder.Path, $Policies)}
        

                }#End foreach $Name



            }#end If $Offset


        }#End if -Not

        
    }#End foreach $Folder


} #End Function PermissionsMain




##### Action Script ######
FoldersMain
PermissionsMain

