﻿import-module SQLServer


$SrvArray = "SQLDBA51","SQLDBA01"
$DB = "DBA_WorkDB"
$Table = "dbo.ServerList"

$Query = @"

    Select server_name from $Table

"@


$Array = @()
foreach($Srv in $SrvArray)
{
    $Error.clear()
    $Ok = 0
    $Result = Invoke-Sqlcmd -ServerInstance $Srv -Database $DB -Query $Query -TrustServerCertificate

    foreach($Item in $Result.Server_Name)
    {
        Write-Host $Item -ForegroundColor Yellow
        
        $testCMD = Invoke-Command -ComputerName $Item {net localgroup administrators}
        foreach($Name in $testCMD)
        {
            Write-host $Name
            if($Name -eq "KCDOM01\SQL_DBA")
            {
                $Ok = 1
            }
        }
        if($Ok -lt 0)
        {
            Write-Host "Warning: "$Item -ForegroundColor Red
        }
        if($Ok -eq 1){$Ok = 0}
        if($Error)
        {
            $Log = "C:\Automation\TestResults.txt"
            $out = $Error | out-file $LOG -Append
            $out2 = " " | out-file $LOG -Append
            $out3 = " " | out-file $LOG -Append
            $Error.Clear()
            
        }


    }


}