﻿


Function Test {

#$today = [datetime]::Today
$today = (get-date).AddDays(-486)

$currentQuarter = [Math]::Ceiling($Today.Month / 3)
$lastQuarter = if ($currentQuarter -eq 1) { 4 } else { $currentQuarter - 1 }
$lastQuarterEndMonth = $lastQuarter * 3

$Diff = $today.Month - $lastQuarterEndMonth 
$NewDate = $Today.AddMonths(-$diff)            #This will change the year
$lastDayOfLastQuarter = [DateTime]::DaysInMonth($NewDate.Year, $NewDate.Month)

if($NewDate.Day -gt $lastDayOfLastQuarter){$Day = $NewDate.Day - $lastDayOfLastQuarter; $FinalDate = $NewDate.AddDays(-$Day)}
if($NewDate.Day -lt $lastDayOfLastQuarter){$Day =  $lastDayOfLastQuarter - $NewDate.Day; $FinalDate = $NewDate.AddDays(+$Day)}


$FinalDate.ToString("yyyy-MM-dd")
}

Test




