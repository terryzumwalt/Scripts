﻿
Import-Module SQLServer


$Global:SrcServer = "SQLAdhoc02"


$Log = "\\kcsan03\users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS_Remove_DB_Groups_" + $Global:SrcServer + "_log.txt"
$Test = Test-Path $log
if($Test -ne $False){Remove-Item $Log}

$Log2 = "\\kcsan03\users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS_Replace_DB_Accounts_REMOVEPerm_log.txt"
$Test = Test-Path $log2
if($Test -ne $False){Remove-Item $Log2}


$ME = whoami
if($ME -ne "KCDOM01\tzumwalt-db"){CLS ;Read-Host "Stop!  Use your DB Account!"}

#Source SSRS
$SRCuri = "http://$Global:SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$type = $svc.GetType().Namespace 
$datatype = ($type + '.Property')


#Get a list of all folders
$FolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
$ReportList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report"}
$DataSources = $svc.ListChildren("/",$true) | Where{$_.TypeName -eq "DataSource"}
$DataSets = $svc.ListChildren("/",$true) |Where{$_.TypeName -eq "DataSet"}








<#

####################################################################################################################################
#################################################### Start Validation (Predicted) ##############################################################
####################################################################################################################################

$ReportServerDB = "ReportServer"

$Security_Validation_Predicted ="\\kcsan03\Users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS\Step1_Predicted.sql"
$Verify = "Select Top 100 * from dbo.Security_Predicted"
Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database $ReportServerDB -InputFile $Security_Validation_Predicted -Verbose -TrustServerCertificate |format-table
Sleep -s 5
Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database $ReportServerDB -Query $Verify -TrustServerCertificate |Format-Table



####################################################################################################################################
#################################################### Validation ####################################################################
####################################################################################################################################



$InheritParent = $True

#Add Group to Folders
Write-Host "Beginning Folders" -ForegroundColor Yellow
$FolderOut = "Beginning Folders" 
$FolderOut |out-file $Log -Append
foreach($Folder in $Folderlist)
{
    
    $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent)

    if($InheritParent -eq $False)
    {
        if($Policies.GroupUserName -contains "KCDOM01\SQL_DBA_PROD")
        {
            if($Policies.GroupUserName -notcontains "KCDOM01\SQL_DBA")
            {
                Write-host $Folder.Path -ForegroundColor Yellow
                $Folder.Path |out-file $Log -Append

                $policyType = "{0}.Policy" -f $type;
                $roleType = "{0}.Role" -f $type;
                $Policy = New-Object ($policyType)
                $Policy.GroupUserName = "KCDOM01\SQL_DBA"
                $Policy.Roles = @()
                $RoleName = "Content Manager"

                [array]$Policies += $Policy

                foreach($Role in $RoleName)
                {
                    $r = New-Object ($roleType)
                    $r.Name = $Role
                    $Policy.Roles += $r
                }

        
                #Update the Folder Permissions
                $svc.SetPolicies($Folder.Path, $Policies)
            }
        }
    }
}







#Add Group to Reports
Write-Host "Beginning Reports" -ForegroundColor Yellow
$RPTOut = "Beginning Reports"
$RPTOut |out-file $Log -Append
#Refresh Permissions list#
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$ReportList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report"}
foreach($Report in $ReportList)
{
    
    $ReportPolicies = $svc.GetPolicies($Report.Path,[ref] $InheritParent) 

    if($InheritParent -eq $False)
    {
        $RptArray = $ReportPolicies.GroupUserName
        if($RptArray -contains "KCDOM01\SQL_DBA_PROD")
        {
            if($RptArray -notcontains "KCDOM01\SQL_DBA")
            {
                Write-Host $Report.Path -ForegroundColor Yellow
                $Report.Path |out-file $Log -Append
                $policyType = "{0}.Policy" -f $type;
                $roleType = "{0}.Role" -f $type;
                $Policy = New-Object ($policyType)
                $Policy.GroupUserName = "KCDOM01\SQL_DBA"
                $Policy.Roles = @()
                $RoleName = "Content Manager"

                [array]$ReportPolicies += $Policy

                foreach($Role in $RoleName)
                {
                    $r = New-Object ($roleType)
                    $r.Name = $Role
                    $Policy.Roles += $r
                }

        
                #Update the Folder Permissions
                $svc.SetPolicies($Report.Path, $ReportPolicies)

            }

        }
    }
}



#Add Group to Datasources
#Refresh Permissions list
$DSOut = "Beginning Data Sources" 
$DSOut |out-file $Log -Append
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$DataSources = $svc.ListChildren("/",$true) |Where{$_.TypeName -eq "DataSource"}
foreach($DS in $DataSources)
{
    $DSPolicies = $Svc.GetPolicies($DS.path,[ref]$InheritParent)
    $GroupArray = $DSPolicies.GroupUserName

    if($InheritParent -eq $False)
    {
        if($GroupArray -contains "KCDOM01\SQL_DBA_PROD")
        {
            if($GroupArray -notcontains "SQL_DBA")
            {
                Write-Host $DS.path -ForegroundColor Yellow
                $DS.path |out-file $Log -Append

                $policyType = "{0}.Policy" -f $type;
                $roleType = "{0}.Role" -f $type;
                $Policy = New-Object ($policyType)
                $Policy.GroupUserName = "KCDOM01\SQL_DBA"
                $Policy.Roles = @()
                $RoleName = "Content Manager"

                [array]$DSPolicies += $Policy

                foreach($Role in $RoleName)
                {
                    $r = New-Object ($roleType)
                    $r.Name = $Role
                    $Policy.Roles += $r
                }

        
                #Update the Data Source Permissions
                $svc.SetPolicies($DS.Path, $DSPolicies)

            }
        }
    }
}


#Add Group to DataSet
#Refresh Permissions list 
$DataSetOut = "Beginning DataSets" 
$DataSetOut |out-file $Log -Append
Write-Host "Beginning DataSets" 

$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$DataSets = $svc.ListChildren("/",$true) |Where{$_.TypeName -eq "DataSet"}
foreach($DataSet in $DataSets)
{
    $DataSetPolicies = $Svc.GetPolicies($DataSet.path,[ref]$InheritParent)
    $GroupArray = $DataSetPolicies.GroupUserName

    if($InheritParent -eq $False)
    {
        if($GroupArray -contains "KCDOM01\SQL_DBA_PROD")
        {
            if($GroupArray -notcontains "SQL_DBA")
            {
                Write-Host $DS.path -ForegroundColor Yellow
                $DataSet.path |out-file $Log -Append

                $policyType = "{0}.Policy" -f $type;
                $roleType = "{0}.Role" -f $type;
                $Policy = New-Object ($policyType)
                $Policy.GroupUserName = "KCDOM01\SQL_DBA"
                $Policy.Roles = @()
                $RoleName = "Content Manager"

                [array]$DataSetPolicies += $Policy

                foreach($Role in $RoleName)
                {
                    $r = New-Object ($roleType)
                    $r.Name = $Role
                    $Policy.Roles += $r
                }

        
                #Update the Data Source Permissions
                $svc.SetPolicies($DataSet.Path, $DataSetPolicies)

            }
        }
    }
}





 ##############################################################################################################################
 ######################################### End Validation (Actual) #####################################################################

 $ReportServerDB = "ReportServer"


 $SecurityValidationActual = "\\kcsan03\Users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS\Step2_Actual.sql"
 $Verify = "select Top(100) * from dbo.Security_Actual"
 Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database $ReportServerDB -InputFile $SecurityValidationActual -TrustServerCertificate -Verbose |Format-Table
 Sleep -s 5
 Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database  $ReportServerDB -Query $Verify -TrustServerCertificate |Format-table -Verbose

 #########################################################################################################################################


 ##################################### COMAPRE RESULTS ##################################################################################


 $ReportServerDB = "ReportServer"

 $Compare = "\\kcsan03\Users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS\Step3_Compare.sql"
 $Verify = "select Top(100) * from dbo.Security_Compare"
 Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database $ReportServerDB -InputFile $Compare -TrustServerCertificate -Verbose |Format-Table
 Sleep -s 5
 Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database  $ReportServerDB -Query $Verify -TrustServerCertificate |Format-table -Verbose

 ########################################################################################################################################



 #>







########################################    Remove SQL_DBA_PROD from Folders, Reports and Data Sources    ########################################


####################################################################################################################################
#################################################### Start Validation (Predicted) ##############################################################
####################################################################################################################################

$ReportServerDB = "ReportServer"

$Security_Validation_Predicted ="\\kcsan03\Users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS\Step1_Predicted_Remove.sql"
$Verify = "Select Top 100 * from dbo.Security_Predicted"
Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database $ReportServerDB -InputFile $Security_Validation_Predicted -Verbose -TrustServerCertificate |format-table
Sleep -s 5
Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database $ReportServerDB -Query $Verify -TrustServerCertificate |Format-Table



####################################################################################################################################
#################################################### Validation ####################################################################
####################################################################################################################################



<#!!!!!!!!!!!!! Run all 3 Groups !!!!!!!!!!!!!!!!!!!!!!!!#>


### CHECK THE GROUP NAME BEFORE EXECUTION ##

$InheritParent = $TRUE

#Remove Group from Folders
#Refresh List
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$FolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
Write-host "Removing Groups From Folders" -ForegroundColor Yellow
$RMGroup = "Removing Groups From Folders"
$RMGroup |out-file $Log2 -Append
foreach($Path in $FolderList)
{
    $Group = "KCDOM01\SQL_DBA_PROD"
    #$Group = "KCDOM01\SQL_DBA_DEV"
    #$Group = "KCDOM01\PROD_DB"

    $Policies = $svc.GetPolicies($Path.path, [ref] $InheritParent)

    if($InheritParent -eq $False)
    {
        if($Policies.GroupUserName -contains $Group)
        {
            Write-Host "Removing $Group from "$Path.Path -ForegroundColor Yellow
            $Path.path |out-file $Log2

            $Path.Path |out-file $Log2 -Append
            $Policies = $Policies |Where{$_.GroupUserName -ne $Group}

            $svc.SetPolicies($Path.Path, $Policies)
        }
    }
    " "
}


#Remove Group from Reports
#Refresh list#
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$ReportList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report"}
Write-Host "Removing Group from Reports" -ForegroundColor Yellow
$RptRMGroup = "Removing Group from Reports"
$RptRMGroup |out-file $Log2 -Append
foreach($RPTPath in $ReportList)
{
    $Group = "KCDOM01\SQL_DBA_PROD"
    #$Group = "KCDOM01\SQL_DBA_DEV"
    #$Group = "KCDOM01\PROD_DB"


    $Policies = $svc.GetPolicies($RPTPath.Path,[ref] $InheritParent) 

    if($InheritParent -eq $False)
    {
        if($Policies.GroupUserName -contains $Group)
        {
            #$Policies
            Write-Host "Removing $Group from "$RPTPath.Path -ForegroundColor Yellow
            $RptPath.path |out-file $Log2

            $RPTPath.path |out-file $Log2 -Append
            $Policies = $Policies |Where{$_.GroupUserName -ne $Group}

            $svc.SetPolicies($RPTPath.Path, $Policies)
        }
    }
  
    " "
    
}



#Remove Group from DataSources
#Refresh list#
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$DataSources = $svc.ListChildren("/",$true) |Where{$_.TypeName -eq "DataSource"}
foreach($DS in $DataSources)
{
    $Group = "KCDOM01\SQL_DBA_PROD"
    #$Group = "KCDOM01\SQL_DBA_DEV"
    #$Group = "KCDOM01\PROD_DB"


    $DSPolicies = $Svc.GetPolicies($DS.path,[ref]$InheritParent)

    if($InheritParent -eq $False)
    {
        if($DSPolicies.GroupUserName -contains $Group)
        {
            Write-Host $DS.path -ForegroundColor Yellow
            $DS.path |out-file $Log2

            $DSPolicies = $DSPolicies |Where{$_.GroupUserName -ne $Group}
            $svc.SetPolicies($DS.Path, $DSPolicies)

        }
    }
}




#Remove Group from DataSets
#Refresh list#
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$DataSet = $svc.ListChildren("/",$true) |Where{$_.TypeName -eq "DataSet"}
foreach($DS in $DataSets)
{
    #$Group = "KCDOM01\SQL_DBA_PROD"
    #$Group = "KCDOM01\SQL_DBA_DEV"
    $Group = "KCDOM01\PROD_DB"


    $DSPolicies = $Svc.GetPolicies($DS.path,[ref]$InheritParent)

    if($InheritParent -eq $False)
    {
        if($DSPolicies.GroupUserName -contains $Group)
        {
            Write-Host $DS.path -ForegroundColor Yellow
            $DS.path |out-file $Log2

            $DSPolicies = $DSPolicies |Where{$_.GroupUserName -ne $Group}
            $svc.SetPolicies($DS.Path, $DSPolicies)

        }
    }
}





 
 ##############################################################################################################################
 ######################################### End Validation (Actual) #####################################################################

 $ReportServerDB = "ReportServer"


 $SecurityValidationActual = "\\kcsan03\Users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS\Step2_Actual_Remove.sql"
 $Verify = "select Top(100) * from dbo.Security_Actual"
 Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database $ReportServerDB -InputFile $SecurityValidationActual -TrustServerCertificate -Verbose |Format-Table
 Sleep -s 5
 Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database  $ReportServerDB -Query $Verify -TrustServerCertificate |Format-table -Verbose

 ###################################################################################################################################


 ##################################### COMAPRE RESULTS ###############################################################################


 $ReportServerDB = "ReportServer"

 $Compare = "\\kcsan03\Users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS\Step3_Compare_Remove.sql"
 $Verify = "select Top(100) * from dbo.Security_Compare"
 Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database $ReportServerDB -InputFile $Compare -TrustServerCertificate -Verbose |Format-Table
 Sleep -s 5
 Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database  $ReportServerDB -Query $Verify -TrustServerCertificate |Format-table -Verbose



