

USE ReportServer
GO

SELECT c.path FROM subscriptions s
    JOIN catalog c ON s.Report_OID = c.ItemID
WHERE s.LastStatus LIKE '%DEFAULTCRED%'




SELECT * FROM dbo.subscriptions




SELECT LastStatus, COUNT(*), MAX(LastRunTime) AS LastRun FROM subscriptions
GROUP BY laststatus
HAVING MAX(lastruntime) > '2022-10-15 13:00'
ORDER BY COUNT(*) DESC


--shows last status
SELECT lastStatus, lastruntime, * FROM dbo.Subscriptions
WHERE DeliveryExtension = 'Report Server Email' AND extensionsettings LIKE '%excel%'
ORDER BY 2 DESC


SELECT lastStatus, lastruntime, * FROM dbo.Subscriptions
ORDER BY 2 DESC

--########################

SELECT * FROM catalog WHERE path = '/Data Sources/KCSQL16-AmericoDW'