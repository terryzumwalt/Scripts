﻿
Write-host "Setting Variables and Establishing a Connection to SSRS, Please wait...." -ForegroundColor Yellow
" "
" "
" "
$Server = "KCSSAS71"
$Global:Server = $Server

#Deploy
$Global:Array = Get-Content "C:\Users\tzumwalt\Desktop\SSRS Report Ticket\Deploy.txt"

#RollBack
#$Global:Array = Get-Content "C:\Users\tzumwalt\Desktop\SSRS Report Ticket\Rollback.txt"


################################################################################
#Specify the URI
$uri = "http://$Server/reportserver/ReportService2010.asmx"
$RS = "Http://$Server/ReportServer"


#Create WebProxy(Connection to SSRS Server and Data)
$svc = New-WebServiceProxy -Class 'RS' -Namespace 'RS' -Uri $uri -UseDefaultCredential
##################################################################################

$Datetime = (Get-Date -Format "MMddyyyy_HH_mm")
$Global:Log = "C:\Users\tzumwalt\Desktop\SSRS Report Ticket\" + "Migration_Log_" + $DateTime + ".txt"
$TestDir = Test-Path $Global:Log


### Fix Extra lines in the .TXT File ####
$NewArray = @()
foreach($Item in $Global:Array)
{
    if($Item.length -gt 0)
    {
        $NewArray += $Item
    }

    $Global:Array = $NewArray
}



Function CreateFolders
{
    foreach($Item in $Global:Array)
    {
 
        #Set Array paths to variables
        $SplitPaths = $Item.Split("|")
        $Src = $SplitPaths[0]
        $Dest = $SplitPaths[1]
        $Src = $Src.Trim()
        $Dest = $Dest.Trim()




        #Reform $FILEPATH with out the report
        $TestPath = ($Dest -split '/') | Where{$_ -ne ""}
        $TPCount = ($TestPath.count - 1)

        if($TPCount -eq 1){$Filepath = "/" + $TestPath[0]}
        if($TPCount -eq 2){$Filepath = "/" + $TestPath[0] + "/" + $TestPath[1]}
        if($TPCount -eq 3){$Filepath = "/" + $TestPath[0] + "/" + $TestPath[1] + "/" + $TestPath[2]}
        if($TPCount -eq 4){$Filepath = "/" + $TestPath[0] + "/" + $TestPath[1] + "/" + $TestPath[2] + "/" + $TestPath[3]}
        if($TPCount -eq 5){$Filepath = "/" + $TestPath[0] + "/" + $TestPath[1] + "/" + $TestPath[2] + "/" + $TestPath[3] + "/" + $TestPath[4]}
        if($TPCount -eq 6){$Filepath = "/" + $TestPath[0] + "/" + $TestPath[1] + "/" + $TestPath[2] + "/" + $TestPath[3] + "/" + $TestPath[4] + "/" + $TestPath[5]}



        #Test IF $FILEPATH Exists
        $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -Like "$FilePath" -and $_.TypeName -eq "Folder"}

        if($Verify -eq $NULL)
        {
            #Prep the Folder Path's
            $PathArray = ($Dest -split '/') | Where{$_ -ne ""}
            $Count = ($PathArray.count - 1) #Remove Report and set 1 = 0
            
            $i = 0
            While($i -lt $Count)
            {
                #Build the Folder Structures
                if($i -eq 0){$Test = "/" + $PathArray[0];$Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Test -and $_.TypeName -eq "Folder"}}
                if($i -eq 1){$Test = "/" + $PathArray[0] + "/" + $PathArray[1];$Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Test -and $_.TypeName -eq "Folder"}}
                if($i -eq 2){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2];$Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Test -and $_.TypeName -eq "Folder"}}
                if($i -eq 3){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2] + "/" + $PathArray[3];$Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Test -and $_.TypeName -eq "Folder"}}
                if($i -eq 4){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2] + "/" + $PathArray[3] + "/" + $PathArray[4];$Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Test -and $_.TypeName -eq "Folder"}}
                if($i -eq 5){$Test = "/" + $PathArray[0] + "/" + $PathArray[1] + "/" + $PathArray[2] + "/" + $PathArray[3] + "/" + $PathArray[4] + "/" + $PathArray[5];$Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Test -and $_.TypeName -eq "Folder"}}


                if($Verify.length -gt 0){Write-Host "Existing Path:" $Test;$OUT = "Existing Path:" + $Test | out-file $Global:Log -Append}
                if($Verify.length -lt 1){Write-Host "Creating Path:" $Test;$OUT = "Creating Path:" + $Test | out-file $Global:Log -Append}


                if($Verify.length -lt 1)
                {
                    if($i -eq 0){$Root = "/";$Path = $PathArray[0]}
                    if($i -eq 1){$Root = "/" + $PathArray[0];$Path = $PathArray[1]}
                    if($i -eq 2){$Root = "/" + $PathArray[0] + "/" + $PathArray[1];$Path = $PathArray[2]}
                    if($i -eq 3){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2];$Path = $PathArray[3]}
                    if($i -eq 4){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2] + "/" + $PathArray[3];$Path = $PathArray[4]}
                    if($i -eq 5){$Root = "/" + $PathArray[0] + "/" + $PathArray[1]  + "/" + $PathArray[2] + "/" + $PathArray[3] + "/" + $PathArray[4];$Path = $PathArray[5]}


                    New-RsFolder -reportserveruri $RS -RsFolder $Root -foldername $Path #-ErrorAction SilentlyContinue
                    

                }#End if $Verify

                $i = $i + 1

            }#End While
            
        }#If $Verify


    }#End Foreach $Item

        if($Error)
        {
            $Out = $Error | out-file $Global:Log -Append
            $Error.clear()
        }#End $Error


}#CreateFolders

Function MoveReports
{
    ## Begin Migration ##
    Foreach($Item in $Global:Array)
    {

        #Set Array paths to variables
        $SplitPaths = $Item.Split("|")
        $Src = $SplitPaths[0]
        $Dest = $SplitPaths[1]
        $Src = $Src.Trim()
        $Dest = $Dest.Trim()

        #Verify the Report Exists
        $Verify = $svc.ListChildren("/", $true) | Where{$_.Path -eq $Src -and $_.TypeName -eq "Report"}
        if($Verify -eq $NULL){Write-Host "$Src   Does not exist on Source...skipping" -ForegroundColor Red ;$OUT = $Src + "Does not exist on Source...skipping" | out-file $Global:Log -Append }
        if($Verify -ne $NULL -and $SRC.Length -gt 0)
        {
   
            $Error.Clear()
            Try{
                Write-host "Moving:  $Src  > $Dest" -ForegroundColor Yellow
                $OUT = "Moving:  $Src  > $Dest" | out-file $Global:Log -Append
                #Move Report
                $svc.MoveItem("$Src","$Dest")

            }
            Catch{
                Write-Host "Error Occurred with $Src   or    $Dest" -ForegroundColor RED
                $OUT = "Error Occurred with $Src   or    $Dest" | out-file $Global:Log -Append
                $Error
            }


        
        }#End if $Verify
          
    }#End Foreach $Item

    if($Error)
    {
        $Out = $Error | out-file $Global:Log -Append
        $Error.clear()
    }#End $Error


}#MoveReports



### Action Script  ###
CreateFolders
MoveReports