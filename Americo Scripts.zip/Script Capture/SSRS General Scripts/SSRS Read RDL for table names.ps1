﻿Import-Module ImportExcel


$Path = "C:\Users\tzumwalt\Downloads\Copy of Lab_Prod_Nacha Fields_V1.xlsx"
$Doc = Import-Excel -Path $Path


$List = $Doc.Column_name
$List = $List | Select-Object -Unique 

$Array = @()
foreach($Item in $List)
{
    $Array += $Item
}


#Path to Reports
$Path = "C:\Automation\SQLSSRS02 Reports Copy"

#Get Reports in the Path
$Reports = Get-ChildItem $Path -Recurse 
$Reports = $Reports |where{$_.Name -like "*.rdl"}


$Log = "C:\Automation\SQLSSRS02 Reports Copy\Log.txt"
$Heading = "Report Name" + "," + "Column" + "," + "Report Path"
$Heading >> $LOG


#Loop through the reports
foreach($Report in $Reports)
{
    #Find Directory Location 
    $DirPath = $Report.PSPath 
    $DirPath = $DirPath -split "::"
    $DirPath = $DirPath[1]
    #$DirPath

    #Set object Type to XML and get the Dataset
    [XML]$Rpt = (Get-Content $DirPath)
    $QueryData = $Rpt.Report.DataSets.DataSet.Query.CommandText


    #Parse the dataset for a match from the $Filter
    if($QueryData |Select-String -List $Array )
    {
        Write-Host $Report -ForegroundColor Yellow
        Write-Host $DirPath

        $PatArray = @()
        Foreach($Item in $Array)
        {
            if($QueryData |Select-String -Pattern $Item)
            {
                $Pattern = ($QueryData |Select-String -Pattern $Item).Pattern
                $Pattern = $Pattern.ToLower() #required to get unique values
                $PatArray += $Pattern
            }

        }#End Foreach $Item

        
        $PatArray = $PatArray |get-unique


        ###################### Create a Comma Delemeted Flat File ###########################
        
        foreach($Item in $PatArray)
        {
            
            Write-host $Report.name","$Item "," $DirPath >> $LOG
            $Statements = $Report.name + "," + $Item + "," + $DirPath |OUT-File $LOG -Append          
        }

        $Space = " " |OUT-File $LOG -Append

        
        " "

    }#End if $QueryData

}#End foreach $Report







