﻿Import-Module SQLServer



$Global:SrcServer = "SQLDBA51"


#Source SSRS
$SRCuri = "http://$Global:SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$type = $svc.GetType().Namespace 
$datatype = ($type + '.Property')

#Get a list of all folders
$FolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
$ReportList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report"}
$DataSources = $svc.ListChildren("/",$true) |Where{$_.TypeName -eq "DataSource"}



$InheritParent = $True

Write-Host "Folders" -ForegroundColor Yellow
foreach($Item in $FolderList)
{
    $Policies = $svc.GetPolicies($Item.path, [ref] $InheritParent)

    if($InheritParent -eq $True)
    {
        Write-Host "True - " $Item.Path
    }
    if($InheritParent -eq $False)
    {
        Write-host "False - " $Item.Path
    }
}

" "
Write-Host "Reports" -ForegroundColor Yellow
foreach($Item in $ReportList)
{
    $RPTPolicies = $svc.GetPolicies($Item.path, [ref] $InheritParent)

    if($InheritParent -eq $True)
    {
        Write-Host "True - "$Item.Path
    }
    if($InheritParent -eq $False)
    {
        Write-host "False - " $Item.Path
    }

}

" "
Write-Host "Data Sources" -ForegroundColor Yellow
foreach($Item in $DataSources)
{
    $DSPolicies = $svc.GetPolicies($Item.path, [ref] $InheritParent)

    if($InheritParent -eq $True)
    {
        Write-Host "True - " $Item.Path
    }
    if($InheritParent -eq $False)
    {
        Write-host "False - " $Item.Path
    }

}


