﻿
Import-Module SQLServer


$Global:SrcServer = "SQLDBA01"


$Log = "\\kcsan03\users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS_Remove_DB_Groups_" + $Global:SrcServer + "_log.txt"
$Test = Test-Path $log
if($Test -ne $False){Remove-Item $Log}

$Log2 = "\\kcsan03\users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS_Replace_DB_Accounts_REMOVEPerm_log.txt"
$Test = Test-Path $log2
if($Test -ne $False){Remove-Item $Log2}


$ME = whoami
if($ME -ne "KCDOM01\tzumwalt-db"){CLS ;Read-Host "Stop!  Use your DB Account!"}

#Source SSRS
$SRCuri = "http://$Global:SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$type = $svc.GetType().Namespace 
$datatype = ($type + '.Property')


#Get a list of all folders
$FolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}
$ReportList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report"}
$DataSources = $svc.ListChildren("/",$true) | Where{$_.TypeName -eq "DataSource"}
$DataSets = $svc.ListChildren("/",$true) |Where{$_.TypeName -eq "DataSet"}







####################################################################################################################################
#################################################### Start Validation (Predicted) ##################################################
####################################################################################################################################

$ReportServerDB = "ReportServer"

$Security_Validation_Predicted ="\\kcsan03\#kcsan03\users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS Add NonPriv DB Account\Step1_Predicted.sql"
$Verify = "Select Top 100 * from dbo.Security_Predicted"
Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database $ReportServerDB -InputFile $Security_Validation_Predicted -Verbose -TrustServerCertificate |format-table
Sleep -s 5
Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database $ReportServerDB -Query $Verify -TrustServerCertificate |Format-Table



####################################################################################################################################
#################################################### Validation ####################################################################
####################################################################################################################################



$InheritParent = $True

#Add Group to Folders
Write-Host "Beginning Folders" -ForegroundColor Yellow
$FolderOut = "Beginning Folders" 
$FolderOut |out-file $Log -Append
foreach($Folder in $Folderlist)
{
    
    $Policies = $svc.GetPolicies($Folder.path, [ref] $InheritParent)

    if($InheritParent -eq $False)
    {
        if($Policies.GroupUserName -Notcontains "KCDOM01\SQL_DBA_NonPriv")
        {
            if($Policies.GroupUserName -notcontains "KCDOM01\SQL_DBA_NonPriv")
            {
                Write-host $Folder.Path -ForegroundColor Yellow
                $Folder.Path |out-file $Log -Append

                $policyType = "{0}.Policy" -f $type;
                $roleType = "{0}.Role" -f $type;
                $Policy = New-Object ($policyType)
                $Policy.GroupUserName = "KCDOM01\SQL_DBA_NonPriv"
                $Policy.Roles = @()
                $RoleName = "Content Manager"

                [array]$Policies += $Policy

                foreach($Role in $RoleName)
                {
                    $r = New-Object ($roleType)
                    $r.Name = $Role
                    $Policy.Roles += $r
                }

        
                #Update the Folder Permissions
                $svc.SetPolicies($Folder.Path, $Policies)
            }
        }
    }
}







#Add Group to Reports
Write-Host "Beginning Reports" -ForegroundColor Yellow
$RPTOut = "Beginning Reports"
$RPTOut |out-file $Log -Append
#Refresh Permissions list#
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$ReportList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Report"}
foreach($Report in $ReportList)
{
    
    $ReportPolicies = $svc.GetPolicies($Report.Path,[ref] $InheritParent) 

    if($InheritParent -eq $False)
    {
        $RptArray = $ReportPolicies.GroupUserName
        if($RptArray -Notcontains "KCDOM01\SQL_DBA_NonPriv")
        {
            if($RptArray -notcontains "KCDOM01\SQL_DBA_NonPriv")
            {
                Write-Host $Report.Path -ForegroundColor Yellow
                $RPTPath1 = $Report.Path 
                $RPTPath1 |out-file $Log -Append
                $policyType = "{0}.Policy" -f $type;
                $roleType = "{0}.Role" -f $type;
                $Policy = New-Object ($policyType)
                $Policy.GroupUserName = "KCDOM01\SQL_DBA_NonPriv"
                $Policy.Roles = @()
                $RoleName = "Content Manager"

                [array]$ReportPolicies += $Policy

                foreach($Role in $RoleName)
                {
                    $r = New-Object ($roleType)
                    $r.Name = $Role
                    $Policy.Roles += $r
                }

        
                #Update the Folder Permissions
                $svc.SetPolicies($Report.Path, $ReportPolicies)

            }

        }
    }
}



#Add Group to Datasources
#Refresh Permissions list
$DSOut = "Beginning Data Sources" 
$DSOut |out-file $Log -Append
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$DataSources = $svc.ListChildren("/",$true) |Where{$_.TypeName -eq "DataSource"}
foreach($DS in $DataSources)
{
    $DSPolicies = $Svc.GetPolicies($DS.path,[ref]$InheritParent)
    $GroupArray = $DSPolicies.GroupUserName

    if($InheritParent -eq $False)
    {
        if($GroupArray -Notcontains "KCDOM01\SQL_DBA_NonPriv")
        {
            if($GroupArray -notcontains "KCDOM01\SQL_DBA_NonPriv")
            {
                Write-Host $DS.path -ForegroundColor Yellow
                $DSPath1 = $DS.path 
                $DSPath1 |out-file $Log -Append
                $policyType = "{0}.Policy" -f $type;
                $roleType = "{0}.Role" -f $type;
                $Policy = New-Object ($policyType)
                $Policy.GroupUserName = "KCDOM01\SQL_DBA_NonPriv"
                $Policy.Roles = @()
                $RoleName = "Content Manager"

                [array]$DSPolicies += $Policy

                foreach($Role in $RoleName)
                {
                    $r = New-Object ($roleType)
                    $r.Name = $Role
                    $Policy.Roles += $r
                }

        
                #Update the Data Source Permissions
                $svc.SetPolicies($DS.Path, $DSPolicies)

            }
        }
    }
}


#Add Group to DataSet
#Refresh Permissions list 
$DataSetOut = "Beginning DataSets" 
$DataSetOut |out-file $Log -Append
Write-Host "Beginning DataSets" 

$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -UseDefaultCredential
$DataSets = $svc.ListChildren("/",$true) |Where{$_.TypeName -eq "DataSet"}
foreach($DataSet in $DataSets)
{
    $DataSetPolicies = $Svc.GetPolicies($DataSet.path,[ref]$InheritParent)
    $GroupArray = $DataSetPolicies.GroupUserName

    if($InheritParent -eq $False)
    {
        if($GroupArray -Notcontains "KCDOM01\SQL_DBA_NonPriv")
        {
            if($GroupArray -notcontains "KCDOM01\SQL_DBA_NonPriv")
            {
                Write-Host $DS.path -ForegroundColor Yellow
                $DSPath2 = $DataSet.path 
                $DSPath2 |out-file $Log -Append
                $policyType = "{0}.Policy" -f $type;
                $roleType = "{0}.Role" -f $type;
                $Policy = New-Object ($policyType)
                $Policy.GroupUserName = "KCDOM01\SQL_DBA_NonPriv"
                $Policy.Roles = @()
                $RoleName = "Content Manager"

                [array]$DataSetPolicies += $Policy

                foreach($Role in $RoleName)
                {
                    $r = New-Object ($roleType)
                    $r.Name = $Role
                    $Policy.Roles += $r
                }

        
                #Update the Data Source Permissions
                $svc.SetPolicies($DataSet.Path, $DataSetPolicies)

            }
        }
    }
}





 ##############################################################################################################################
 ######################################### End Validation (Actual) #####################################################################

 $ReportServerDB = "ReportServer"


 $SecurityValidationActual = "\\kcsan03\#kcsan03\users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS Add NonPriv DB Account\Step2_Actual.sql"
 $Verify = "select Top(100) * from dbo.Security_Actual"
 Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database $ReportServerDB -InputFile $SecurityValidationActual -TrustServerCertificate -Verbose |Format-Table
 Sleep -s 5
 Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database  $ReportServerDB -Query $Verify -TrustServerCertificate |Format-table -Verbose

 #########################################################################################################################################


 ##################################### COMAPRE RESULTS ##################################################################################


 $ReportServerDB = "ReportServer"

 $Compare = "\\kcsan03\#kcsan03\users\tzumwalt\Scripts\Projects\PAW Boxes\SSRS Add NonPriv DB Account\Step3_Compare.sql"
 $Verify = "select Top(100) * from dbo.Security_Compare"
 Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database $ReportServerDB -InputFile $Compare -TrustServerCertificate -Verbose |Format-Table
 Sleep -s 5
 Invoke-Sqlcmd -ServerInstance $Global:SrcServer -Database  $ReportServerDB -Query $Verify -TrustServerCertificate |Format-table -Verbose

 ########################################################################################################################################








