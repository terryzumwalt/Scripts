﻿import-module sqlserver
import-module importexcel


$File = Import-Excel -Path "C:\Users\tzumwalt\Downloads\Production Informatica DB Access 2023-03-28.xlsx"
$ServiceAccount = "KCDOM01\Informatica_DB"



$Servers = $File.server
$Servers = $Servers |Select-Object -Unique


foreach($Srv in $Servers)
{
    $Server = New-object("Microsoft.SQLServer.Management.SMO.Server")$Srv
    $Srv
    $Databases = ($File |Where{$_.Server -eq $Srv}).database
    $Databases.count
    $Login = $Server.Logins |Where{$_.Name -eq $ServiceAccount}

    if($Login -ne $NULL)
    {
        Write-Host "Account Exists on $Srv : $Login"
    
    }



    #This section will count the # of permissions in the sheet vs how many are assigned.
    #Populated data may be a purposefull change.
    foreach($Database in $Databases)
    {
        $users = ($Server.databases[$Database].Users).name
        
        if($users -contains $ServiceAccount)
        {
            Write-Host "User Exists on $Srv : Database - $Database"
        }

        if($users -notcontains "KCDOM01\SQL_Informatica_Support")
        {
            Write-Host "User KCDOM01\SQL_Informatica_Support Does Not Exists on $Srv : Database - $Database"
        }


        $Userobj = ($Server.databases[$Database].Users)
        $Userobj = $Userobj |Where{$_.Name -eq "KCDOM01\SQL_Informatica_Support"}
        $UserRoles = $UserObj.EnumRoles()
        $CountRoles = $UserRoles.Count
        

        $FileDB = $File |Where{$_.Server -eq $SRV -and $_.Database -eq $Database -and $_."AD Group" -eq "KCDOM01\SQL_Informatica_Support"} 
        $FDR = ($FileDB.db_datareader).count
        $FDW = ($FileDB.db_datawriter).count
        $FDDL = ($FileDB.db_ddladmin).count
        $Array = $FDR + $FDW + $FDDL

        if($CountRoles -ne $Array)
        {
            Write-host "Role count issue with $Srv : $Database"
        }


        $FDR = $NULL
        $FDW = $NULL
        $FDDL = $NULL
        $Array = $NULL

        Read-host "Press Enter"




    }







} #End Foreach