﻿Import-Module SQLServer

#Servers containing dbo.serverlist
$ServerArray = "SQLDBA01","SQLDBA51"

#Query to get the list of Server Names
$Query = "Select Server_Name from dbo.ServerList"

#Loop the $ServerArray and gather all the server names in to $ListArray
$ListArray = @()
Foreach($Srv in $ServerArray)
{
    $SrvList = Invoke-Sqlcmd -ServerInstance $Srv -Database "DBA_WORKDB" -Query $Query 

    foreach($Item in $SrvList)
    {
        $ListArray += $Item.Server_Name
    }
}


#Un-Comment to scan these, they fail on run 1
#$ListArray = "SQLDBA01","KCSCSQL70"

#Loop the list of server names and search each server services for SSAS (OLAP)
$HasOLAP = @()
foreach($SN in  $ListArray)
{
    Write-Host $SN -ForegroundColor Yellow
    $Services = Invoke-Command -ComputerName $SN {Get-Service |Where{$_.Name -like "*OLAP*"}}
    if($Services)
    {
        $HasOlap += $Services
    }
}

$HasOlap.PSCOMPUTERName






