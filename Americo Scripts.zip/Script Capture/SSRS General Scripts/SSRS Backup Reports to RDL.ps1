﻿
<#
    1. Change the $URI to the server you want to backup reports from
    2. Change $SourceDirectory to the SSRS Folder directory you want to back up. Using just "/" will grab everything on the server. 
    3. Change Destination to a directory local to where the script is running. 

    If you want to view what is in your directory or on the server use the following after loading the $Proxy 
    Change your directory first. 
    
    $Proxy.ListChildren("/TZTemp",$True)

    #(https://social.msdn.microsoft.com/Forums/en-US/f64b3071-ffb5-40b6-8529-49b5d9fe159a/what-apis-are-available-for-reading-rdl-files)
#>


#******* prerequisites *************#
#You will need to have install permissions locally to run Step 1. 

#Step 1
Install-Module -Name ReportingServicesTools

#Step 2: (After 1 is complete)   
Import-Module ReportingServicesTools

#***********************************#



#Declare URI
$URI = "http://SQLSSRS02/ReportServer"

#Create Proxy to SSRS
$Proxy = New-RsWebServiceProxy -ReportServerUri $URI 

      
$SourceDirectory = "/"
$Destination = "C:\Automation\TEMP" 


#Download the .RDL files from the Source Directory.
Out-RsFolderContent -Proxy $Proxy -RsFolder $SourceDirectory -Destination $Destination -Recurse -Verbose





