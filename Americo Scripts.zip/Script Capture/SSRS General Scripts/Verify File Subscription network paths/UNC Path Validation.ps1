﻿


Import-Module ReportingServicesTools
import-Module importexcel


#import the Path's to check
$Paths = import-excel -Path "Y:\Scripts\SSRS General Scripts\Verify File Subscription network paths\Book1.xlsx"

#Destination
$Source = "http://SQLSSRS02/reportserver/ReportService2010.asmx"

#list all subscriptions  
$rs2010 = New-WebServiceProxy -Uri $Source -Namespace SSRS.ReportingService2010 -UseDefaultCredential;  
$subscriptions = $rs2010.ListSubscriptions("/");  

#$Paths = $Paths.itempath[136]
foreach($Path in $Paths.itemPath)
{

    $SUB = $subscriptions |Where{$_.Path -like $Path}
    foreach($Item in $Sub)
    {
        $Values = $Item.DeliverySettings.ParameterValues
        $FilteredVal = ($Values.GetValue(0)).Value

        #Exclude Email Subscriptions
        if($FilteredVal -Notlike "*@*")
        {
    
            Write-host $Item.Path
            Write-host $FilteredVal -ForegroundColor Yellow
            " "

            #Write to log
            $Log = "Y:\Scripts\SSRS General Scripts\Verify File Subscription network paths\Log.txt"
            $Item.Path >> $Log
            $FilteredVal >> $Log
            $Space = " " >>  $Log

        }
        
    }
}




#kcnas01\








