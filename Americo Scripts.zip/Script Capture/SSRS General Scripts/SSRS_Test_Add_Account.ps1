import-module SQLServer

$Global:SrcServer = "sqlscom04"


#Source SSRS
$SRCuri = "http://$Global:SrcServer/reportserver/ReportService2010.asmx"
$svc = New-WebServiceProxy -Class 'RS' -Uri $SRCuri -Credential "KCDOM01\svc_scom_DRA_prod"
$type = $svc.GetType().Namespace 
$datatype = ($type + '.Property')


#Get a list of all folders
$FolderList = $svc.ListChildren("/", $true) | select -Property Path,TypeName |Where{$_.TypeName -eq "Folder"}




<#
SQLDCOM04
KCDOM01\svc_scom_DRA_prod
uI|6V@omyp/a*PE0&
#>