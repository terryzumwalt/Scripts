﻿

Add-Type -AssemblyName System.Windows.Forms

#Current Position
$Pos = [Windows.Forms.Cursor]::Position


# [Windows.Forms.Cursor]::Position = $Pos 

$i = 0
While($i -ne 1)
{
    
    $Pos.x = 100
    $Pos.y  = 50
    [Windows.Forms.Cursor]::Position = $Pos  #New Position


    While($Pos.x -le 1000)
    {
        $Pos.x += 10
        $Pos.y  += 10
        [Windows.Forms.Cursor]::Position = $Pos  #New Position

        if($Pos.x -ge 1000)
        {
            $Pos.x = 100
            $Pos.y  = 50
            [Windows.Forms.Cursor]::Position = $Pos  #New Position
         
        }

            Write-Host "Position is: $Pos"
            Sleep -Seconds 5
 
    }


    Write-Host "Position is: $Pos"
    " "


    Sleep -Seconds 5
}