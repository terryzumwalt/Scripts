#NOSQLPS
import-module SQLServer


<#
    INFO:
    Server: SQLDBA01
    Database: DBA_WorkDB
    Table: dbo.Azure_Logins - Not Created Yet


    MAYBE: - Not Created Yet
    USE DBA_WorkDB
    GO
    CREATE TABLE dbo.spr_Azure_Logins(
        ID INT IDENTITY(1,1) PRIMARY KEY,
        Logins NVARCHAR(100) NOT NULL
    )

    
#>



$InstanceArray = "ame-mi-prod-01-central.16559c496249.database.windows.net"
$DB = "AmericoStoragePS"
$QueryLogins = "SELECT Name FROM sys.sql_logins"

foreach($Srv in $InstanceArray)
{
    $Logins = Invoke-Sqlcmd -Query $QueryLogins -ConnectionString "Server=tcp:$Srv,1433;Database=$DB;Authentication=Active Directory Integrated;Encrypt=True;"  
    $Logins = $Logins.name

}#End foreach $Instance