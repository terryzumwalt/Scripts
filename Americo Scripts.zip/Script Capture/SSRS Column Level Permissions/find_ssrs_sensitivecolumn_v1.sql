WITH XMLNAMESPACES 
(  DEFAULT
  'http://schemas.microsoft.com/sqlserver/reporting/2010/01/reportdefinition' 
, 'http://schemas.microsoft.com/SQLServer/reporting/reportdesigner' AS ReportDefinition)
SELECT  
CATDATA.Name AS ReportName
,CATDATA.Path AS ReportPathLocation
,xmlcolumn.value('(@Name)[1]', 'VARCHAR(250)') AS DataSetName  
,xmlcolumn.value('(Query/DataSourceName)[1]','VARCHAR(250)') AS DataSoureName 
,xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(2500)') AS CommandText
,path
 ,CASE Type
               WHEN 2 THEN
                   'Report'
               WHEN 5 THEN
                   'Data Source'
               WHEN 7 THEN
                   'Report Part'
               WHEN 8 THEN
                   'Shared Dataset'
               ELSE
                   'Other'
           END AS TypeDescription,
CASE WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%ACCOUNTNUMBER%' THEN 'yes' 
--WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%TaxIdNumber%' THEN 'yes' 

                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%BANK_ACCOUNT_NUMBER%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%AccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%PAYEE_BANK_ACCOUNT_NUMBER%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%MBHP_BANK_ACCOUNT_NUM%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%PayeeBankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Recipient Bank Account%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%APAccountHolderType%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%BANK_CHECK_ID6%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%BankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%EFTAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%RIP_BANK_ACCOUNT_NO%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Address_AccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Banking_AccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%PAC_BANK_OR_CHECK_DATA%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%BANK_CHECK_ID4%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%AcctNo%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%NewBankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%OldBankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%ClientBankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%accountnumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Old PayeeBankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%New PayeeBankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Bank Account No_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%G_L Bank Account No_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Recipient Bank Acc_ No_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Sender Bank Account No_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Bank Account Nos_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Bank Activity Batch Nos_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Our Account No_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Bank_Account_No_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Client_Bank_Account_No%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%From Bank Account No_%' THEN 'yes' 
                    else 'No'
                 END AS SensitiveFieldInReport
FROM (  
	SELECT C.Name
	,c.Path
	,CONVERT(XML,CONVERT(VARBINARY(MAX),C.Content)) AS reportXML
	, c.Type
	,c.Content
	FROM  ReportServer.dbo.Catalog C
	WHERE  C.Content is not null
	AND c.Type IN ( 2, 5, 7, 8 )
	--and Name in('AgentBankDataChange','2020 Distribution Types')
	) CATDATA
CROSS APPLY reportXML.nodes('/Report/DataSets/DataSet') xmltable ( xmlcolumn )
--where CATDATA.Name ='AgentBankDataChange'
ORDER BY CATDATA.Name
--2016


WITH XMLNAMESPACES 
(  DEFAULT
  'http://schemas.microsoft.com/sqlserver/reporting/2016/01/reportdefinition'
, 'http://schemas.microsoft.com/SQLServer/reporting/reportdesigner' AS ReportDefinition )
SELECT  
CATDATA.Name AS ReportName
,CATDATA.Path AS ReportPathLocation
,xmlcolumn.value('(@Name)[1]', 'VARCHAR(250)') AS DataSetName  
,xmlcolumn.value('(Query/DataSourceName)[1]','VARCHAR(250)') AS DataSoureName 
,xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(2500)') AS CommandText
,path
 ,CASE Type
               WHEN 2 THEN
                   'Report'
               WHEN 5 THEN
                   'Data Source'
               WHEN 7 THEN
                   'Report Part'
               WHEN 8 THEN
                   'Shared Dataset'
               ELSE
                   'Other'
           END AS TypeDescription,
CASE WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%ACCOUNTNUMBER%' THEN 'yes' 
--WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%TaxIdNumber%' THEN 'yes' 

                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%BANK_ACCOUNT_NUMBER%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%AccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%PAYEE_BANK_ACCOUNT_NUMBER%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%MBHP_BANK_ACCOUNT_NUM%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%PayeeBankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Recipient Bank Account%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%APAccountHolderType%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%BANK_CHECK_ID6%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%BankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%EFTAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%RIP_BANK_ACCOUNT_NO%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Address_AccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Banking_AccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%PAC_BANK_OR_CHECK_DATA%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%BANK_CHECK_ID4%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%AcctNo%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%NewBankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%OldBankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%ClientBankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%accountnumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Old PayeeBankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%New PayeeBankAccountNumber%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Bank Account No_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%G_L Bank Account No_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Recipient Bank Acc_ No_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Sender Bank Account No_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Bank Account Nos_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Bank Activity Batch Nos_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Our Account No_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Bank_Account_No_%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%Client_Bank_Account_No%' THEN 'yes' 
                                                WHEN xmlcolumn.value('(Query/CommandText)[1]','VARCHAR(max)') like '%From Bank Account No_%' THEN 'yes' 
                    else 'No'
                 END AS SensitiveFieldInReport
FROM (  
	SELECT C.Name
	,c.Path
	,CONVERT(XML,CONVERT(VARBINARY(MAX),C.Content)) AS reportXML
	, c.Type
	,c.Content
	FROM  ReportServer.dbo.Catalog C
	WHERE  C.Content is not null
	AND c.Type IN ( 2, 5, 7, 8 )
	--and Name in('AgentBankDataChange','2020 Distribution Types')
	) CATDATA
CROSS APPLY reportXML.nodes('/Report/DataSets/DataSet') xmltable ( xmlcolumn )
--where CATDATA.Name ='AgentBankDataChange'
ORDER BY CATDATA.Name


