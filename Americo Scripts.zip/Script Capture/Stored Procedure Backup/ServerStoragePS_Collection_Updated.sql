

USE [AmericoStoragePS]
GO

/****** Object:  StoredProcedure [dbo].[ServerStoragePS_Collection]    Script Date: 3/1/2023 11:18:18 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- All servers

Alter PROCEDURE [dbo].[ServerStoragePS_Collection]
AS
BEGIN

truncate table [AmericoStoragePS].[dbo].[ServerStoragePS_Staging]


DECLARE @SQL NVARCHAR(4000)

IF OBJECT_ID('tempdb..#FileSizes') IS NOT NULL
	DROP TABLE #FileSizes


CREATE TABLE #FileSizes (
	timecollected DATETIME2,
	ServerName NVARCHAR(255),
	DatabaseName NVARCHAR(128),
	Logical_Filename NVARCHAR(128),
	File_Group NVARCHAR(128),
	FileType NVARCHAR(60),
	Drive NVARCHAR(10),
	File_Path NVARCHAR(260),
	Allocated_MB FLOAT,
	Allocated_Used_MB DECIMAL(15,3),
	Allocated_Free_MB DECIMAL(15,3),
	Disk_Total_MB DECIMAL(15,3),
	Disk_Used_MB DECIMAL(15,3),
	Drive_Free_MB DECIMAL(15,3)
  )


SET @SQL =
'Use [?]; Insert into #FileSizes
SELECT GetDate() as timecollected,
CONVERT(NVARCHAR(128),SERVERPROPERTY(''machinename'')) AS ServerName, 
db_name(db_id()) as DatabaseName,
df.name as Logical_Filename,
ISNULL(fg.name,''<log>'') as File_Group,
df.type_desc as FileType, 
CASE WHEN vs.volume_mount_point LIKE ''\\Cohesity%'' THEN ''CO:'' ELSE replace(vs.volume_mount_point,''\'','''') END AS Drive,
physical_name as File_Path,
ISNULL(size*8.0/1024.0,0) as Allocated_MB,
ISNULL(Convert(Float,FILEPROPERTY(df.name, ''SpaceUsed''))*8.0/1024.0,0) as Allocated_Used_MB,
ISNULL(size*8.0/1024.0 - Convert(Float,FILEPROPERTY(df.name, ''SpaceUsed''))*8.0/1024.0,0) as Allocated_Free_MB,
vs.total_bytes/1024.0 /1024.0 as Disk_Total_MB,
vs.total_bytes/1024.0 /1024.0 - available_bytes /1024.0/1024.0 AS Disk_Used_MB,
vs.available_bytes/1024.0/1024.0 as Drive_Free_MB
from sys.database_files df
left outer join sys.filegroups fg on df.data_space_id = fg.data_space_id
cross apply sys.dm_os_volume_stats(db_id(), df.file_id) vs'


EXEC sp_msforeachdb @SQL

INSERT INTO [AmericoStoragePS].[dbo].[ServerStoragePS_Staging](timecollected,ServerName,DatabaseName,Logical_Filename,File_Group,FileType,Drive,File_Path,Allocated_MB,Allocated_Used_MB,Allocated_Free_MB,Disk_Total_MB,Disk_Used_MB,Drive_Free_MB)
SELECT timecollected,ServerName,DatabaseName,Logical_FileName,File_Group,FileType,Drive,File_Path,Allocated_MB,Allocated_Used_MB,Allocated_Free_MB,Disk_Total_MB,Disk_Used_MB,Drive_Free_MB
FROM #FileSizes
END
GO
