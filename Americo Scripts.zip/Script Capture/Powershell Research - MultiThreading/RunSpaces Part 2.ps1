﻿
#https://devblogs.microsoft.com/scripting/beginning-use-of-powershell-runspaces-part-1/


#This script allows the new runspace to run in the background instead of this instance pausing.
#Becarefull with this one and when you Dispose of the Runspace
#Part 3 shows how to use a runspace pool and re-use the threads. 





#Create a runspace (Thread)
$Runspace = [runspacefactory]::CreateRunspace()

#Create a powershell instance
$PowerShell = [powershell]::Create()

#Add the Insatnce to the RUNSPACE 
$PowerShell.runspace = $Runspace

#Open the Runspace
$Runspace.Open()


#Show the Runspace
$Powershell.runspace

#Add a script to the runspace
[void]$PowerShell.AddScript({

    Get-Date

    Start-Sleep -Seconds 10

})

#This object allows the script to run ASYNC in the background
$AsyncObject = $PowerShell.BeginInvoke()


#inspect the Status of the invoked process
$AsyncObject


#Dispose of the AsyncObject
$Data = $PowerShell.EndInvoke($AsyncObject)
$Data



#Dispose of the instance
$Powershell.Dispose()




<#

$Powershell.runspace



#>