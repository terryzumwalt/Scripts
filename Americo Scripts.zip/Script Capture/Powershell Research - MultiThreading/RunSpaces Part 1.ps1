﻿#https://devblogs.microsoft.com/scripting/beginning-use-of-powershell-runspaces-part-1/

#This only creates multiple instances of Powershell to send scripts too but your console will not be free
#Use RunSpaces Part 2 and 3 scripts. 

#Show Current Run Spaces
#Get-RunSpace

#New RunSpace
$PowerShell = [powershell]::Create()

#Use the RunSpace
[VOID]$PowerShell.AddScript({ 



get-date 



})

#invoke the Script
$PowerShell.invoke()

<#------------------------------------------------------------#>



Get-RunSpace

$PowerShell.Runspace.Dispose()

$PowerShell.Dispose()