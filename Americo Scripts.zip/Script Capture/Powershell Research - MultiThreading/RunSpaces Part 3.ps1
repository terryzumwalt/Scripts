﻿#https://devblogs.microsoft.com/scripting/beginning-use-of-powershell-runspaces-part-3/



#The only real benifit of this is to see how to re-use the threads by using a pool instead.  or create a dispose like Part2
#FYI: you can use params with this script you will have to go to the website above to get that code. 



#Create Runspace Pool 
[runspacefactory]::CreateRunspacePool()


#Default Option here is "Reuse Thread"
$SessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()

#Add Pool Run Throttle
$RunspacePool = [runspacefactory]::CreateRunspacePool(

    1, #Min Runspaces

    10 #Max Runspaces

)

#Create Powershell Instance
$PowerShell = [powershell]::Create()

#Add the Instance to the Pool
$PowerShell.RunspacePool = $RunspacePool

#Open the RunSpace
$RunspacePool.Open()


#This is where you are specifying the work to do
1..50 | ForEach {

    #Create PowerShell Instance
    $PowerShell = [powershell]::Create()

    #Add the Instance to the Pool
    $PowerShell.RunspacePool = $RunspacePool

    #Add the Script to the Instance
    [void]$PowerShell.AddScript({

        

        get-date
        Sleep -Seconds 10

    })



    #Launch the Script in its own space
    $Handle = $PowerShell.BeginInvoke()
    #$Handle

}#End Foreach






#Shows the amount of runspaces available
$RunspacePool.GetAvailableRunspaces()

#This will show the status of your RunSpaces (Re-run this a few times while your threads are alive to see them end.)
Get-Runspace


<#
Grab the Thread ID 
$ThreadID = [appdomain]::GetCurrentThreadId()


#Array list method
$jobs = New-Object System.Collections.ArrayList


#>

