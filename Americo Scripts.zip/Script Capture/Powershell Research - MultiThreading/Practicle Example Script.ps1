﻿Import-Module SQLServer


#NOTE: The code is working because im passing $Name as an argument and fetching it in the script block as a param.
#This is important becuase now I can direct the script at a specific Host per each loop.
### How This works ###
#Before the 


#Create Runspace Pool 
[runspacefactory]::CreateRunspacePool()


#Set the Runspace Session State (Default Option is "Reuse Thread")
$SessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()

#Add Runspace Pool Throttle
$RunspacePool = [runspacefactory]::CreateRunspacePool(1,5) #(Min,Max)Threads


#Create Powershell Instance
$PowerShell = [powershell]::Create()

#Add the Instance to the Pool
$PowerShell.RunspacePool = $RunspacePool

#Open the RunSpace
$RunspacePool.Open()


<#Query for a list of SQL Server Names#>
$NameQuery = 'select server_name from dbo.serverlist'
$Names = Invoke-Sqlcmd -ServerInstance "SQLDBA51" -Database "DBA_WORKDB" -Query $NameQuery
$Global:Names = $Names.server_name


#Loop the server names
Foreach($Global:Name in $Global:Names) {


    #Create PowerShell Instance
    $PowerShell = [powershell]::Create()

    #Add the Instance to the Pool
    $PowerShell.RunspacePool = $RunspacePool

    

    #Add the Script to the Instance (Created above)
    [void]$PowerShell.AddScript({

        #Required to get the variable from outside the script block.
        param(
            [String]$Name
        )

        #Test that the variable was passed.
        if($Global:Name -eq $NULL)
        {
            $Name = "Fail"
        }

        #Log either the passed $Name Variable or Fail if it didnt pass. 
        $Name |out-File "C:\Temp\RunSpaceTesting\RunSpaceResults.txt" -Append

    }).AddArgument($Global:Name) #End "AddScript"



    #Launch the Script in its own RunSpace
    $InvokePS = $PowerShell.BeginInvoke()
    $invokePS
    

}#End Foreach




<# INFO #>

#Shows the amount of runspaces available
$RunspacePool.GetAvailableRunspaces()
#Get-Runspace


<# Clean Up #>
$RunspacePool.Dispose()
$PowerShell.Dispose()






<#  

Grab the Thread ID 
$ThreadID = [appdomain]::GetCurrentThreadId()


#Array list method
$jobs = New-Object System.Collections.ArrayList


#>

