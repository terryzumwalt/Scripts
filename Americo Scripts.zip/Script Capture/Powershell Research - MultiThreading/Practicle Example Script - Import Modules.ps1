﻿Import-Module SQLServer


#This script is designed to test Multithreading. 
#What is it doing: 
# 1. This script will open a runspace pool set to your throttle limmit (currently 20)
# 2. It will then query SQLDBA51 for a list of lab server names. 
# 3. The names will be looped, for each name a thread will be spun up and the script designed for the host will be ran. 
# 4. The Host script will import the SQL Server Module, Build a .net object for the host and fetch the product level info. 
# 5. The Server Name and Product will be logged. 
# This design was intended to prove Multi Threading with Powershell and DBA work. 

#Create Runspace Pool 
[runspacefactory]::CreateRunspacePool()


#Set the Runspace Session State (Default Option is "Reuse Thread")
$SessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()

#Add Runspace Pool Throttle
$RunspacePool = [runspacefactory]::CreateRunspacePool(1,20) #(Min,Max)Threads


#Create Powershell Instance
$PowerShell = [powershell]::Create()

#Add the Instance to the Pool
$PowerShell.RunspacePool = $RunspacePool

#Open the RunSpace
$RunspacePool.Open()


<#Query for a list of SQL Server Names#>
$NameQuery = 'select server_name from dbo.serverlist'
$Names = Invoke-Sqlcmd -ServerInstance "SQLDBA51" -Database "DBA_WORKDB" -Query $NameQuery
$Names = $Names.server_name


#Loop the server names
Foreach($Name in $Names) {


    #Create PowerShell Instance
    $PowerShell = [powershell]::Create()

    #Add the Instance to the Pool
    $PowerShell.RunspacePool = $RunspacePool


    #Add the Script to the Instance (Created above)
    [void]$PowerShell.AddScript({


        #Required to get the variable from outside the script block.
        param(
            [String]$Name
        )

        
        if($Name -eq $NULL)
        {
            $Name = "Fail"
        }

        try{
            
            #Log The Server Name
            $Name |out-File "C:\Temp\RunSpaceTesting\RunSpaceResults.txt" -Append

            #Get Product Level Dtaa
            $Server = New-Object("Microsoft.SQLServer.Management.SMO.Server")$Name
            $PL = $Server.ProductLevel
            $PL | out-File "C:\Temp\RunSpaceTesting\RunSpaceResults.txt" -Append


        }
        Catch{
            
            $fail = "Fail"
            $Fail |Out-File "C:\Temp\RunSpaceTesting\RunSpaceResults.txt" -Append
        }


       sleep -s 10


    }).AddArgument($Name) #End "AddScript"

    #Add: (import-Module SQLServer)
    $Powershell.Commands.AddCommand("Import-Module")
    $Powershell.AddArgument("sqlserver")




    #Launch the Script in its own RunSpace
    $InvokePS = $PowerShell.BeginInvoke() 
    #$invokePS
    

}#End Foreach




<# INFO #>

#Shows the amount of runspaces available
#$RunspacePool.GetAvailableRunspaces()

#This will show you the run spaces and if they are being used.
#Get-Runspace


<# Clean Up #>
#$RunspacePool.Dispose()
#$PowerShell.Dispose()






<#  

Grab the Thread ID 
$ThreadID = [appdomain]::GetCurrentThreadId()


#Array list method
$jobs = New-Object System.Collections.ArrayList


#>

