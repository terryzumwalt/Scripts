--Troubleshooting I/0 and Growing Databases
EXIT
END

/*

--FUll list of DISK and File stats
SELECT db_name(database_id) DatabaseName, * FROM sys.dm_io_virtual_file_stats(NULL, NULL)

Select DatabaseName,db_id, From FROM sys.dm_io_virtual_file_stats(NULL, NULL)


--Check DB For consistancy
dbcc checkdb('NJ_DEV_DOR_Annual_Report')

--Full list of events waiting
select * from  sys.dm_os_wait_stats

use OR_PRD_MOSS03_C_Courts_Baker
exec sp_spaceused

ALTER DATABASE crp_prd_sec_NS SET SINGLE_USER WITH ROLLBACK IMMEDIATE
ALTER DATABASE crp_prd_sec_NS SET Multi_USER WITH ROLLBACK IMMEDIATE
GO

Restore database crp_prd_sec_NS with RECOVERY


SELECT *
  FROM sys.dm_db_index_usage_stats

  use CRP_STG_FormServices

*/


--1. SHOW LOG ERRORS----
--Exec sp_readerrorlog 0,1, 'Fail'


/*
CREATE LOGIN [NICUSA\srvd_crp_brands] FROM WINDOWS
GRANT CONNECT SQL TO [NICUSA\srvd_crp_brands]
*/

## Tracing Deadlocks ##
https://www.mssqltips.com/sqlservertutorial/252/tracing-a-sql-server-deadlock/


-- SPACE CONSUMED BY A DB or Instance  -- From Jeff
SELECT a.io_stall, a.io_stall_read_ms, a.io_stall_write_ms, a.num_of_reads,
a.num_of_writes,
--a.sample_ms, a.num_of_bytes_read, a.num_of_bytes_written, a.io_stall_write_ms,
( ( a.size_on_disk_bytes / 1024 ) / 1024.0 ) AS size_on_disk_mb,
db_name(a.database_id) AS dbname,
b.name, a.file_id,
db_file_type = CASE
                  WHEN a.file_id = 2 THEN 'Log'
                  ELSE 'Data'
                  END,
UPPER(SUBSTRING(b.physical_name, 1, 2)) AS disk_location
FROM sys.dm_io_virtual_file_stats (NULL, NULL) a
JOIN sys.master_files b ON a.file_id = b.file_id
AND a.database_id = b.database_id
ORDER BY a.io_stall DESC









/*

---Set Max Worker threads
USE master;  
GO  
EXEC sp_configure 'show advanced option', '1';  
RECONFIGURE
exec sp_configure 'Max worker threads', '4096'
RECONFIGURE;  
EXEC sp_configure;  

*/







use  NJ_Prd_DOR_FORMATIONS


--2. Show databases with the Most I/O

SELECT name AS 'Database Name'     
,SUM(num_of_reads) AS 'Number of Read'      
,SUM(num_of_writes) AS 'Number of Writes'
FROM sys.dm_io_virtual_file_stats(NULL, NULL) I  
INNER JOIN sys.databases D       
ON I.database_id = d.database_id
GROUP BY name ORDER BY 'Number of Read' DESC;


--3. Get DB ID
SELECT db_name(database_id) DatabaseName, database_id FROM sys.dm_io_virtual_file_stats(NULL, NULL)





--4. Identify Physical location of DB files and logs (Change DB Name)
--Remove Where to see all DB's or just change the DB Name
SELECT name, physical_name AS current_file_location
FROM sys.master_files where name ='NJ_NJSP_CriminalRecords'



--5. List queries on specific DB (Change msdb to your DB)
SELECT deqs.last_execution_time AS [Time], dest.text AS [Query], dest.*
FROM sys.dm_exec_query_stats AS deqs
CROSS APPLY sys.dm_exec_sql_text(deqs.sql_handle) AS dest
WHERE dest.dbid = DB_ID('MD_MOSS_PRD2_Portal')
ORDER BY deqs.last_execution_time DESC




--6. Show the amount of I0 performed by each database in the Last 5 Min
DECLARE @Sample TABLE (
  DBName varchar(128) 
 ,NumberOfReads bigint
 ,NumberOfWrites bigint)

INSERT INTO @Sample 
SELECT name AS 'DBName'
      ,SUM(num_of_reads) AS 'NumberOfRead'
      ,SUM(num_of_writes) AS 'NumberOfWrites' 
FROM sys.dm_io_virtual_file_stats(NULL, NULL) I
  INNER JOIN sys.databases D  
      ON I.database_id = d.database_id
GROUP BY name 

WAITFOR DELAY '00:05:00.000';

SELECT FirstSample.DBName
      ,(SecondSample.NumberOfReads - FirstSample.NumberOfReads) AS 'Number of Reads'
      ,(SecondSample.NumberOfWrites - FirstSample.NumberOfWrites) AS 'Number of Writes'
FROM 
(SELECT * FROM @Sample) FirstSample
INNER JOIN
(SELECT name AS 'DBName'
      ,SUM(num_of_reads) AS 'NumberOfReads'
      ,SUM(num_of_writes) AS 'NumberOfWrites' 
FROM sys.dm_io_virtual_file_stats(NULL, NULL) I
  INNER JOIN sys.databases D  
      ON I.database_id = d.database_id
GROUP BY name) AS SecondSample
ON FirstSample.DBName = SecondSample.DBName
ORDER BY 'Number of Reads' DESC;




--Thread Pool Exhaustion/Waits
use master
Select * from sys.dm_os_waiting_tasks

--Count SQL Threads Used.
Select Count(*) from sys.dm_os_threads where started_by_sqlservr = 1
exec sp_configure --View Max Worker Threads



--SHOW CONNECTIONS TO INSTANCE PER Source
CREATE TABLE #tbl (
      spid      int
    , ecid      int
    , status    varchar(50)
    , loginame  varchar(255)
    , hostname  varchar(255)
    , blk       varchar(50)
    , dbname    varchar(255)
    , cmd       varchar(255)
    , request_id varchar(255)
    )
GO

INSERT INTO #tbl EXEC sp_who

SELECT COUNT(0), hostname FROM #tbl group by hostname 

DROP TABLE #tbl
GO



--Show Connections on DB
DECLARE @AllConnections TABLE(
    SPID INT,
    Status VARCHAR(MAX),
    LOGIN VARCHAR(MAX),
    HostName VARCHAR(MAX),
    BlkBy VARCHAR(MAX),
    DBName VARCHAR(MAX),
    Command VARCHAR(MAX),
    CPUTime INT,
    DiskIO INT,
    LastBatch VARCHAR(MAX),
    ProgramName VARCHAR(MAX),
    SPID_1 INT,
    REQUESTID INT
)
INSERT INTO @AllConnections EXEC sp_who2
SELECT * FROM @AllConnections WHERE DBName = 'MSEGOV_PRD_DPS'


--SHOW LAST TIME USED PER DB
use COP_STG_ECOMMERCE
SELECT
last_user_seek = MAX(last_user_seek),
last_user_scan = MAX(last_user_scan),
last_user_lookup = MAX(last_user_lookup),
last_user_update = MAX(last_user_update)
FROM
sys.dm_db_index_usage_stats
WHERE
[database_id] = DB_ID()







--Show Suspended Queries
SELECT  wt.session_id, 
    ot.task_state, 
    wt.wait_type, 
    wt.wait_duration_ms, 
    wt.blocking_session_id, 
    wt.resource_description, 
    es.[host_name], 
    es.[program_name] 
FROM  sys.dm_os_waiting_tasks  wt  
INNER  JOIN sys.dm_os_tasks ot ON ot.task_address = wt.waiting_task_address 
INNER JOIN sys.dm_exec_sessions es ON es.session_id = wt.session_id 
WHERE es.is_user_process =  1 





--. List I0 by drive letter
SELECT left(f.physical_name, 1) AS DriveLetter, 
	DATEADD(MS,sample_ms * -1, GETDATE()) AS [Start Date],
	SUM(v.num_of_writes) AS total_num_of_writes, 
	SUM(v.num_of_bytes_written) AS total_num_of_bytes_written, 
	SUM(v.num_of_reads) AS total_num_of_reads, 
	SUM(v.num_of_bytes_read) AS total_num_of_bytes_read, 
	SUM(v.size_on_disk_bytes) AS total_size_on_disk_bytes
FROM sys.master_files f
INNER JOIN sys.dm_io_virtual_file_stats(NULL, NULL) v
ON f.database_id=v.database_id and f.file_id=v.file_id
GROUP BY left(f.physical_name, 1),DATEADD(MS,sample_ms * -1, GETDATE());








--List top 25 queries that are the most expensive
SELECT TOP 25 cp.usecounts AS [execution_count]
      ,qs.total_worker_time AS CPU
      ,qs.total_elapsed_time AS ELAPSED_TIME
      ,qs.total_logical_reads AS LOGICAL_READS
      ,qs.total_logical_writes AS LOGICAL_WRITES
      ,qs.total_physical_reads AS PHYSICAL_READS 
      ,SUBSTRING(text, 
                   CASE WHEN statement_start_offset = 0 
                          OR statement_start_offset IS NULL  
                           THEN 1  
                           ELSE statement_start_offset/2 + 1 END, 
                   CASE WHEN statement_end_offset = 0 
                          OR statement_end_offset = -1  
                          OR statement_end_offset IS NULL  
                           THEN LEN(text)  
                           ELSE statement_end_offset/2 END - 
                     CASE WHEN statement_start_offset = 0 
                            OR statement_start_offset IS NULL 
                             THEN 1  
                             ELSE statement_start_offset/2  END + 1 
                  )  AS [Statement]        
FROM sys.dm_exec_query_stats qs  
   join sys.dm_exec_cached_plans cp on qs.plan_handle = cp.plan_handle 
   CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) st
ORDER BY qs.total_logical_reads DESC;




--List top 10 Queries (This query does not cause locks.)
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED -- the uncommitted statement means no Locks.

SELECT TOP 20
    qs.total_elapsed_time AS [Total Time]
    , qs.execution_count AS [Execution count]
    , SUBSTRING (qt.text,(qs.statement_start_offset/2) + 1,
    ((CASE WHEN qs.statement_end_offset = -1
        THEN LEN(CONVERT(NVARCHAR(MAX), qt.text)) * 2
    ELSE
        qs.statement_end_offset
    END - qs.statement_start_offset)/2) + 1) AS [Individual Query]
    , qt.text AS [Parent Query]
    , DB_NAME(qt.dbid) AS DatabaseName
    , qp.query_plan
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) as qt
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) qp
ORDER BY [Total Time] DESC;







--Top 10 events the server is waiting on
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SELECT TOP 10
        wait_type ,
        max_wait_time_ms wait_time_ms ,
        signal_wait_time_ms ,
        wait_time_ms - signal_wait_time_ms AS resource_wait_time_ms ,
        100.0 * wait_time_ms / SUM(wait_time_ms) OVER ( ) AS percent_total_waits ,
        100.0 * signal_wait_time_ms / SUM(signal_wait_time_ms) OVER ( ) AS percent_total_signal_waits ,
        100.0 * ( wait_time_ms - signal_wait_time_ms )
        / SUM(wait_time_ms) OVER ( ) AS percent_total_resource_waits
FROM    sys.dm_os_wait_stats
WHERE   wait_time_ms > 0 -- remove zero wait_time
        AND wait_type NOT IN -- filter out additional irrelevant waits
( 'SLEEP_TASK', 'BROKER_TASK_STOP', 'BROKER_TO_FLUSH', 'SQLTRACE_BUFFER_FLUSH',
  'CLR_AUTO_EVENT', 'CLR_MANUAL_EVENT', 'LAZYWRITER_SLEEP', 'SLEEP_SYSTEMTASK',
  'SLEEP_BPOOL_FLUSH', 'BROKER_EVENTHANDLER', 'XE_DISPATCHER_WAIT',
  'FT_IFTSHC_MUTEX', 'CHECKPOINT_QUEUE', 'FT_IFTS_SCHEDULER_IDLE_WAIT',
  'BROKER_TRANSMITTER', 'FT_IFTSHC_MUTEX', 'KSOURCE_WAKEUP',
  'LAZYWRITER_SLEEP', 'LOGMGR_QUEUE', 'ONDEMAND_TASK_QUEUE',
  'REQUEST_FOR_DEADLOCK_SEARCH', 'XE_TIMER_EVENT', 'BAD_PAGE_PROCESS',
  'DBMIRROR_EVENTS_QUEUE', 'BROKER_RECEIVE_WAITFOR',
  'PREEMPTIVE_OS_GETPROCADDRESS', 'PREEMPTIVE_OS_AUTHENTICATIONOPS', 'WAITFOR',
  'DISPATCHER_QUEUE_SEMAPHORE', 'XE_DISPATCHER_JOIN', 'RESOURCE_QUEUE' )
ORDER BY wait_time_ms DESC



--Block / Lock Troubleshooter for hung transactions
DBCC OpenTran



--Block / Lock issues (Change DB Name at the end of the script) -- aarhondas
SELECT * FROM (
SELECT es.session_id AS session_id
,COALESCE(es.original_login_name, '') AS login_name
,COALESCE(es.host_name,'') AS hostname
,COALESCE(es.last_request_end_time,es.last_request_start_time) AS last_batch
,es.[status] 'session_status'
,er.[status]'request_status'
,COALESCE(er.blocking_session_id,0) AS blocked_by
,COALESCE(er.wait_type,'MISCELLANEOUS') AS waittype
,COALESCE(er.wait_time,0) AS waittime
,COALESCE(er.last_wait_type,'MISCELLANEOUS') AS lastwaittype
,COALESCE(er.wait_resource,'') AS waitresource
,coalesce(db_name(er.database_id),'No Info') as dbid
,COALESCE(er.command,'AWAITING COMMAND') AS cmd
,sql_text=st.text
,COALESCE(es.cpu_time,0)
   + COALESCE(er.cpu_time,0) AS cpu
,COALESCE(es.reads,0)
   + COALESCE(es.writes,0)
   + COALESCE(er.reads,0)
+ COALESCE(er.writes,0) AS physical_io
,COALESCE(er.open_transaction_count,-1) AS open_tran
,transaction_isolation =
CASE es.transaction_isolation_level
   WHEN 0 THEN 'Unspecified'
   WHEN 1 THEN 'Read Uncommitted'
   WHEN 2 THEN 'Read Committed'
   WHEN 3 THEN 'Repeatable'
   WHEN 4 THEN 'Serializable'
   WHEN 5 THEN 'Snapshot'
END
,COALESCE(es.program_name,'') AS program_name
,es.login_time
FROM sys.dm_exec_sessions es
LEFT OUTER JOIN sys.dm_exec_requests er ON es.session_id = er.session_id
OUTER APPLY sys.dm_exec_sql_text(er.sql_handle) AS st
where es.is_user_process = 1
and es.session_id <> @@spid
)rtab
WHERE rtab.dbid = 'MD_Prd_MVA_SchoolBusInsp'


--list ONLY BLOCKS on the Databases
USE   
OIPA 
GO
SELECT * 
FROM sys.dm_exec_requests
WHERE blocking_session_id <> 0;
GO


--Refined BLOCKING list
SELECT DB_NAME(database_id) AS 'DatabaseName'
, session_id AS 'Session ID'
, blocking_session_id AS 'Blocking Session ID'
, command AS 'Command'
, status AS 'Status'
, wait_time AS 'Wait Time'
, wait_resource AS 'Wait Resource'
, request_id AS 'Request ID'
, sql_handle AS 'SQL Handle'
From sys.dm_exec_requests
Where blocking_session_id <> 0
Order by 'DatabaseName'



/*BLOCKING (Wilfred)*/
EXEC SP_WHO2 active
go
DBCC INPUTBUFFER(83)






--BLOCKING TROUBLESHOOTING
USE Master
GO
SELECT session_id, wait_duration_ms, wait_type, blocking_session_id 
FROM sys.dm_os_waiting_tasks 
WHERE blocking_session_id <> 0
GO





-------DISK TROUBLESHOOTING---------------

--Disk Latency and INFO
SELECT * FROM sys.dm_io_virtual_file_stats (NULL, NULL);


--Disk Latency
SELECT  LEFT(physical_name, 1) AS drive,
        CAST(SUM(io_stall_read_ms) / 
            (1.0 + SUM(num_of_reads)) AS NUMERIC(10,1)) 
                          AS 'avg_read_disk_latency_ms',
        CAST(SUM(io_stall_write_ms) / 
            (1.0 + SUM(num_of_writes) ) AS NUMERIC(10,1)) 
                          AS 'avg_write_disk_latency_ms',
        CAST((SUM(io_stall)) / 
            (1.0 + SUM(num_of_reads + num_of_writes)) AS NUMERIC(10,1)) 
                          AS 'avg_disk_latency_ms'
FROM    sys.dm_io_virtual_file_stats(NULL, NULL) AS divfs
        JOIN sys.master_files AS mf ON mf.database_id = divfs.database_id
                                       AND mf.file_id = divfs.file_id
GROUP BY LEFT(physical_name, 1)
ORDER BY avg_disk_latency_ms DESC;




--Disk Latency and Aggregate Info
SELECT
    [ReadLatency] =
        CASE WHEN [num_of_reads] = 0
            THEN 0 ELSE ([io_stall_read_ms] / [num_of_reads]) END,
    [WriteLatency] =
        CASE WHEN [num_of_writes] = 0
            THEN 0 ELSE ([io_stall_write_ms] / [num_of_writes]) END,
    [Latency] =
        CASE WHEN ([num_of_reads] = 0 AND [num_of_writes] = 0)
            THEN 0 ELSE ([io_stall] / ([num_of_reads] + [num_of_writes])) END,
    [AvgBPerRead] =
        CASE WHEN [num_of_reads] = 0
            THEN 0 ELSE ([num_of_bytes_read] / [num_of_reads]) END,
    [AvgBPerWrite] =
        CASE WHEN [num_of_writes] = 0
            THEN 0 ELSE ([num_of_bytes_written] / [num_of_writes]) END,
    [AvgBPerTransfer] =
        CASE WHEN ([num_of_reads] = 0 AND [num_of_writes] = 0)
            THEN 0 ELSE
                (([num_of_bytes_read] + [num_of_bytes_written]) /
                ([num_of_reads] + [num_of_writes])) END,
    LEFT ([mf].[physical_name], 2) AS [Drive],
    DB_NAME ([vfs].[database_id]) AS [DB],
    [mf].[physical_name]
FROM
    sys.dm_io_virtual_file_stats (NULL,NULL) AS [vfs]
JOIN sys.master_files AS [mf]
    ON [vfs].[database_id] = [mf].[database_id]
    AND [vfs].[file_id] = [mf].[file_id]
-- WHERE [vfs].[file_id] = 2 -- log files
-- ORDER BY [Latency] DESC
-- ORDER BY [ReadLatency] DESC
ORDER BY [WriteLatency] DESC;
GO

--------------MIRRORS----------------------------


		SELECT DB_NAME(database_id) AS 'DatabaseName'
		, mirroring_role_desc AS 'DatabaseRole'
		, mirroring_role_sequence AS 'FailoverCount'
		, mirroring_partner_instance AS 'MirroringInstance'
		, mirroring_state_desc AS 'MirroringState'
		, mirroring_connection_timeout 'MirroringConnectionTimeoutInSeconds'
		, mirroring_witness_name AS 'WitnessInstance'
		, mirroring_witness_state_desc AS 'WitnessState'
		FROM master.sys.database_mirroring
		WHERE mirroring_guid IS NOT NULL
		order by DatabaseName asc



--Re-Sync Disconnected Mirrors
ALTER DATABASE MS_Prd_MDHS SET PARTNER RESUME
ALTER DATABASE OR_Prd_ECommerce SET PARTNER RESUME


--Get mirroring endpoint name
select * from sys.database_mirroring_endpoints
--alter endpoint Mirroring state = stopped
--alter endpoint Mirroring state = started

--stop Endpoint
--alter endpoint Mirroring state = stopped

--Start Endpoint
alter endpoint Mirroring state = started



--Resume a Database
alter database MSGOV_PROD_MDRS_WSS_Content set partner resume


select * from sys.certificates

---------------------------------------------------------------------
--Troubleshooting Logins

/*
CREATE LOGIN [NICUSA\srvd_crp_brands] FROM WINDOWS
GRANT CONNECT SQL TO [NICUSA\srvd_crp_brands]
*/


--------------------------------------------------------------------------


--View Transactions per DB 
use DBNAMEHERE
DBCC openTran




--GET STATS ON RUNNING JOBS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

SELECT r.percent_complete
    , DATEDIFF(MINUTE, start_time, GETDATE()) AS Age
    , DATEADD(MINUTE, DATEDIFF(MINUTE, start_time, GETDATE()) /
        percent_complete * 100, start_time) AS EstimatedEndTime
    , t.Text AS ParentQuery
    , SUBSTRING (t.text,(r.statement_start_offset/2) + 1,
    ((CASE WHEN r.statement_end_offset = -1
        THEN LEN(CONVERT(NVARCHAR(MAX), t.text)) * 2
        ELSE r.statement_end_offset
    END - r.statement_start_offset)/2) + 1) AS IndividualQuery
    , start_time
    , DB_NAME(Database_Id) AS DatabaseName
    , Status
FROM sys.dm_exec_requests r
CROSS APPLY sys.dm_exec_sql_text(sql_handle) t
WHERE session_id > 50
    AND percent_complete > 0
ORDER BY percent_complete DESC

-- ############ NEW Additions 2021 #############

-- Troubleshoot Blocking
EXEC sp_WhoIsActive
    @find_block_leaders = 1,
    @sort_order = '[blocked_session_count] DESC'



--Live, Queries by CPU % ( Updated by James Limb)
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SELECT
r.session_id AS SessionID
, st.text AS batch_text
, SUBSTRING ( st.text
, statement_start_offset / 2 + 1
, ((CASE
WHEN r.statement_end_offset = -1 THEN
(LEN (CONVERT (NVARCHAR(MAX), st.text)) * 2)
ELSE
r.statement_end_offset
END
) - r.statement_start_offset
) / 2 + 1
) AS statement_text
, qp.query_plan AS 'XML Plan'
, [r].[start_time]
, [r].[status]
, [r].[command]
, [r].[database_id]
, [database_name] = DB_NAME ([r].[database_id])
, [r].[blocking_session_id]
, [r].[wait_type]
, [r].[wait_time]
, [r].[last_wait_type]
, [r].[wait_resource]
, [r].[open_transaction_count]
, [r].[transaction_id]
, [r].[context_info]
, [r].[percent_complete]
, [r].[estimated_completion_time]
, [r].[cpu_time]
, [r].[total_elapsed_time]
, [r].[reads]
, [r].[writes]
, [r].[logical_reads]
, [r].[text_size]
, [r].[transaction_isolation_level]
, [r].[lock_timeout]
, [r].[deadlock_priority]
, [r].[row_count]
, [r].[prev_error]
, [r].[nest_level]
, [r].[dop]
, [r].[parallel_worker_count]
, [r].[is_resumable]
FROM
sys.dm_exec_requests r
CROSS APPLY sys.dm_exec_sql_text (r.sql_handle) AS st
CROSS APPLY sys.dm_exec_query_plan (r.plan_handle) AS qp
WHERE
[r].[session_id] <> @@SPID
ORDER BY
cpu_time DESC;






-- LIVE, Queries by CPU %
-- ########## Show Queries by CPU Usage ###########
SELECT 
	r.session_id as SessionID
	,st.TEXT AS batch_text
	,SUBSTRING(st.TEXT, statement_start_offset / 2 + 1, (
			(
				CASE 
					WHEN r.statement_end_offset = - 1
						THEN (LEN(CONVERT(NVARCHAR(max), st.TEXT)) * 2)
					ELSE r.statement_end_offset
					END
				) - r.statement_start_offset
			) / 2 + 1) AS statement_text
	,qp.query_plan AS 'XML Plan'
	,r.*
FROM sys.dm_exec_requests r
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS st
CROSS APPLY sys.dm_exec_query_plan(r.plan_handle) AS qp
ORDER BY cpu_time DESC

		


--#### Find all queries running (Includes system spids) - By Bill Roberts
-- Run this script in its entierty to create the temporary stored procedure.

-- Then simply run it:

--		Exec #Perf_View




if object_id('tempdb..#perf_view') is not null
	drop procedure #perf_view
go

Create PROCEDURE #Perf_View
AS 
Begin -- Procedure

declare @number_of_cpus decimal (5,2)  
  
set nocount on  
 
if object_Id('tempdb..#One') is not null
       Drop table #One
if object_Id('tempdb..#Two') is not null
       Drop table #Two

--set @number_of_cpus = 3.0  

select @Number_of_cpus = cpu_count
from sys.dm_os_sys_info

--select * from sys.dm_exec_sessions
--select * from sys.dm_exec_requests

select GetDate() as Snap1,
       s.Session_Id, s.Login_Time, s.Host_Name, s.Program_Name, s.Login_Name, r.CPU_Time, r.Reads, r.Writes, r.Logical_Reads, db_name(r.database_Id) as Database_Name,
       r.Open_Transaction_Count, r.Command, r.SQL_Handle, r.Plan_Handle, r.Blocking_Session_Id, r.Wait_Type, r.Wait_Time, r.Last_Wait_Type, r.Wait_Resource,
       r.Reads as Request_Reads, r.Writes as Request_Writes, r.Logical_Reads as Request_Logical_Reads
into #One
from sys.dm_exec_sessions s
       join sys.dm_exec_requests r on s.session_id = r.session_id

waitfor delay '00:00:02'

select GetDate() as Snap2,
       s.Session_Id, s.Login_Time, s.Host_Name, s.Program_Name, s.Login_Name, r.CPU_Time, r.Reads, r.Writes, r.Logical_Reads, db_name(r.database_Id) as Database_Name,
       r.Open_Transaction_Count, r.Command, r.SQL_Handle, r.Plan_Handle, r.Blocking_Session_Id, r.Wait_Type, r.Wait_Time, r.Last_Wait_Type, r.Wait_Resource,
       r.Reads as Request_Reads, r.Writes as Request_Writes, r.Logical_Reads as Request_Logical_Reads
	   , r.granted_query_memory, r.total_elapsed_time
into #Two
from sys.dm_exec_sessions s
       join sys.dm_exec_requests r on s.session_id = r.session_id

--select * from #One

Select
t.Session_Id, t.Host_Name, t.Program_Name, t.Login_Name, t.Blocking_Session_Id,
Convert(Decimal(10,1),(t.CPU_Time - o.CPU_Time)*1.0/ (datediff(ms, o.Snap1, t.Snap2)/1000.0) ) as [CPU ms/s],

Convert(Decimal(5,1),(t.CPU_Time - o.CPU_Time)*1.0/datediff(ms, o.Snap1, t.Snap2) / @number_of_cpus * 100.0) as [CPU %],

convert(decimal(12,2),t.CPU_Time/1000.0) as [Tot CPU (sec)],

convert(decimal(12,2), t.total_elapsed_time/1000.0) as [Tot Elapsed (sec)],

Convert(decimal(15,2),(t.Reads - o.Reads)/(datediff(ms,o.Snap1,t.Snap2) / 1000.0)) as [Reads/s],
Convert(decimal(15,2),(t.Logical_Reads - o.Logical_Reads)/(datediff(ms,o.Snap1,t.Snap2) / 1000.0)) as [Logical_Reads/s],
Convert(decimal(15,2),(t.Writes - o.Writes)/(datediff(ms,o.Snap1,t.Snap2) / 1000.0)) as [Writes/s],
Convert(decimal(10,1),t.granted_query_memory/128.0) as [Memory (MB)],
t.Database_Name, t.Command,/*t.SQL_Handle,*/ 'SELECT text from sys.dm_exec_sql_text('+convert(varchar(max),t.SQL_Handle,1)+')' as SQL_Query,
 /*t.Plan_Handle,*/ 'select query_plan from sys.dm_exec_query_plan('+convert(varchar(max),t.plan_handle,1)+')' as Exec_Plan,
t.Wait_Type, t.Wait_Time, t.Last_Wait_Type, t.Wait_Resource
From #Two t
       left Outer join #one o on t.session_id = o.session_id
WHERE t.session_id > 50 OR Convert(Decimal(10,1),(t.CPU_Time - o.CPU_Time)*1.0/ (datediff(ms, o.Snap1, t.Snap2)/1000.0) ) > 0
ORDER BY [CPU ms/s] desc

  
End -- Procedure

