﻿Import-Module SQLServer
Import-Module ActiveDirectory

$GetServerList = @"


"@

$Srv = "SQLDBA01"

$Server = New-Object("Microsoft.SQLServer.Management.SMO.Server")$Srv

$FilterItems = "DenyUser",`
"MS_DataCollectorInternalUser",`
"##MS_SSISServerCleanupJobLogin##",`
"##MS_PolicyTsqlExecutionLogin##",`
"NT SERVICE\SQLServerReportingServices",`
"NT SERVICE\PowerBIReportServer",`
"##MS_PolicyEventProcessingLogin##",`
"##MS_AgentSigningCertificate##",`
"INFORMATION_SCHEMA",`
"sys",`
"guest",`
"dbo",`
"##MS_SSISServerCleanupJobUser##"



$DBList = $Server.Databases
$UserList = @()
foreach($DB in $DBlist)
{
    #Add logins here

    $Users = ($DB.Users).name
    foreach($User in $Users)
    {
      
        if($Userlist -notcontains $User -and $FilterItems -notcontains $User)
        {
           Write-host "User" -ForegroundColor Yellow
            $UserList += $User
        }
    }


}



foreach($User in $UserList)
{
   
    $User = $user.Split("\")
    if($user.count -eq 2){ $User = $user[1]}

   

    $Error.Clear()
    Get-ADUser $User  
    if($Error)
    {
        $Error.Clear()
        $Group = Get-ADGroup $User
        if($Error)
        {
            Write-Host "User Does not Exist in Active Directory: "$User
        }
    }

}




######### testing area ############
<#
$Users = "KCDOM01\TZ"
foreach($User in $Users)
{
    $User
    if($user -like "*\*"){"Yes"}
}
#>