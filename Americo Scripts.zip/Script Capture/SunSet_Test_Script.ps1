import-module ActiveDirectory
import-module ImportExcel

$Array = Import-Excel "C:\Users\tzumwalt-db\Desktop\Code Testing Area\SunSet_Test_List.xlsx"
$BadArray = @()
$GoodArray = @()


foreach($Srv in $Array.Servers)
{
    $Error.Clear()
    Try{
        Get-ADComputer $Srv
    }
    Catch{
        if($Error)
        {
            Write-Host $Srv "May be Sunset" -ForegroundColor Gray
            $BadArray += $Srv
            $Error.Clear()
        }
    }
    if(-not $Error)
    {
        Write-Host $Srv "Seems Online" -ForegroundColor Yellow
        $GoodArray += $Srv
    }
}